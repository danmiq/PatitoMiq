﻿Module Principal

    Sub Main()
        Dim sCarpetaMolde, sCarpetaDestino, sProyecto As String

        sCarpetaMolde = My.Application.CommandLineArgs(0)
        sCarpetaDestino = My.Application.CommandLineArgs(1)
        sProyecto = My.Application.CommandLineArgs(2)

        VB2019.CopiarMolde(sCarpetaMolde, sCarpetaDestino, sProyecto)
        VB2019.AddForm(sCarpetaDestino & sProyecto & "\", "frmMain")
        System.Console.WriteLine("Finalizado")
        Stop

    End Sub





End Module

