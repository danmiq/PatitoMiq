alter table Ventas add id_cliente integer 

delete from ventas 