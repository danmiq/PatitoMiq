<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLista
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLista))
        Me.lvDatos = New System.Windows.Forms.ListView()
        Me.colId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.lblCantItems = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lvDatos
        '
        Me.lvDatos.Activation = System.Windows.Forms.ItemActivation.TwoClick
        Me.lvDatos.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colId, Me.ColumnHeader4})
        Me.lvDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.lvDatos.FullRowSelect = True
        Me.lvDatos.GridLines = True
        Me.lvDatos.HideSelection = False
        Me.lvDatos.Location = New System.Drawing.Point(0, 0)
        Me.lvDatos.Name = "lvDatos"
        Me.lvDatos.Size = New System.Drawing.Size(501, 372)
        Me.lvDatos.TabIndex = 1
        Me.lvDatos.UseCompatibleStateImageBehavior = False
        Me.lvDatos.View = System.Windows.Forms.View.Details
        '
        'colId
        '
        Me.colId.Text = "C�digo"
        Me.colId.Width = 54
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Nombre"
        Me.ColumnHeader4.Width = 300
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(410, 378)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(79, 31)
        Me.btnSalir.TabIndex = 7
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnOK.Image = CType(resources.GetObject("btnOK.Image"), System.Drawing.Image)
        Me.btnOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnOK.Location = New System.Drawing.Point(325, 378)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(79, 31)
        Me.btnOK.TabIndex = 8
        Me.btnOK.Text = "Elegir  "
        Me.btnOK.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'lblCantItems
        '
        Me.lblCantItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCantItems.ForeColor = System.Drawing.Color.Navy
        Me.lblCantItems.Location = New System.Drawing.Point(12, 384)
        Me.lblCantItems.Name = "lblCantItems"
        Me.lblCantItems.Size = New System.Drawing.Size(69, 18)
        Me.lblCantItems.TabIndex = 65
        Me.lblCantItems.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmLista
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(501, 418)
        Me.Controls.Add(Me.lblCantItems)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.lvDatos)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "frmLista"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " Lista"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lvDatos As System.Windows.Forms.ListView
    Friend WithEvents colId As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents lblCantItems As System.Windows.Forms.Label
End Class
