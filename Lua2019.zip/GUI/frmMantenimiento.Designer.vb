﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMantenimiento
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMantenimiento))
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnBackUp = New System.Windows.Forms.Button()
        Me.txtArchivoBackup = New System.Windows.Forms.TextBox()
        Me.btnDirectorio = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtEmpresa = New System.Windows.Forms.TextBox()
        Me.btnGrabarEmpresa = New System.Windows.Forms.Button()
        Me.txtSettingBase = New System.Windows.Forms.TextBox()
        Me.txtSettingImagenes = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtSettingReportes = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtRemitente = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTelRemitente = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMail = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtClaveMail = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(428, 320)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(85, 39)
        Me.btnSalir.TabIndex = 53
        Me.btnSalir.TabStop = False
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.btnBackUp)
        Me.GroupBox1.Controls.Add(Me.txtArchivoBackup)
        Me.GroupBox1.Controls.Add(Me.btnDirectorio)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 235)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(512, 81)
        Me.GroupBox1.TabIndex = 54
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Respaldo / Restauracion"
        '
        'btnBackUp
        '
        Me.btnBackUp.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBackUp.Location = New System.Drawing.Point(440, 13)
        Me.btnBackUp.Name = "btnBackUp"
        Me.btnBackUp.Size = New System.Drawing.Size(68, 30)
        Me.btnBackUp.TabIndex = 5
        Me.btnBackUp.Text = "Respaldar"
        Me.btnBackUp.UseVisualStyleBackColor = True
        '
        'txtArchivoBackup
        '
        Me.txtArchivoBackup.Location = New System.Drawing.Point(13, 18)
        Me.txtArchivoBackup.Name = "txtArchivoBackup"
        Me.txtArchivoBackup.Size = New System.Drawing.Size(331, 20)
        Me.txtArchivoBackup.TabIndex = 4
        '
        'btnDirectorio
        '
        Me.btnDirectorio.Location = New System.Drawing.Point(350, 16)
        Me.btnDirectorio.Name = "btnDirectorio"
        Me.btnDirectorio.Size = New System.Drawing.Size(35, 25)
        Me.btnDirectorio.TabIndex = 3
        Me.btnDirectorio.Text = "..."
        Me.btnDirectorio.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(5, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 55
        Me.Label1.Text = "Empresa"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Location = New System.Drawing.Point(61, 7)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(408, 20)
        Me.txtEmpresa.TabIndex = 56
        '
        'btnGrabarEmpresa
        '
        Me.btnGrabarEmpresa.Location = New System.Drawing.Point(461, 73)
        Me.btnGrabarEmpresa.Name = "btnGrabarEmpresa"
        Me.btnGrabarEmpresa.Size = New System.Drawing.Size(53, 32)
        Me.btnGrabarEmpresa.TabIndex = 57
        Me.btnGrabarEmpresa.Text = "Grabar"
        Me.btnGrabarEmpresa.UseVisualStyleBackColor = True
        '
        'txtSettingBase
        '
        Me.txtSettingBase.Location = New System.Drawing.Point(61, 141)
        Me.txtSettingBase.Name = "txtSettingBase"
        Me.txtSettingBase.ReadOnly = True
        Me.txtSettingBase.Size = New System.Drawing.Size(337, 20)
        Me.txtSettingBase.TabIndex = 58
        '
        'txtSettingImagenes
        '
        Me.txtSettingImagenes.Location = New System.Drawing.Point(61, 168)
        Me.txtSettingImagenes.Name = "txtSettingImagenes"
        Me.txtSettingImagenes.ReadOnly = True
        Me.txtSettingImagenes.Size = New System.Drawing.Size(337, 20)
        Me.txtSettingImagenes.TabIndex = 59
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 144)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 60
        Me.Label2.Text = "Base"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 171)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 61
        Me.Label3.Text = "Imagenes"
        '
        'txtSettingReportes
        '
        Me.txtSettingReportes.Location = New System.Drawing.Point(61, 194)
        Me.txtSettingReportes.Name = "txtSettingReportes"
        Me.txtSettingReportes.ReadOnly = True
        Me.txtSettingReportes.Size = New System.Drawing.Size(337, 20)
        Me.txtSettingReportes.TabIndex = 62
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 197)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 63
        Me.Label4.Text = "Reportes"
        '
        'txtRemitente
        '
        Me.txtRemitente.Location = New System.Drawing.Point(61, 33)
        Me.txtRemitente.Name = "txtRemitente"
        Me.txtRemitente.Size = New System.Drawing.Size(246, 20)
        Me.txtRemitente.TabIndex = 65
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 64
        Me.Label5.Text = "Remitente"
        '
        'txtTelRemitente
        '
        Me.txtTelRemitente.Location = New System.Drawing.Point(61, 59)
        Me.txtTelRemitente.Name = "txtTelRemitente"
        Me.txtTelRemitente.Size = New System.Drawing.Size(170, 20)
        Me.txtTelRemitente.TabIndex = 67
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 62)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 13)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "Tel"
        '
        'txtMail
        '
        Me.txtMail.Location = New System.Drawing.Point(61, 85)
        Me.txtMail.Name = "txtMail"
        Me.txtMail.Size = New System.Drawing.Size(170, 20)
        Me.txtMail.TabIndex = 69
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(7, 88)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 68
        Me.Label7.Text = "e-mail"
        '
        'txtClaveMail
        '
        Me.txtClaveMail.Location = New System.Drawing.Point(285, 85)
        Me.txtClaveMail.Name = "txtClaveMail"
        Me.txtClaveMail.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtClaveMail.Size = New System.Drawing.Size(170, 20)
        Me.txtClaveMail.TabIndex = 71
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(245, 88)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 70
        Me.Label8.Text = "Clave"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button1
        '
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button1.Location = New System.Drawing.Point(440, 45)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(68, 30)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Recuperar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmMantenimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(520, 361)
        Me.Controls.Add(Me.txtClaveMail)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtMail)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtTelRemitente)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtRemitente)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtSettingReportes)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtSettingImagenes)
        Me.Controls.Add(Me.txtSettingBase)
        Me.Controls.Add(Me.btnGrabarEmpresa)
        Me.Controls.Add(Me.txtEmpresa)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.Label3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMantenimiento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Configuración"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnBackUp As System.Windows.Forms.Button
    Friend WithEvents txtArchivoBackup As System.Windows.Forms.TextBox
    Friend WithEvents btnDirectorio As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents btnGrabarEmpresa As System.Windows.Forms.Button
    Friend WithEvents txtSettingBase As System.Windows.Forms.TextBox
    Friend WithEvents txtSettingImagenes As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSettingReportes As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtRemitente As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtTelRemitente As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtMail As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtClaveMail As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
