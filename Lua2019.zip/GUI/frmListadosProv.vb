﻿Public Class frmListadosProv

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmListados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aColumnasMerc() As String = {"Codigo", "Articulo", "Costo", "Precio", "Stock", "SubTotCosto", "SubTotPrecio", "Estado"}
        Dim aColumnasVentas() As String = {"Codigo", "Articulo", "Costo", "Cantidad", "Subtotal", "Fecha"}
        Me.lblStatus.Text = ""

        Me.dtDesde.Value = Date.Today
        Me.dtDesde.Value = DateAdd(DateInterval.Day, 1 - (Me.dtDesde.Value.Day), Me.dtDesde.Value)

        InitGrilla(Me.grDatosMerc, aColumnasMerc)
        InitGrilla(Me.grDatosVentas, aColumnasVentas)
        Me.txtNomProv.Focus()
    End Sub

    Private Sub txtNomProv_Leave(sender As Object, e As EventArgs) Handles txtNomProv.Leave
        Dim sMail As String
        CargarProveedor(Me.lblCodProv, Me.txtNomProv, sMail)
        Me.txtMail.Text = sMail

        If Me.lblCodProv.Text <> "" Then
            CargarDatos(CInt(Me.lblCodProv.Text))
        End If
    End Sub

    Sub CargarDatos(nIdProv As Integer)
        Dim oLista As Prendas
        Dim oListaVentas As List(Of ITEM_VENTA_DETALLE)

        oLista = oHandler.CargarPrendas("P.id_proveedor = " & nIdProv.ToString, 2)
        CargarGrillaStock(Me.grDatosMerc, oLista)

        oListaVentas = oHandlerRep.GetVentasDetalle("P.id_proveedor = " & nIdProv.ToString)
        CargarGrillaVentasProv(Me.grDatosVentas, oListaVentas)
    End Sub

    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        mnuAcciones.Show(System.Windows.Forms.Cursor.Position)
    End Sub

    Private Sub ToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles mnuListaAmbos.Click
        ListarMercaderia()
        ListarVentas()
    End Sub

    Private Sub mnuListaVentas_Click(sender As Object, e As EventArgs) Handles mnuListaVentas.Click
        ListarVentas()
    End Sub
    Private Sub mnuListaMercaderia_Click(sender As Object, e As EventArgs) Handles mnuListaMercaderia.Click
        ListarMercaderia()
    End Sub
    Sub ListarMercaderia()
        Dim sArchivoGenerado As String

        Try
            sArchivoGenerado = GrillaToPDF(CARPETA_REPORTES, "Stock_" & Me.lblCodProv.Text, "Stock de Mercadería ", "Proveedor " & Me.txtNomProv.Text, Me.grDatosMerc)

            If Me.chkMail.Checked And Me.txtMail.Text <> "" Then
                Me.lblStatus.Text = "Enviando mail a " & Me.txtMail.Text & " ..."
                Reportes.MandaMail(Me.txtMail.Text, "Su stock de mercaderia en " & NOMBRE_EMPRESA, "Gracias por trabajar con nosotros.", sArchivoGenerado)
            End If
            MostrarArchivo(sArchivoGenerado)
            Me.lblStatus.Text = "Archivo " & sArchivoGenerado & " generado"
        Catch ex As Exception
            MsgBox("Error a generar : " & ex.Message)
        End Try

    End Sub
    Sub ListarVentas()
        Dim sArchivoGenerado As String
        Dim sFechaFSDesde, sFechaFSHasta, sParametros As String

        Try
            sFechaFSDesde = FechaUniversal(Me.dtDesde.Value)
            sFechaFSHasta = FechaUniversal(Me.dtHasta.Value)

            sParametros = "Proveedor " & Me.txtNomProv.Text & " - Del " & Format(Me.dtDesde.Value, "dd/MM/yyyy") & " al " & Format(Me.dtHasta.Value, "dd/MM/yyyy")

            sArchivoGenerado = GrillaToPDF(CARPETA_REPORTES, "Ventas_" & Me.lblCodProv.Text & "_" & sFechaFSDesde & "_" & sFechaFSHasta, "Listado de Ventas", sParametros, Me.grDatosVentas)

            If Me.chkMail.Checked And Me.txtMail.Text <> "" Then
                Me.lblStatus.Text = "Enviando mail a " & Me.txtMail.Text & " ..."
                Reportes.MandaMail(Me.txtMail.Text, "Sus ventas en " & NOMBRE_EMPRESA, sParametros, sArchivoGenerado)
            End If
            MostrarArchivo(sArchivoGenerado)
            Me.lblStatus.Text = "Archivo " & sArchivoGenerado & " generado"
        Catch ex As Exception
            MsgBox("Error a generar : " & ex.Message)
        End Try
    End Sub

    Private Sub txtNomProv_TextChanged(sender As Object, e As EventArgs) Handles txtNomProv.TextChanged

    End Sub

    Private Sub btnCargar_Click(sender As Object, e As EventArgs) Handles btnCargar.Click
        If Me.lblCodProv.Text <> "" Then
            CargarDatos(CInt(Me.lblCodProv.Text))
        End If
    End Sub
End Class