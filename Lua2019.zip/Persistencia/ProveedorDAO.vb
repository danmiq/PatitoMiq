Public Class ProveedorDAO
    Inherits DAOBase

    Const sSQLPrincipal As String = "SELECT * FROM PROVEEDORES"

    Public Sub New(ByVal obase As Object)
        MyBase.New(obase)
    End Sub

    Public Function CargarLista(sFiltro As String) As Proveedores
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New Proveedores
        Dim p As Proveedor

        sSQL = sSQLPrincipal
        If sFiltro <> "" Then
            sSQL = sSQL & " WHERE " & sFiltro
        End If
        sSQL = sSQL & " ORDER BY id_proveedor"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            p = New Proveedor()
            p.Id = r.Item("id_proveedor")
            p.Nombre = r.Item("Nombre").ToString.Trim
            p.Direccion = NoNulo(r.Item("Direccion"), "")
            p.Telefono = NoNulo(r.Item("Telefono"), "")
            p.Mail = NoNulo(r.Item("Mail"), "")
            p.FecIngreso = NoNulo(r.Item("FecIngreso"), "")
            oLista.Items.Add(p)
        Next
        Return oLista
    End Function

    Public Function Cargar(ByVal idObjeto As Integer) As Proveedor
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim o As Proveedor

        sSQL = sSQLPrincipal & " WHERE id_proveedor = " & idObjeto

        d = oBase.Consultar(sSQL)
        If d.Tables(0).Rows.Count > 0 Then
            r = d.Tables(0).Rows(0)
            o = New Proveedor()
            o.Id = r.Item("id_proveedor")
            o.Nombre = r.Item("Nombre").ToString.Trim
            o.Direccion = NoNulo(r.Item("Direccion"), "")
            o.Telefono = NoNulo(r.Item("Telefono"), "")
            o.Mail = NoNulo(r.Item("Mail"), "")
            o.FecIngreso = NoNulo(r.Item("FecIngreso"), "")
        End If
        Return o
    End Function


    Public Function Grabar(ByVal o As Proveedor, ByVal bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim bOk As Boolean = True

        Try
            oBase.BeginTran()
            If Not bEliminar Then
                If ExisteBD(o) Then
                    sSQL = "UPDATE PROVEEDORES SET " & _
                     "   Direccion = " & Comillas(o.Direccion) & _
                     " , Nombre = " & Comillas(o.Nombre) & _
                     " , Telefono = " & Comillas(o.Telefono) & _
                     " , Mail = " & Comillas(o.Mail) & _
                     " WHERE id_proveedor = " & o.Id
                    oBase.Actualizar(sSQL)
                Else
                    sSQL = "insert into PROVEEDORES (id_proveedor ,Nombre ,Direccion, Telefono, Mail,FecIngreso) values (" & _
                            o.Id & "," & Comillas(o.Nombre) & "," & Comillas(o.Direccion) & "," & Comillas(o.Telefono) & "," & Comillas(o.Mail) & ",getdate()" & _
                            ")"
                    oBase.Actualizar(sSQL)
                End If

            Else
                sSQL = "DELETE FROM PROVEEDORES WHERE id_proveedor = " & o.Id
                oBase.Actualizar(sSQL)
            End If

            sError = ""
            oBase.CommitTran()

        Catch ex As Exception
            oBase.RollbackTran()
            sError = ex.Message
            bOk = False
        End Try
        Return bOk
    End Function

    Public Function ExisteBD(ByVal o As Proveedor) As Boolean
        Return Existe(TABLA_PROVEEDORES, "id_proveedor", o.Id)
    End Function
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub


End Class
