Imports System.IO

Public Class PrendaDAO
    Inherits DAOBase

    Const sSQLLista1 As String = "SELECT P.* , Prov.Nombre AS NomProveedor, S.Nombre as Status" & _
                " ,(SELECT count(*) FROM PRENDAS_IMAGENES I WHERE I.id_prenda = P.id_prenda) as CantFotos" & _
                " FROM PRENDAS P" & _
                " JOIN PROVEEDORES Prov ON Prov.id_proveedor = P.id_proveedor" & _
                " JOIN STATUS S ON P.cod_status = S.cod_status"
                
    ' Esta lista trae las prendas candidatas a liquidar
    Const sSQLLista2 As String = "SELECT P.* , Prov.Nombre AS NomProveedor, S.Nombre as Status" & _
            " FROM PRENDAS P" & _
            " JOIN PROVEEDORES Prov ON Prov.id_proveedor = P.id_proveedor" & _
            " JOIN STATUS S         ON P.cod_status = S.cod_status"
    Public Sub New(ByVal obase As Object)
        MyBase.New(obase)
    End Sub

    Public Function Devolver(nIdPrenda As Integer, nCant As Integer, dtFecha As Date, ByRef sError As String) As Boolean
        Dim sSQL As String

        Devolver = True
        Try
            oBase.BeginTran()
            sSQL = "UPDATE PRENDAS SET " & _
                   "  fec_devolucion = " & Comillas(FechaUniversal(dtFecha)) & _
                   " , Stock = Stock - " & nCant & _
                   " WHERE id_prenda = " & nIdPrenda
            oBase.Actualizar(sSQL)

            sSQL = "UPDATE PRENDAS SET cod_status = " & T_STATUS.DEVUELTA_PROVEEDOR & _
                   " WHERE id_prenda = " & nIdPrenda & " AND Stock = 0"
            oBase.Actualizar(sSQL)

            sSQL = "INSERT INTO DEVOLUCIONES(id_prenda, fec_devolucion, cantidad) VALUES (" & nIdPrenda & ",getdate()," & nCant & ")"
            oBase.Actualizar(sSQL)

            oBase.CommitTran()
        Catch ex As Exception
            oBase.RollbackTran()
            Devolver = False
            sError = ex.Message
        End Try
    End Function

    Public Function CargarLista2(ByVal sFiltro As String) As Prendas
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New Prendas
        Dim p As Prenda

        sSQL = sSQLLista2
        If sFiltro <> "" Then
            sSQL = sSQL & " WHERE " & sFiltro
        End If
        sSQL = sSQL & " ORDER BY id_prenda"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            p = New Prenda()
            p.Id = r.Item("id_prenda")
            p.Proveedor = r.Item("NomProveedor")
            p.FecIngreso = NoNulo(r.Item("fec_ingreso"), FECHA_CENTINELA)
            p.Precio = NoNulo(r.Item("Precio"), 0)
            p.CodStatus = r.Item("cod_status")
            p.Descripcion = NoNulo(r.Item("Descripcion"), "")
            p.Stock = NoNulo(r.Item("Stock"), 0)
            p.Status = r.Item("Status")
            oLista.Items.Add(p)
        Next
        Return oLista
    End Function

    Public Function CargarLista() As Prendas
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New Prendas
        Dim p As Prenda

        sSQL = sSQLLista1
        sSQL = sSQL & " ORDER BY id_prenda"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            p = New Prenda()
            p.Id = r.Item("id_prenda")
            p.Proveedor = r.Item("NomProveedor").ToString.Trim
            p.FecIngreso = NoNulo(r.Item("fec_ingreso"), FECHA_CENTINELA)
            p.Precio = NoNulo(r.Item("Precio"), 0)
            p.Costo = NoNulo(r.Item("Costo"), 0)
            p.Stock = NoNulo(r.Item("Stock"), 0)
            p.CodStatus = r.Item("cod_status")
            p.CantFotos = r.Item("CantFotos")
            p.Descripcion = r.Item("Descripcion").ToString.Trim
            p.Status = r.Item("Status")
            p.IdProveedor = r.Item("id_proveedor")
            p.FecDevolucion = NoNulo(r.Item("fec_devolucion"), FECHA_CENTINELA)

            oLista.Items.Add(p)
        Next
        Return oLista
    End Function

    Public Function Cargar(ByVal idPrenda As Integer, ByVal bModoLight As Boolean) As Prenda
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim o As Prenda
        Dim oPromoDAO As New PromoDAO(Me.oBase)

        sSQL = sSQLLista1 & " WHERE P.id_prenda = " & idPrenda

        d = oBase.Consultar(sSQL)
        If d.Tables(0).Rows.Count > 0 Then
            r = d.Tables(0).Rows(0)
            o = New Prenda()
            o.Id = r.Item("id_prenda")
            o.Proveedor = r.Item("NomProveedor").ToString.Trim
            o.FecIngreso = NoNulo(r.Item("fec_ingreso"), FECHA_CENTINELA)
            o.IdProveedor = r.Item("id_proveedor")
            o.Precio = NoNulo(r.Item("Precio"), 0)
            o.Costo = NoNulo(r.Item("Costo"), 0)
            o.CodStatus = r.Item("cod_status")
            o.Status = r.Item("Status")
            o.Stock = r.Item("Stock")
            o.FecDevolucion = NoNulo(r.Item("fec_devolucion"), FECHA_CENTINELA)

            o.Descripcion = IIf(IsDBNull(r.Item("Descripcion")), "", r.Item("Descripcion")).ToString.Trim
            CargarDatosExtra(o)
            CargarImagenes(o)
            '            o.Promos = oPromoDAO.CargarLista("PP.id_prenda = " & o.Id)
        End If
        Return o
    End Function

    Private Sub CargarDatosExtra(ByRef o As Prenda)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow

        'If o.CodStatus = T_STATUS.VENDIDA Then
        '    sSQL = "SELECT  V.fec_venta, C.Nombre" & _
        '             " FROM  VENTAS V " & _
        '             " JOIN  CLIENTES C ON C.id_contacto = V.id_contacto " & _
        '             " WHERE V.id_prenda = " & o.Id

        '    d = oBase.Consultar(sSQL)
        '    If d.Tables(0).Rows.Count > 0 Then
        '        r = d.Tables(0).Rows(0)
        '        o.ExtraInfo = "El " & r.Item("fec_venta") & " a " & r.Item("Nombre")

        '    End If
        'End If

        If o.CodStatus = T_STATUS.DEVUELTA_PROVEEDOR Then
            o.ExtraInfo = "El " & o.FecDevolucion
        End If

    End Sub

    Private Sub CargarImagenes(ByRef o As Prenda)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim im As Prenda.T_IMAGEN

        sSQL = "select   * from   PRENDAS_IMAGENES where id_prenda = " & o.Id

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            im.Archivo = r.Item("txt_archivo")
            im.IdSec = r.Item("id_sec")
            im.Accion = Prenda.T_ACCION_IMAGEN.NADA
            o.AddImagen(im)
        Next
    End Sub

    Public Function Grabar(ByVal o As Prenda, ByVal bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim bOk As Boolean = True

        Try
            oBase.BeginTran()
            If Not bEliminar Then
                If ExisteBD(o) Then
                    sSQL = "UPDATE PRENDAS SET " & _
                     "  fec_ingreso = '" & FechaUniversal(o.FecIngreso) & "'" & _
                     " , Precio = " & o.Precio & _
                     " , Costo = " & o.Costo & _
                     " , Stock = " & o.Stock & _
                     " , id_proveedor = " & o.IdProveedor & _
                     " WHERE id_prenda = " & o.Id
                    oBase.Actualizar(sSQL)
                Else
                    sSQL = "insert into PRENDAS (id_prenda   ,Descripcion ,Precio , Costo, Stock,fec_ingreso ,id_proveedor, cod_status) values (" & _
                            o.Id & "," & Comillas(o.Descripcion) & "," & o.Precio & "," & o.Costo & "," & o.Stock & ",'" & FechaUniversal(o.FecIngreso) & "'," & _
                            o.IdProveedor & "," & o.CodStatus & ")"
                    oBase.Actualizar(sSQL)
                End If

            Else
                sSQL = "DELETE FROM PRENDAS WHERE id_prenda = " & o.Id
                oBase.Actualizar(sSQL)
            End If

            sError = ""
            oBase.CommitTran()

        Catch ex As Exception
            oBase.RollbackTran()
            sError = ex.Message
            bOk = False
        End Try
        Return bOk
    End Function


    Public Function GrabarImagenes(ByVal o As Prenda, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim bOk As Boolean = True
        Dim t As Prenda.T_IMAGEN
        Dim sArchivo As String

        Try
            oBase.BeginTran()

            For Each t In o.Imagenes
                If t.Accion = Prenda.T_ACCION_IMAGEN.AGREGAR Then
                    sArchivo = CopiarArchivo(t.Archivo, o.Id, t.IdSec)
                    If sArchivo <> "" Then
                        sSQL = "insert into PRENDAS_IMAGENES (id_prenda,id_sec ,txt_archivo) values (" & o.Id & "," & t.IdSec & ",'" & sArchivo & "')"
                        oBase.Actualizar(sSQL)
                    End If
                Else
                    If t.Accion = Prenda.T_ACCION_IMAGEN.ELIMINAR Then

                        My.Computer.FileSystem.DeleteFile(t.Archivo)

                        sSQL = "DELETE FROM PRENDAS_IMAGENES WHERE id_prenda = " & o.Id & " and id_sec = " & t.IdSec
                        oBase.Actualizar(sSQL)
                    End If
                End If
            Next

            sError = ""
            oBase.CommitTran()

        Catch ex As Exception
            oBase.RollbackTran()
            sError = ex.Message
            bOk = False
        End Try
        Return bOk
    End Function

    Function CopiarArchivo(sArchOrigen As String, nIdPrenda As Integer, nIdSec As Integer) As String
        ' Copia un archivo de un origen y genera el nombre dentro de la estructura de FS de este sistema, si no puede retorna ""
        Dim sArchivoNuevo As String
        Dim sExt As String = Path.GetExtension(sArchOrigen)
        Dim sPathNuevo As String = CARPETA_IMAGENES & nIdPrenda.ToString

        Try
            My.Computer.FileSystem.CreateDirectory(sPathNuevo)

            sArchivoNuevo = sPathNuevo & "\IMAGEN_" & nIdSec.ToString.Trim & sExt

            If sArchivoNuevo <> "" Then
                FileCopy(sArchOrigen, sArchivoNuevo)
            End If
            Return sArchivoNuevo
        Catch
            Return ""
        End Try
    End Function

    Public Function ExisteBD(ByVal o As Prenda) As Boolean
        Return Existe(TABLA_PRENDAS, "id_prenda", o.Id)
    End Function
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub


End Class
