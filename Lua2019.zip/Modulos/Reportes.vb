﻿Imports System.IO
Imports System.Net
Imports System.Net.Mail
Imports iText.IO.Image
Imports iTextSharp.text
Imports iTextSharp.text.pdf

Module Reportes
    Public Structure ITEM_VENTA_RESUMEN
        Dim Fecha As Date
        Dim ImporteCompra As Double
        Dim ImporteVenta As Double
        Dim Cantidad As Integer
    End Structure

    Friend Structure ITEM_VENTA_DETALLE
        Dim IdPrenda As Integer
        Dim IdProveedor As Integer
        Dim Costo As Double
        Dim Precio As Double
        Dim Cantidad As Integer
        Dim NomPrenda As String
        Dim NomProveedor As String
        Dim Fecha As Date
    End Structure

    Public oHandlerRep As HandlerReporte

    Sub InitGrilla(ByRef gr As DataGridView, aColumnas() As String)
        Dim s As String
        Dim col As DataGridViewTextBoxColumn

        gr.ShowEditingIcon = False
        gr.RowHeadersVisible = False

        For Each s In aColumnas
            col = New DataGridViewTextBoxColumn
            col.DataPropertyName = "PropertyName"
            col.HeaderText = s
            col.Name = "col" & s.Replace(" ", "")
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            gr.Columns.Add(col)
        Next

    End Sub

    Public Sub MostrarArchivo(sArchivo As String)
        ' Abre archivo XLS o PDF
        If Strings.Right(sArchivo, 4).ToUpper.Contains("XLS") Then

            Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
            p.EnableRaisingEvents = False
            System.Diagnostics.Process.Start("Excel.exe", sArchivo)
        Else
            System.Diagnostics.Process.Start(sArchivo)
        End If
    End Sub

    Public Sub MandaMail(sTo As String, sSubject As String, sBody As String, sAttach As String)
        Dim fromAddress As MailAddress
        Dim toAddress As MailAddress
        Dim fromPassword As String = CLAVE_MAIL
        Dim subject As String = sSubject
        Dim body As String = sBody

        Try
            fromAddress = New MailAddress(CASILLA_MAIL, CASILLA_MAIL)
            toAddress = New MailAddress(sTo, "Nombre")

            Dim smtp = New SmtpClient With {
                .Host = "smtp.gmail.com",
                .Port = 587,
                .UseDefaultCredentials = False,
                .DeliveryMethod = SmtpDeliveryMethod.Network,
                .Credentials = New NetworkCredential(fromAddress.Address, fromPassword),
                .EnableSsl = True
            }

            Dim a As System.Net.Mail.Attachment

            If sAttach <> "" Then
                a = New System.Net.Mail.Attachment(sAttach)
            End If

            Using m = New MailMessage(fromAddress, toAddress) With {
                .Subject = subject,
                .Body = body
            }
                If sAttach <> "" Then
                    m.Attachments.Add(a)
                End If
                smtp.Send(m)
            End Using
        Catch ex As Exception
            MsgBox("Error al mandar el mail" & vbCrLf & ex.Message)
        End Try
    End Sub

    Friend Sub CargarGrilla(ByRef gr As DataGridView, oVentas As List(Of ITEM_VENTA_DETALLE))
        Dim v As ITEM_VENTA_DETALLE
        Dim r As DataGridViewRow
        Dim n As Integer
        Dim nTotCosto, nTotPrecio As Double

        nTotCosto = 0
        nTotPrecio = 0

        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()

            gr.Rows(n).Cells(0).Value = v.IdPrenda
            gr.Rows(n).Cells(1).Value = v.NomPrenda
            gr.Rows(n).Cells(2).Value = v.Precio
            gr.Rows(n).Cells(3).Value = v.Costo
            gr.Rows(n).Cells(4).Value = v.Cantidad
            gr.Rows(n).Cells(5).Value = v.NomProveedor
            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
            nTotPrecio = nTotPrecio + (v.Precio * v.Cantidad)
        Next
        n = gr.Rows.Add()
        n = gr.Rows.Add()

        gr.Rows(n).Cells(0).Value = "Totales"
        gr.Rows(n).Cells(0).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
        gr.Rows(n).Cells(2).Value = Format(nTotCosto, FORMATO_IMPORTE)
        gr.Rows(n).Cells(2).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
        gr.Rows(n).Cells(3).Value = Format(nTotPrecio, FORMATO_IMPORTE)
        gr.Rows(n).Cells(3).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
    End Sub

    Friend Sub CargarGrillaVentasProv(ByRef gr As DataGridView, oVentas As List(Of ITEM_VENTA_DETALLE))
        Dim v As ITEM_VENTA_DETALLE
        Dim r As DataGridViewRow
        Dim n As Integer
        Dim nTotCosto As Double

        nTotCosto = 0

        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()
            '"Codigo", "Articulo", "Costo", "Cantidad", "Subtotal"}
            gr.Rows(n).Cells(0).Value = v.IdPrenda
            gr.Rows(n).Cells(1).Value = v.NomPrenda
            gr.Rows(n).Cells(2).Value = v.Costo
            gr.Rows(n).Cells(3).Value = v.Cantidad
            gr.Rows(n).Cells(4).Value = Format(v.Costo * v.Cantidad, FORMATO_IMPORTE)
            gr.Rows(n).Cells(5).Value = Format(v.Fecha, "dd/MM/yyyy")

            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
        Next
        n = gr.Rows.Add()
        n = gr.Rows.Add()

        gr.Rows(n).Cells(0).Value = "Totales"
        gr.Rows(n).Cells(0).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
        gr.Rows(n).Cells(4).Value = Format(nTotCosto, FORMATO_IMPORTE)
        gr.Rows(n).Cells(4).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
    End Sub
    Friend Sub CargarGrillaStock(ByRef gr As DataGridView, l As Prendas)
        Dim p As Prenda
        Dim r As DataGridViewRow
        Dim n As Integer
        Dim nTotCosto, nTotPrecio As Double

        nTotCosto = 0
        nTotPrecio = 0

        gr.Rows.Clear()

        For Each p In l.Items
            r = New DataGridViewRow
            n = gr.Rows.Add()

            gr.Rows(n).Cells(0).Value = p.Id
            gr.Rows(n).Cells(1).Value = p.Descripcion
            gr.Rows(n).Cells(2).Value = p.Costo
            gr.Rows(n).Cells(3).Value = p.Precio
            gr.Rows(n).Cells(4).Value = p.Stock
            gr.Rows(n).Cells(5).Value = p.Costo * p.Stock
            gr.Rows(n).Cells(6).Value = p.Precio * p.Stock
            gr.Rows(n).Cells(7).Value = p.Status
            nTotCosto = nTotCosto + Format((p.Costo * p.Stock), FORMATO_IMPORTE)
            nTotPrecio = nTotPrecio + Format((p.Precio * p.Stock), FORMATO_IMPORTE)
        Next
        n = gr.Rows.Add()
        n = gr.Rows.Add()

        gr.Rows(n).Cells(0).Value = "Totales"
        gr.Rows(n).Cells(0).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
        gr.Rows(n).Cells(5).Value = Format(nTotCosto, FORMATO_IMPORTE)
        gr.Rows(n).Cells(5).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
        gr.Rows(n).Cells(6).Value = Format(nTotPrecio, FORMATO_IMPORTE)
        gr.Rows(n).Cells(6).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
    End Sub

    Function GrillaToPDF(sPath As String, sArchivo As String, sTitulo As String, sParametros As String, ByRef g As DataGridView) As String
        Dim sArchGenerado As String = sPath & sArchivo & ".pdf"
        Dim pdfDoc As Document
        Dim pdfTable As PdfPTable
        Dim P As Paragraph
        Dim cellvalue As String
        Dim celdaPdf As PdfPCell
        Dim i As Integer

        Dim sArchLogo As String = My.Application.Info.DirectoryPath & "\Logo.png"
        Dim oImagen As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(sArchLogo)
        oImagen.ScaleAbsolute(80, 30)

        ' Array de Columnas y sus anchos
        Dim colWidths As Single()
        ReDim colWidths(0 To g.ColumnCount - 1)
        For i = 0 To g.ColumnCount - 1
            colWidths(i) = System.Math.Round((g.Columns(i).Width / g.Width) * 100, 2)
        Next

        ' Crea tabla
        pdfTable = New PdfPTable(colWidths)
        pdfTable.WidthPercentage = 100
        pdfTable.HorizontalAlignment = Element.ALIGN_LEFT
        pdfTable.DefaultCell.Padding = 3
        pdfTable.DefaultCell.BorderWidth = 1
        pdfTable.DefaultCell.NoWrap = True

        ' Cabezales
        For Each column As DataGridViewColumn In g.Columns
            celdaPdf = New PdfPCell(New Phrase(column.HeaderText))
            celdaPdf.Phrase.Chunks(0).Font = New Font(Font.FontFamily.HELVETICA, 9, Font.BOLD)
            celdaPdf.BackgroundColor = New iTextSharp.text.BaseColor(240, 240, 240)
            pdfTable.AddCell(celdaPdf)
        Next

        ' Datos
        cellvalue = ""

        For Each row As DataGridViewRow In g.Rows
            For Each cell As DataGridViewCell In row.Cells
                cellvalue = cell.FormattedValue
                celdaPdf = New PdfPCell(New Phrase(Convert.ToString(cellvalue)))
                If celdaPdf.Phrase.Chunks.Count > 0 Then
                    celdaPdf.Phrase.Chunks(0).Font = New Font(Font.FontFamily.HELVETICA, 8)
                End If
                pdfTable.AddCell(celdaPdf)
            Next
        Next

        'Exporting to PDF

        If Not Directory.Exists(sPath) Then
            Directory.CreateDirectory(sPath)
        End If
        Using stream As New FileStream(sArchGenerado, FileMode.Create)
            pdfDoc = New Document
            PdfWriter.GetInstance(pdfDoc, stream)
            pdfDoc.Open()

            P = New Paragraph(NOMBRE_EMPRESA, FontFactory.GetFont("Arial", 7))
            P.Alignment = 1
            P.Add(oImagen)
            pdfDoc.Add(P)

            ' pdfDoc.Add(oImagen)

            P = New Paragraph(NOMBRE_EMPRESA, FontFactory.GetFont("Arial", 7))
            P.Alignment = 2
            'pdfDoc.Add(P)

            P = New Paragraph(Date.Now, FontFactory.GetFont("Arial", 7))
            P.Alignment = 2
            pdfDoc.Add(P)

            pdfDoc.AddTitle(sTitulo)

            P = New Paragraph(sTitulo, FontFactory.GetFont("Arial", 12))
            P.Alignment = 1
            pdfDoc.Add(P)
            P = New Paragraph(" ", FontFactory.GetFont("Arial", 12))
            pdfDoc.Add(P)

            P = New Paragraph(sParametros, FontFactory.GetFont("Arial", 10))
            P.Alignment = 1
            pdfDoc.Add(P)
            P = New Paragraph(" ", FontFactory.GetFont("Arial", 12))
            pdfDoc.Add(P)

            pdfDoc.Add(pdfTable)
            pdfDoc.Close()
            stream.Close()
        End Using
        Return (sArchGenerado)
    End Function

End Module
