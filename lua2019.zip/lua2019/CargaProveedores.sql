select * from DEVOLUCIONES

-- Update de los que habia
update PROVEEDORES 
set Nombre = F.[PV_NOMBRE  ], 
Mail = F.[PV_EMAIL   ],
Telefono = case when isnull(F.[PV_CELULAR ],'') = '' then F.[PV_TELEFON ] else F.[PV_CELULAR ] end,
Direccion = F.[PV_DIRECCI ],
FecIngreso = F.[PV_FECHAIN ]
from FP_PROVEEDORES F where F.[PV_NUMERO  ] = PROVEEDORES.id_proveedor


-- Agreo los que no tenia
INSERT INTO PROVEEDORES(id_proveedor, Nombre, Telefono,Mail,Direccion,FecIngreso)
select P.[PV_NUMERO  ], P.[PV_NOMBRE  ], case when isnull(P.[PV_CELULAR ],'') = '' then P.[PV_TELEFON ] else P.[PV_CELULAR ] end , 
P.[PV_EMAIL   ], P.[PV_DIRECCI ], P.[PV_FECHAIN ]
from fp_proveedores P
where P.[PV_NUMERO  ] not in (select id_proveedor from PROVEEDORES)
and P.[PV_NUMERO  ] >= 1380
order by P.[PV_NUMERO  ]


select * from PROVEEDORES where Mail <> '' order by id_proveedor

	 select * from  fp_proveedores where  isnull([PV_EMAIL   ] ,'') <> ''
	 and [PV_NUMERO  ] >= 1380
	 
	 lvergaraz@hotmail.com
	                                                   
	 select * from  fp_proveedores where  isnull([PV_DIRECCI ] ,'') <> ''
	 and [PV_NUMERO  ] >= 1380


	 SELECT P.id_prenda as IdPrenda, P.Descripcion, P.Costo, P.Precio, V.cantidad, P.id_proveedor, PR.Nombre as Proveedor, V.fec_venta as Fecha
	 FROM VENTAS V JOIN PRENDAS P ON V.id_prenda = P.id_prenda 
	 JOIN PROVEEDORES PR ON P.id_proveedor = PR.id_proveedor
	 WHERE P.id_proveedor = 1384
	 -- AND V.fec_venta >= '20200901' AND V.fec_venta < '20200919' 
	 ORDER BY V.fec_venta, P.id_prenda



	 update PROVEEDORES set Mail = ltrim(trim(Mail)), Direccion =  ltrim(trim(Direccion)), 
	 Telefono =  ltrim(trim(Telefono)), Nombre =  ltrim(trim(Nombre))
