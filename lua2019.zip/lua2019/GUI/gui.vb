﻿Imports System.IO

Public Class GUI
    Public Enum T_VISTA_LISTVIEW
        GRUPOS = 1
        LISTA = 2
    End Enum
#Region "GENERALES"

    Public Shared Function GetListaSeleccionados(lv As ListView) As String
        ' Devuelve una lista con ID's de un listview
        Dim itm As ListViewItem
        GetListaSeleccionados = ""
        For Each itm In lv.SelectedItems
            GetListaSeleccionados = GetListaSeleccionados & itm.Text & ","
        Next
        If GetListaSeleccionados.Length > 0 Then
            GetListaSeleccionados = GetListaSeleccionados.Substring(0, GetListaSeleccionados.Length - 1)
        End If

    End Function

    Public Shared Function GetLista(lv As ListView) As String
        ' Devuelve una lista con ID's de un listview
        Dim itm As ListViewItem
        GetLista = ""
        For Each itm In lv.Items
            GetLista = GetLista & itm.Text & ","
        Next
        If GetLista.Length > 0 Then
            GetLista = GetLista.Substring(0, GetLista.Length - 1)
        End If

    End Function

    Public Shared Function GetLista(lv As ListView, bSoloCheckeados As Boolean) As String
        ' Devuelve una lista con ID's de un listview
        Dim itm As ListViewItem
        GetLista = ""
        For Each itm In lv.Items
            If bSoloCheckeados And itm.Checked Then
                GetLista = GetLista & itm.Text & ","
            End If
        Next
        If GetLista.Length > 0 Then
            GetLista = GetLista.Substring(0, GetLista.Length - 1)
        End If

    End Function

    Public Shared Sub LimpiarPictureBox(ByRef p As PictureBox)
        Try
            Dim tmpImg = p.Image
            p.Image = Nothing
            If Not (tmpImg Is Nothing) Then
                tmpImg.Dispose()
                tmpImg = Nothing
            End If
        Catch
        End Try
    End Sub


    Shared Function SetTablaCodigos(ByVal l As ListView, ByVal sTabla As String, ByVal sCampoCod As String, ByVal sCampoDesc As String) As T_CLASE_CODIGOS
        Dim itm As ListViewItem
        Dim t As New T_CLASE_CODIGOS

        t.Tabla = sTabla
        t.CampoCodigo = sCampoCod
        t.CampoDesc = sCampoDesc

        For Each itm In l.Items
            t.Add(itm.Text, itm.SubItems(1).Text, itm.ImageIndex)
        Next
        Return t
    End Function
#End Region
#Region "PRENDAS"
    Public Shared Function ValidarDatos(f As frmPrendas, ByRef sError As String) As Boolean
        ValidarDatos = True
        sError = ""
        If f.NumericUpDown1.Value < 0 Then
            ValidarDatos = False
            sError = sError & "- El Stock no puede ser negativo" & vbCrLf
        End If
        If Not IsNumeric(f.txtPrecio.Text) Then
            ValidarDatos = False
            sError = sError & "- Ingrese un Precio válido" & vbCrLf
        End If
        If Not IsNumeric(f.txtCosto.Text) Then
            ValidarDatos = False
            sError = sError & "- Ingrese un Costo válido" & vbCrLf
        Else
            If CDbl(f.txtCosto.Text) <= 0 Then
                ValidarDatos = False
                sError = sError & "- El Costo debe ser > 0" & vbCrLf
            End If
        End If
        If f.lblCodProv.Text = "" Then
            ValidarDatos = False
            sError = sError & "- Debe indicar el Proveedor" & vbCrLf
        End If
        If f.txtDescripcion.TextLength < 3 Then
            ValidarDatos = False
            sError = sError & "- El nombre del articulo debe tener al menos 3 letras" & vbCrLf

        End If
    End Function

    Shared Sub HabilitarAcciones(ByRef f As frmPrendas, nEstado As T_STATUS, nCantPrendas As Integer)
        f.btnDevolver.Enabled = (nEstado = T_STATUS.DISPONIBLE Or nEstado = T_STATUS.DISPONIBLE_VENTA_ANULADA) And nCantPrendas > 0
    End Sub
    Shared Sub LimpiarCampos(ByVal f As frmPrendas)
        f.txtId.Text = ""
        f.txtDescripcion.Text = ""
        f.dtFecIngreso.Value = Date.Today
        f.lblStatus.Text = ""
        f.txtPrecio.Text = "0"
        f.txtCosto.Text = ""
        f.dtFecIngreso.BackColor = Color.White

        f.picFotoInicial.Image = Nothing
        f.btnDevolver.Enabled = False
        f.SplitContainer2.SplitterDistance = 54

        ' botones
        f.btnEliminar.Enabled = False
        f.btnGrabar.Enabled = False
    End Sub
    Shared Sub LimpiarCampos(ByVal f As frmPromos)
        f.txtId.Text = ""
        f.txtNombre.Text = ""
        f.txtDescuento.Text = ""
        f.dtDesde.Value = Date.Today
        f.dtHasta.Value = Date.Today
        f.lblPrecioFinal.Text = ""
        f.lblPrecioLista.Text = ""
        f.lblCantPrendas.Text = ""
        f.lblPrendaActual.Text = ""
        LimpiarPictureBox(f.picFotoInicial)
        f.tvPromos.Nodes.Clear()
        ' botones
        f.btnEliminar.Enabled = False
        f.btnGrabar.Enabled = False
    End Sub

    Public Shared Function ValidarDatos(ByVal f As frmPromos, ByRef sError As String) As Boolean
        ValidarDatos = True
        If f.txtDescuento.Text.Length = 0 Then
            ValidarDatos = False
            sError = "Debe ingresar un porcentaje de descuento  (0 a 100)"
        Else
            If Not IsNumeric(f.txtDescuento.Text) Then
                ValidarDatos = False
                sError = "El Descuento debe ser un numero"
            End If
        End If
    End Function
    Public Shared Function ValidarPrenda(ByVal f As frmPrendas, ByRef sError As String) As Boolean
        Dim b As Boolean = True
        If f.txtPrecio.Text.Length = 0 Then
            f.txtPrecio.Text = "0"
        End If

        If Not IsNumeric(f.txtId.Text) Then
            b = False
            sError = "El Id. de Prenda debe ser un Numero"
        End If

        Return b
    End Function
    Shared Function GetVenta(f As frmVenta) As Venta
        Dim oVenta As New Venta
        Dim itm As ListViewItem
        Dim t As Venta.T_VENTA

        oVenta.Fecha = f.dtFecha.Value

        For Each itm In f.lvDatos.Items
            t.CodPrenda = CInt(itm.Text)
            t.Cantidad = CInt(itm.SubItems(2).Text)
            t.Precio = CDbl(itm.SubItems(3).Text)
            oVenta.aArticulos.Add(t)
        Next
        Return oVenta
    End Function
    Shared Function GetPrenda(ByVal f As frmPrendas) As Prenda
        Dim itm As ListViewItem
        Dim t As Prenda.T_IMAGEN


        Dim o As New Prenda
        o.Id = CInt(f.txtId.Text)
        o.IdProveedor = CInt(f.lblCodProv.text)
        o.FecIngreso = f.dtFecIngreso.Value
        o.Precio = CDbl(f.txtPrecio.Text)
        o.Descripcion = Generales.FiltrarTexto(f.txtDescripcion.Text)
        o.Costo = CDbl(f.txtCosto.Text)
        o.Stock = CInt(f.NumericUpDown1.Value)
        If Not (f.oPrendaActual Is Nothing) Then
            o.CodStatus = f.oPrendaActual.CodStatus
        End If

        For Each itm In f.lvFotos.Items
            t.IdSec = CInt(itm.Text)
            t.Archivo = itm.SubItems(1).Text
            t.Accion = itm.Tag
            o.AddImagen(t)
        Next

        Return o

    End Function

    Public Shared Sub MostrarPromo(ByVal p As Promo, ByRef f As frmPromos)
        f.txtId.Text = p.Id
        f.dtDesde.Value = p.Desde
        f.dtHasta.Value = p.Hasta
        f.txtDescuento.Text = p.Descuento
        f.txtNombre.Text = p.Nombre

        f.lblCantPrendas.Text = p.Prendas.Items.Count
        f.lblPrecioLista.Text = Format(p.ImporteLista, FORMATO_IMPORTE)
        f.lblPrecioFinal.Text = Format(p.ImporteFinal, FORMATO_IMPORTE)
    End Sub

    Public Shared Sub MostrarPrenda(ByVal s As Prenda, ByRef f As frmPrendas)
        f.txtId.Text = s.Id
        f.dtFecIngreso.Value = s.FecIngreso
        f.lblCodProv.Text = s.IdProveedor
        f.txtPrecio.Text = s.Precio
        f.txtCosto.Text = s.Costo
        f.lblDatosStatus.Text = s.ExtraInfo
        f.dtFecIngreso.BackColor = Color.White
        f.txtNomProv.Text = s.Proveedor
        f.NumericUpDown1.Value = s.Stock

        f.lblStatus.Text = s.Status

        If s.CodStatus = T_STATUS.VENDIDA Then
            f.lblStatus.ForeColor = Color.Red
        Else
            f.lblStatus.ForeColor = Color.DarkGreen
        End If
        f.txtDescripcion.Text = s.Descripcion

        If s.Imagenes.Count > 0 Then
            MostrarImagen(f.picFotoInicial, s, s.PrimerIdImagen)
        Else
            f.picFotoInicial.Image = Nothing
        End If

        ' Cargo LV de Fotos
        Dim t As Prenda.T_IMAGEN
        Dim itm As ListViewItem

        f.lvFotos.Items.Clear()

        For Each t In s.Imagenes
            itm = New ListViewItem
            itm.Text = t.IdSec
            itm.SubItems.Add(t.Archivo)
            itm.Tag = t.Accion
            f.lvFotos.Items.Add(itm)
        Next
        LimpiarPictureBox(f.picFotoPrenda)
        f.tabFotos.Text = "Fotos (" & f.lvFotos.Items.Count & ")"

        ' Carga Promos (si hay)
        If s.Promos.Items.Count > 0 Then

        Else
        End If
        HabilitarAcciones(f, s.CodStatus, s.Stock)
    End Sub
    Public Shared Sub MostrarImagen(ByRef p As PictureBox, o As Prenda, nIdImagen As Integer)
        Dim t As Prenda.T_IMAGEN
        Dim tempImage As Image
        Dim tempBitmap As Bitmap
        Try

            p.Image = Nothing
            For Each t In o.Imagenes
                If t.IdSec = nIdImagen Then
                    System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

                    tempImage = Image.FromFile(t.Archivo)
                    tempBitmap = New Bitmap(tempImage)
                    p.Image = tempBitmap
                    tempImage.Dispose()
                    tempImage = Nothing

                    System.Windows.Forms.Cursor.Current = Cursors.Default
                    Exit Sub
                End If
            Next
        Catch ex As Exception

        End Try

    End Sub
    Friend Shared Sub MostrarPrendas(ByVal ps As Prendas, ByVal lv As ListView, sFiltroDesc As String, bDisponibles As Boolean, nProveedor As Integer, ByRef nCant As Integer, ByVal nIdPrenda As Integer, ByRef dCostoTotal As Double, ByRef dPrecioTotal As Double, vista As T_VISTA_LISTVIEW)
        ' Usado en form principal de Prendas
        Dim p As Prenda
        Dim itm As ListViewItem
        Dim g As ListViewGroup
        Dim bListar As Boolean

        lv.ShowGroups = (vista = T_VISTA_LISTVIEW.GRUPOS)

        dCostoTotal = 0
        dPrecioTotal = 0
        lv.Items.Clear()

        For Each p In ps.Items
            If IsNumeric(sFiltroDesc) Then
                bListar = p.Id = CInt(sFiltroDesc)
            Else
                bListar = p.Descripcion.ToUpper.Contains(sFiltroDesc)
            End If
            bListar = bListar And ((p.IdProveedor = nProveedor And nProveedor <> 0) Or (nProveedor = 0))
            bListar = bListar And (((p.CodStatus = T_STATUS.DISPONIBLE Or p.CodStatus = T_STATUS.DISPONIBLE_VENTA_ANULADA) And bDisponibles) Or (Not bDisponibles))
            If bListar Then
                itm = New ListViewItem
                itm.Text = p.Id
                itm.SubItems.Add(p.Descripcion)
                itm.SubItems.Add(p.Proveedor)
                itm.SubItems.Add(p.Stock)
                itm.SubItems.Add(p.Costo)
                itm.SubItems.Add(p.Precio)
                itm.SubItems.Add(p.FecIngreso)
                itm.SubItems.Add(p.CantFotos)
                itm.SubItems.Add(p.Status)

                itm.StateImageIndex = p.CodEstado - 1
                lv.Items.Add(itm)

                If p.CodStatus = T_STATUS.VENDIDA Then
                    itm.ForeColor = Color.Gray
                End If
                dPrecioTotal = dPrecioTotal + p.Precio
                dCostoTotal = dCostoTotal + p.Costo
            End If
        Next

        If nIdPrenda <> 0 Then
            For Each itm In lv.Items
                If CInt(itm.Text) = nIdPrenda Then
                    itm.EnsureVisible()
                    itm.Selected = True
                    Exit For
                End If
            Next
        End If
        nCant = lv.Items.Count
    End Sub

    Public Shared Sub MostrarPrendas(ByVal ps As Prendas, ByVal lv As ListView, ByRef lblCantidad As Label)
        ' Usado en LIQUIDACIONES
        Dim p As Prenda
        Dim itm As ListViewItem

        lv.Items.Clear()
        For Each p In ps.Items
            itm = New ListViewItem
            itm.Text = p.Id
            itm.SubItems.Add(p.Descripcion)
            itm.SubItems.Add(p.Precio)
            itm.SubItems.Add(p.Stock)
            lv.Items.Add(itm)

        Next

        If Not (lblCantidad Is Nothing) Then
            lblCantidad.Text = lv.Items.Count.ToString.Trim & " items"
        End If
    End Sub
#End Region
#Region "PROVEEDORES"
    Public Shared Function ValidarDatos(f As frmProveedores, ByRef sError As String) As Boolean
        ValidarDatos = True
        sError = ""
        If f.txtNombre.TextLength < 2 Then
            ValidarDatos = False
            sError = sError & "- El Nombre debe tener al menos 2 letras" & vbCrLf
        End If
    End Function

    Public Shared Sub MostrarProveedor(o As Proveedor, ByRef f As frmProveedores)
        f.txtId.Text = o.Id
        f.txtNombre.Text = o.Nombre
        f.txtdireccion.text = o.Direccion
        f.txtTelefono.text = o.Telefono
        f.txtmail.text = o.Mail
        f.txtFecingreso.text = o.FecIngreso

    End Sub

    Public Shared Sub MostrarProveedores(ByRef lv As ListView, oLista As Proveedores, sFiltro As String)
        Dim p As Proveedor
        Dim itm As ListViewItem
        Dim bListar As Boolean
        lv.Items.Clear()
        For Each p In oLista.Items
            If sFiltro = "" Then
                bListar = True
            Else
                If IsNumeric(sFiltro) Then
                    bListar = (p.Id = CInt(sFiltro))
                Else
                    bListar = (p.Nombre.ToUpper.Contains(sFiltro))
                End If
            End If

            If bListar Then
                itm = New ListViewItem
                itm.Text = p.Id
                itm.SubItems.Add(p.Nombre)
                itm.SubItems.Add(p.Telefono)
                itm.SubItems.Add(p.Mail)
                itm.SubItems.Add(p.Direccion)
                lv.Items.Add(itm)

            End If
        Next
    End Sub
    Shared Function GetPromo(ByVal f As frmPromos) As Promo
        Dim o As New Promo
        o.Id = CInt(f.txtId.Text)
        o.Desde = f.dtDesde.Value
        o.Hasta = f.dtHasta.Value
        o.Descuento = CDbl(f.txtDescuento.Text)
        o.Nombre = f.txtNombre.Text
        Return o
    End Function
    Shared Function GetProveedor(ByVal f As frmProveedores) As Proveedor
        Dim o As New Proveedor
        o.Id = CInt(f.txtId.Text)

        o.Nombre = FiltrarTexto(f.txtNombre.Text)
        o.Direccion = FiltrarTexto(f.txtDireccion.Text)
        o.Mail = FiltrarTexto(f.txtMail.Text)
        o.Telefono = FiltrarTexto(f.txtTelefono.Text)

        Return o
    End Function

    Shared Sub LimpiarCampos(ByVal f As frmProveedores)
        f.txtId.Text = ""
        f.txtNombre.Text = ""
        f.txtFecIngreso.Text = ""
        f.txtDireccion.Text = ""
        f.txtFiltro.Text = ""
        f.txtMail.Text = ""
        f.txtTelefono.Text = ""
    End Sub
#End Region
#Region "CLIENTES"
    Shared Sub LimpiarCampos(ByVal f As frmClientes)

        f.txtId.Text = ""
        f.txtTelefono.Text = ""
        f.txtMail.Text = ""
        f.txtDireccion.Text = ""
        f.txtCredito.Text = ""
        f.btnEliminar.Enabled = False

        If f.VieneDeVenta Then
            f.btnNuevo.Enabled = False
            f.SplitContainer1.SplitterDistance = 0
        Else
            f.txtNombre.Text = ""
            f.btnGrabar.Enabled = False
            f.SplitContainer1.SplitterDistance = 408
        End If
    End Sub
    Shared Function GetCliente(ByVal f As frmClientes) As Cliente
        Dim o As New Cliente
        o.Id = CInt(f.txtId.Text)
        o.Telefono = Generales.FiltrarTexto(f.txtTelefono.Text)
        o.Nombre = Generales.FiltrarTexto(f.txtNombre.Text)
        o.Direccion = Generales.FiltrarTexto(f.txtDireccion.Text)
        o.Mail = Generales.FiltrarTexto(f.txtMail.Text)
        Return o
    End Function

    Public Shared Sub MostrarClientes(ByRef lv As ListView, oLista As Clientes)
        Dim p As Cliente
        Dim itm As ListViewItem

        lv.Items.Clear()
        For Each p In oLista.Items
            itm = New ListViewItem
            itm.Text = p.Id
            itm.SubItems.Add(p.Nombre)
            itm.SubItems.Add(p.Telefono)
            itm.SubItems.Add(p.Mail)
            itm.SubItems.Add(p.CantCompras)
            itm.SubItems.Add(p.CantCupones)
            lv.Items.Add(itm)
        Next
    End Sub
    Public Shared Sub MostrarCliente(o As Cliente, ByRef f As frmClientes)
        f.txtId.Text = o.Id
        f.txtNombre.Text = o.Nombre
        f.txtTelefono.Text = o.Telefono
        f.txtDireccion.Text = o.Direccion
        f.txtMail.Text = o.Mail
        f.txtCredito.Text = o.Credito
    End Sub
    Public Shared Sub MostrarCupones(o As Cliente, ByRef lv As ListView)
        Dim c As Cupon
        Dim itm As ListViewItem

        lv.Items.Clear()
        For Each c In o.Cupones.Items
            itm = New ListViewItem(c.IdCupon)
            itm.SubItems.Add(c.FecEntrega)
            itm.SubItems.Add(c.PjeDescuento)
            itm.SubItems.Add(IIf(c.FecUsado = FECHA_CENTINELA, "", c.FecUsado))
            lv.Items.Add(itm)
        Next
    End Sub
    Public Shared Function ValidarDatos(f As frmClientes, ByRef sError As String) As Boolean
        ValidarDatos = True
        sError = ""
        If f.txtNombre.TextLength < 3 Then
            ValidarDatos = False
            sError = sError & "- El Cliente debe tener un Nombre" & vbCrLf
        End If
    End Function

#End Region
    Friend Shared Sub MostrarLiquidaciones(ByRef lv As ListView, ps As List(Of T_LIQUIDACION))
        Dim t As T_LIQUIDACION
        Dim itm As ListViewItem
        lv.Items.Clear()

        For Each t In ps
            itm = New ListViewItem
            itm.Text = t.IdLiq
            itm.SubItems.Add(t.NomProv)
            itm.SubItems.Add(t.Fecha)
            itm.SubItems.Add(t.Importe)
            itm.SubItems.Add(t.Comision)
            lv.Items.Add(itm)
        Next
    End Sub
    Public Shared Function UltimoId(lv As ListView) As Integer
        Dim n As Integer = 0
        For Each itm In lv.Items
            If Val(itm.text) > n Then
                n = Val(itm.text)
            End If
        Next
        Return n
    End Function

    Public Shared Sub MostrarPromos(ByVal ps As Promos, ByVal tv As TreeView)
        Dim p As Promo
        Dim nPadre, nHijo As TreeNode
        Dim r As Prenda
        Dim sTexto As String

        tv.Nodes.Clear()

        For Each p In ps.Items
            sTexto = p.Id & " - " & p.Nombre & " - " & p.Descuento & "% - " & p.Prendas.Items.Count
            sTexto = sTexto & " prenda" & IIf(p.Prendas.Items.Count > 1 Or p.Prendas.Items.Count = 0, "s", "")

            nPadre = New TreeNode(sTexto)
            nPadre.Name = p.Id
            nPadre.StateImageIndex = 0
            If p.Hasta < Date.Today Then
                nPadre.ForeColor = Color.Gray
                nPadre.StateImageIndex = 1
            End If
            tv.Nodes.Add(nPadre)
            For Each r In p.Prendas.Items
                sTexto = r.Id & " - " & r.Categoria & " - " & r.Marca & " - " & r.Tamanio & " - " & r.Precio & " $ - [" & _
                                     System.Math.Round(r.Precio * (1 - (p.Descuento / 100)), 2) & " $]"
                nHijo = New TreeNode(sTexto)
                nHijo.Name = r.Id
                nPadre.Nodes.Add(nHijo)
            Next
        Next
    End Sub
    Public Shared Sub MostrarPromos(ByVal ps As Promos, ByVal lv As ListView)
        Dim p As Promo
        Dim itm As ListViewItem

        lv.Items.Clear()
        For Each p In ps.Items
            itm = New ListViewItem
            itm.Text = p.Id
            itm.SubItems.Add(p.Nombre & "  [" & p.Desde & " - " & p.Hasta & "] - " & p.Descuento & "%")
            itm.SubItems.Add(p.Descuento)
            If p.Hasta < Date.Today Then
                itm.ForeColor = Color.Gray
            End If
            lv.Items.Add(itm)
        Next
    End Sub
End Class


