﻿Public Class frmListadosProv

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmListados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aColumnasMerc() As Tuple(Of String, String) = {New Tuple(Of String, String)("Codigo", "C"), New Tuple(Of String, String)("Articulo", "I"),
                New Tuple(Of String, String)("Costo", "D"), New Tuple(Of String, String)("Stock", "D"), New Tuple(Of String, String)("SubTotal", "D"),
                New Tuple(Of String, String)("Estado", "C")}

        Dim aColumnasVentas() As Tuple(Of String, String) = {New Tuple(Of String, String)("Fecha", "C"), New Tuple(Of String, String)("Codigo", "C"), New Tuple(Of String, String)("Articulo", "I"),
                New Tuple(Of String, String)("Costo", "D"), New Tuple(Of String, String)("Cantidad", "D"),
                New Tuple(Of String, String)("Subtotal", "D")}

        Dim aColumnasDevoluciones() As Tuple(Of String, String) = {New Tuple(Of String, String)("Fecha", "C"), New Tuple(Of String, String)("Codigo", "C"),
                New Tuple(Of String, String)("Articulo", "I"), New Tuple(Of String, String)("Costo", "D"),
                New Tuple(Of String, String)("Cantidad", "D"), New Tuple(Of String, String)("Subtotal", "D")}

        Me.lblStatus.Text = ""

        Me.dtDesde.Value = Date.Today
        Me.dtDesde.Value = DateAdd(DateInterval.Day, 1 - (Me.dtDesde.Value.Day), Me.dtDesde.Value)

        InitGrilla(Me.grDatosMerc, aColumnasMerc)
        InitGrilla(Me.grDatosVentas, aColumnasVentas)
        InitGrilla(Me.grDevoluciones, aColumnasDevoluciones)
        Me.txtNomProv.Focus()
    End Sub

    Private Sub txtNomProv_Leave(sender As Object, e As EventArgs) Handles txtNomProv.Leave
        Dim sMail As String
        Me.txtNomProv.BackColor = Color.White
        If Me.txtNomProv.Text <> "" Then
            CargarProveedor(Me.lblCodProv, Me.txtNomProv, sMail)
            Me.txtMail.Text = sMail
        End If

        If Me.lblCodProv.Text <> "" Then
            CargarDatos(CInt(Me.lblCodProv.Text))
        End If
    End Sub

    Sub CargarDatos(nIdProv As Integer)
        Dim oStock As Prendas
        Dim oListaVentas As List(Of ITEM_VENTA_DETALLE)
        Dim oListaDevol As List(Of ITEM_DEVOLUCION)
        Dim sFiltro As String

        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

        oStock = oHandler.CargarPrendas("P.id_proveedor = " & nIdProv.ToString, 2)
        CargarGrillaStockProv(Me.grDatosMerc, oStock)

        sFiltro = "P.id_proveedor = " & nIdProv.ToString & " AND V.fec_venta >= " & Comillas(FechaUniversal(Me.dtDesde.Value)) & " AND V.fec_venta < " & Comillas(FechaUniversal(DateAdd(DateInterval.Day, 1, Me.dtHasta.Value)))

        oListaVentas = oHandlerRep.GetVentasDetalle(sfiltro)
        CargarGrillaVentasProv(Me.grDatosVentas, oListaVentas)

        oListaDevol = oHandlerRep.GetDevoluciones("P.id_proveedor = " & nIdProv.ToString)
        CargarGrillaDevoluciones(Me.grDevoluciones, oListaDevol)

        System.Windows.Forms.Cursor.Current = Cursors.Default

        Me.tabVentas.Text = "Ventas (" & oListaVentas.Count & ")"
        Me.tabMercaderia.Text = "Mercadería (" & oStock.Items.Count & ")"
        Me.tabDevoluciones.Text = "Devoluciones (" & oListaDevol.Count & ")"
    End Sub

    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        mnuAcciones.Show(System.Windows.Forms.Cursor.Position)
    End Sub

    Private Sub ToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles mnuListaTodos.Click
        ListarMercaderia()
        ListarVentas()
        ListarDevoluciones()
    End Sub

    Private Sub mnuListaVentas_Click(sender As Object, e As EventArgs) Handles mnuListaVentas.Click
        ListarVentas()
    End Sub
    Private Sub mnuListaMercaderia_Click(sender As Object, e As EventArgs) Handles mnuListaMercaderia.Click
        ListarMercaderia()
    End Sub
    Sub ListarMercaderia()
        Dim sArchivoGenerado As String

        Try
            sArchivoGenerado = GrillaToPDF(CARPETA_REPORTES, "Stock_" & Me.lblCodProv.Text, "Stock de Mercadería ", "Proveedor " & Me.txtNomProv.Text, Me.grDatosMerc)

            If Me.chkMail.Checked And Me.txtMail.Text <> "" Then
                Me.lblStatus.Text = "Enviando mail a " & Me.txtMail.Text & " ..."
                Reportes.MandaMail(Me.txtMail.Text, "Su stock de mercaderia en " & NOMBRE_EMPRESA, "Gracias por trabajar con nosotros.", sArchivoGenerado)
            End If
            MostrarArchivo(sArchivoGenerado)
            Me.lblStatus.Text = "Archivo " & sArchivoGenerado & " generado"
        Catch ex As Exception
            MsgBox("Error a generar : " & ex.Message)
        End Try

    End Sub
    Sub ListarVentas()
        Dim sArchivoGenerado As String
        Dim sFechaFSDesde, sFechaFSHasta, sParametros As String

        Try
            sFechaFSDesde = FechaUniversal(Me.dtDesde.Value)
            sFechaFSHasta = FechaUniversal(Me.dtHasta.Value)

            sParametros = "Proveedor " & Me.txtNomProv.Text & " - Del " & Format(Me.dtDesde.Value, "dd/MM/yyyy") & " al " & Format(Me.dtHasta.Value, "dd/MM/yyyy")

            sArchivoGenerado = GrillaToPDF(CARPETA_REPORTES, "Ventas_" & Me.lblCodProv.Text & "_" & sFechaFSDesde & "_" & sFechaFSHasta, "Listado de Ventas", sParametros, Me.grDatosVentas)

            If Me.chkMail.Checked And Me.txtMail.Text <> "" Then
                Me.lblStatus.Text = "Enviando mail a " & Me.txtMail.Text & " ..."
                Reportes.MandaMail(Me.txtMail.Text, "Sus ventas en " & NOMBRE_EMPRESA, sParametros, sArchivoGenerado)
            End If
            MostrarArchivo(sArchivoGenerado)
            Me.lblStatus.Text = "Archivo " & sArchivoGenerado & " generado"
        Catch ex As Exception
            MsgBox("Error a generar : " & ex.Message)
        End Try
    End Sub

    Private Sub txtNomProv_TextChanged(sender As Object, e As EventArgs) Handles txtNomProv.TextChanged

    End Sub

    Private Sub btnCargar_Click(sender As Object, e As EventArgs) Handles btnCargar.Click
        If Me.lblCodProv.Text <> "" Then
            CargarDatos(CInt(Me.lblCodProv.Text))
        End If
    End Sub

    Private Sub DevolucionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DevolucionesToolStripMenuItem.Click
        ListarDevoluciones()
    End Sub
    Sub ListarDevoluciones()
        Dim sArchivoGenerado As String
        Dim sParametros As String

        Try

            sParametros = "Proveedor " & Me.txtNomProv.Text

            sArchivoGenerado = GrillaToPDF(CARPETA_REPORTES, "Devoluciones_" & Me.lblCodProv.Text, "Devoluciones al Proveedor", sParametros, Me.grDatosVentas)

            If Me.chkMail.Checked And Me.txtMail.Text <> "" Then
                Me.lblStatus.Text = "Enviando mail a " & Me.txtMail.Text & " ..."
                Reportes.MandaMail(Me.txtMail.Text, "Mercaderia que le hemos devuelto en " & NOMBRE_EMPRESA, sParametros, sArchivoGenerado)
            End If
            MostrarArchivo(sArchivoGenerado)
            Me.lblStatus.Text = "Archivo " & sArchivoGenerado & " generado"
        Catch ex As Exception
            MsgBox("Error a generar : " & ex.Message)
        End Try
    End Sub

    Private Sub txtNomProv_Enter(sender As Object, e As EventArgs) Handles txtNomProv.Enter
        Me.txtNomProv.BackColor = COLOR_SETEADO
    End Sub
End Class