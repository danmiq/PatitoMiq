Public Class frmLista

    Public Filtro As String
    Public Id As Long = 0
    Public Nombre As String = ""
    Public oLista As Object
    Public Tabla As String

    Sub MostrarDatos()
        If Me.Tabla = TABLA_PROVEEDORES Then
            GUI.MostrarProveedores(Me.lvDatos, oLista, "")
        End If
        If Me.Tabla = TABLA_CLIENTES Then
            GUI.MostrarClientes(Me.lvDatos, oLista)
        End If
        If Me.Tabla = TABLA_PRENDAS Then
            Me.lvDatos.Columns.Add("Precio")
            Me.lvDatos.Columns.Add("Stock")
            GUI.MostrarPrendas(oLista, Me.lvDatos, Me.lblCantItems)
        End If
    End Sub

    Public Sub CargarLista(sFiltro As String)
        If Me.Tabla = TABLA_PROMOS Then
            oLista = oHandler.CargarPromos()
            ' GUI.MostrarPromos(Me.lvDatos, oLista, sFiltro)
        End If
    End Sub

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.DialogResult = Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub frmLista_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Filtro = ""
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me.Id = CLng(Me.lvDatos.SelectedItems(0).Text)
        Me.Nombre = Me.lvDatos.SelectedItems(0).SubItems(1).Text
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub lvDatos_ItemActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvDatos.ItemActivate
        Me.Id = CLng(Me.lvDatos.SelectedItems(0).Text)
        Me.Nombre = Me.lvDatos.SelectedItems(0).SubItems(1).Text
        Me.DialogResult = Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

End Class