﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListadosProv
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmListadosProv))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.panelVentas = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtHasta = New System.Windows.Forms.DateTimePicker()
        Me.dtDesde = New System.Windows.Forms.DateTimePicker()
        Me.lblCodProv = New System.Windows.Forms.Label()
        Me.txtNomProv = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tabContenedor = New System.Windows.Forms.TabControl()
        Me.tabMercaderia = New System.Windows.Forms.TabPage()
        Me.grDatosMerc = New System.Windows.Forms.DataGridView()
        Me.tabVentas = New System.Windows.Forms.TabPage()
        Me.grDatosVentas = New System.Windows.Forms.DataGridView()
        Me.tabDevoluciones = New System.Windows.Forms.TabPage()
        Me.grDevoluciones = New System.Windows.Forms.DataGridView()
        Me.btnListar = New System.Windows.Forms.Button()
        Me.mnuAcciones = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuListaMercaderia = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuListaVentas = New System.Windows.Forms.ToolStripMenuItem()
        Me.DevolucionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuListaTodos = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkMail = New System.Windows.Forms.CheckBox()
        Me.txtMail = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCargar = New System.Windows.Forms.Button()
        Me.panelVentas.SuspendLayout()
        Me.tabContenedor.SuspendLayout()
        Me.tabMercaderia.SuspendLayout()
        CType(Me.grDatosMerc, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabVentas.SuspendLayout()
        CType(Me.grDatosVentas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabDevoluciones.SuspendLayout()
        CType(Me.grDevoluciones, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuAcciones.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(689, 431)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(73, 36)
        Me.btnSalir.TabIndex = 7
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatus.ForeColor = System.Drawing.Color.Navy
        Me.lblStatus.Location = New System.Drawing.Point(11, 434)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(370, 23)
        Me.lblStatus.TabIndex = 8
        '
        'panelVentas
        '
        Me.panelVentas.Controls.Add(Me.Label2)
        Me.panelVentas.Controls.Add(Me.dtHasta)
        Me.panelVentas.Controls.Add(Me.dtDesde)
        Me.panelVentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.panelVentas.Location = New System.Drawing.Point(11, 31)
        Me.panelVentas.Name = "panelVentas"
        Me.panelVentas.Size = New System.Drawing.Size(325, 26)
        Me.panelVentas.TabIndex = 51
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(2, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 13)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Ventas entre"
        '
        'dtHasta
        '
        Me.dtHasta.CustomFormat = "dd/MM/yyyy"
        Me.dtHasta.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtHasta.Location = New System.Drawing.Point(208, 4)
        Me.dtHasta.Name = "dtHasta"
        Me.dtHasta.Size = New System.Drawing.Size(114, 20)
        Me.dtHasta.TabIndex = 1
        '
        'dtDesde
        '
        Me.dtDesde.CustomFormat = "dd/MM/yyyy"
        Me.dtDesde.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtDesde.Location = New System.Drawing.Point(87, 3)
        Me.dtDesde.Name = "dtDesde"
        Me.dtDesde.Size = New System.Drawing.Size(114, 20)
        Me.dtDesde.TabIndex = 0
        '
        'lblCodProv
        '
        Me.lblCodProv.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCodProv.Location = New System.Drawing.Point(75, 5)
        Me.lblCodProv.Name = "lblCodProv"
        Me.lblCodProv.Size = New System.Drawing.Size(54, 20)
        Me.lblCodProv.TabIndex = 95
        Me.lblCodProv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtNomProv
        '
        Me.txtNomProv.Location = New System.Drawing.Point(135, 5)
        Me.txtNomProv.Name = "txtNomProv"
        Me.txtNomProv.Size = New System.Drawing.Size(309, 20)
        Me.txtNomProv.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 94
        Me.Label7.Text = "Proveedor"
        '
        'tabContenedor
        '
        Me.tabContenedor.Controls.Add(Me.tabMercaderia)
        Me.tabContenedor.Controls.Add(Me.tabVentas)
        Me.tabContenedor.Controls.Add(Me.tabDevoluciones)
        Me.tabContenedor.Location = New System.Drawing.Point(0, 61)
        Me.tabContenedor.Name = "tabContenedor"
        Me.tabContenedor.SelectedIndex = 0
        Me.tabContenedor.Size = New System.Drawing.Size(777, 366)
        Me.tabContenedor.TabIndex = 97
        '
        'tabMercaderia
        '
        Me.tabMercaderia.Controls.Add(Me.grDatosMerc)
        Me.tabMercaderia.Location = New System.Drawing.Point(4, 22)
        Me.tabMercaderia.Name = "tabMercaderia"
        Me.tabMercaderia.Padding = New System.Windows.Forms.Padding(3)
        Me.tabMercaderia.Size = New System.Drawing.Size(769, 340)
        Me.tabMercaderia.TabIndex = 0
        Me.tabMercaderia.Text = "Mercadería"
        Me.tabMercaderia.UseVisualStyleBackColor = True
        '
        'grDatosMerc
        '
        Me.grDatosMerc.AllowUserToAddRows = False
        Me.grDatosMerc.AllowUserToDeleteRows = False
        Me.grDatosMerc.AllowUserToOrderColumns = True
        Me.grDatosMerc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.grDatosMerc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grDatosMerc.DefaultCellStyle = DataGridViewCellStyle1
        Me.grDatosMerc.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grDatosMerc.Location = New System.Drawing.Point(3, 3)
        Me.grDatosMerc.Name = "grDatosMerc"
        Me.grDatosMerc.ReadOnly = True
        Me.grDatosMerc.Size = New System.Drawing.Size(763, 334)
        Me.grDatosMerc.TabIndex = 105
        '
        'tabVentas
        '
        Me.tabVentas.Controls.Add(Me.grDatosVentas)
        Me.tabVentas.Location = New System.Drawing.Point(4, 22)
        Me.tabVentas.Name = "tabVentas"
        Me.tabVentas.Padding = New System.Windows.Forms.Padding(3)
        Me.tabVentas.Size = New System.Drawing.Size(769, 340)
        Me.tabVentas.TabIndex = 1
        Me.tabVentas.Text = "Ventas"
        Me.tabVentas.UseVisualStyleBackColor = True
        '
        'grDatosVentas
        '
        Me.grDatosVentas.AllowUserToAddRows = False
        Me.grDatosVentas.AllowUserToDeleteRows = False
        Me.grDatosVentas.AllowUserToOrderColumns = True
        Me.grDatosVentas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grDatosVentas.DefaultCellStyle = DataGridViewCellStyle2
        Me.grDatosVentas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grDatosVentas.Location = New System.Drawing.Point(3, 3)
        Me.grDatosVentas.Name = "grDatosVentas"
        Me.grDatosVentas.ReadOnly = True
        Me.grDatosVentas.Size = New System.Drawing.Size(763, 334)
        Me.grDatosVentas.TabIndex = 106
        '
        'tabDevoluciones
        '
        Me.tabDevoluciones.Controls.Add(Me.grDevoluciones)
        Me.tabDevoluciones.Location = New System.Drawing.Point(4, 22)
        Me.tabDevoluciones.Name = "tabDevoluciones"
        Me.tabDevoluciones.Padding = New System.Windows.Forms.Padding(3)
        Me.tabDevoluciones.Size = New System.Drawing.Size(769, 340)
        Me.tabDevoluciones.TabIndex = 2
        Me.tabDevoluciones.Text = "Devoluciones"
        Me.tabDevoluciones.UseVisualStyleBackColor = True
        '
        'grDevoluciones
        '
        Me.grDevoluciones.AllowUserToAddRows = False
        Me.grDevoluciones.AllowUserToDeleteRows = False
        Me.grDevoluciones.AllowUserToOrderColumns = True
        Me.grDevoluciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grDevoluciones.DefaultCellStyle = DataGridViewCellStyle3
        Me.grDevoluciones.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grDevoluciones.Location = New System.Drawing.Point(3, 3)
        Me.grDevoluciones.Name = "grDevoluciones"
        Me.grDevoluciones.ReadOnly = True
        Me.grDevoluciones.Size = New System.Drawing.Size(763, 334)
        Me.grDevoluciones.TabIndex = 107
        '
        'btnListar
        '
        Me.btnListar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnListar.ContextMenuStrip = Me.mnuAcciones
        Me.btnListar.Location = New System.Drawing.Point(501, 433)
        Me.btnListar.Name = "btnListar"
        Me.btnListar.Size = New System.Drawing.Size(73, 24)
        Me.btnListar.TabIndex = 0
        Me.btnListar.Text = "Exportar"
        Me.btnListar.UseVisualStyleBackColor = True
        '
        'mnuAcciones
        '
        Me.mnuAcciones.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuListaMercaderia, Me.mnuListaVentas, Me.DevolucionesToolStripMenuItem, Me.ToolStripSeparator1, Me.mnuListaTodos})
        Me.mnuAcciones.Name = "mnuAcciones"
        Me.mnuAcciones.Size = New System.Drawing.Size(146, 98)
        '
        'mnuListaMercaderia
        '
        Me.mnuListaMercaderia.Name = "mnuListaMercaderia"
        Me.mnuListaMercaderia.Size = New System.Drawing.Size(145, 22)
        Me.mnuListaMercaderia.Text = "Mercadería"
        '
        'mnuListaVentas
        '
        Me.mnuListaVentas.Name = "mnuListaVentas"
        Me.mnuListaVentas.Size = New System.Drawing.Size(145, 22)
        Me.mnuListaVentas.Text = "Ventas"
        '
        'DevolucionesToolStripMenuItem
        '
        Me.DevolucionesToolStripMenuItem.Name = "DevolucionesToolStripMenuItem"
        Me.DevolucionesToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.DevolucionesToolStripMenuItem.Text = "Devoluciones"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(142, 6)
        '
        'mnuListaTodos
        '
        Me.mnuListaTodos.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnuListaTodos.Name = "mnuListaTodos"
        Me.mnuListaTodos.Size = New System.Drawing.Size(145, 22)
        Me.mnuListaTodos.Text = "Todos"
        '
        'chkMail
        '
        Me.chkMail.AutoSize = True
        Me.chkMail.Location = New System.Drawing.Point(417, 437)
        Me.chkMail.Name = "chkMail"
        Me.chkMail.Size = New System.Drawing.Size(78, 17)
        Me.chkMail.TabIndex = 2
        Me.chkMail.Text = "Enviar Mail"
        Me.chkMail.UseVisualStyleBackColor = True
        '
        'txtMail
        '
        Me.txtMail.Location = New System.Drawing.Point(517, 6)
        Me.txtMail.Name = "txtMail"
        Me.txtMail.Size = New System.Drawing.Size(242, 20)
        Me.txtMail.TabIndex = 101
        Me.txtMail.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(477, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 102
        Me.Label1.Text = "e-mail"
        '
        'btnCargar
        '
        Me.btnCargar.Location = New System.Drawing.Point(375, 31)
        Me.btnCargar.Name = "btnCargar"
        Me.btnCargar.Size = New System.Drawing.Size(69, 26)
        Me.btnCargar.TabIndex = 103
        Me.btnCargar.Text = "Cargar"
        Me.btnCargar.UseVisualStyleBackColor = True
        '
        'frmListadosProv
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(774, 469)
        Me.Controls.Add(Me.btnCargar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtMail)
        Me.Controls.Add(Me.btnListar)
        Me.Controls.Add(Me.chkMail)
        Me.Controls.Add(Me.tabContenedor)
        Me.Controls.Add(Me.panelVentas)
        Me.Controls.Add(Me.lblCodProv)
        Me.Controls.Add(Me.txtNomProv)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.btnSalir)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmListadosProv"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Listados"
        Me.panelVentas.ResumeLayout(False)
        Me.panelVentas.PerformLayout()
        Me.tabContenedor.ResumeLayout(False)
        Me.tabMercaderia.ResumeLayout(False)
        CType(Me.grDatosMerc, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabVentas.ResumeLayout(False)
        CType(Me.grDatosVentas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabDevoluciones.ResumeLayout(False)
        CType(Me.grDevoluciones, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuAcciones.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents panelVentas As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtHasta As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtDesde As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblCodProv As System.Windows.Forms.Label
    Friend WithEvents txtNomProv As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents tabContenedor As System.Windows.Forms.TabControl
    Friend WithEvents tabMercaderia As System.Windows.Forms.TabPage
    Friend WithEvents tabVentas As System.Windows.Forms.TabPage
    Friend WithEvents grDatosMerc As System.Windows.Forms.DataGridView
    Friend WithEvents btnListar As System.Windows.Forms.Button
    Friend WithEvents chkMail As System.Windows.Forms.CheckBox
    Friend WithEvents txtMail As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grDatosVentas As DataGridView
    Friend WithEvents mnuAcciones As ContextMenuStrip
    Friend WithEvents mnuListaMercaderia As ToolStripMenuItem
    Friend WithEvents mnuListaVentas As ToolStripMenuItem
    Friend WithEvents mnuListaTodos As ToolStripMenuItem
    Friend WithEvents btnCargar As Button
    Friend WithEvents tabDevoluciones As TabPage
    Friend WithEvents grDevoluciones As DataGridView
    Friend WithEvents DevolucionesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
End Class
