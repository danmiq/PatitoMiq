﻿Public Class Cupon
    Private nId As Integer

    Public Property IdCupon() As Integer
        Get
            Return nId
        End Get
        Set(ByVal value As Integer)
            nId = value
        End Set
    End Property

    Private dFecEntrega As Date
    Private dFecUsado As Date
    Private nIdCliente As Integer
    Private dPjeDescuento As Double


    Public Property FecEntrega() As Date
        Get
            Return dFecEntrega
        End Get
        Set(ByVal value As Date)
            dFecEntrega = value
        End Set
    End Property
    Public Property FecUsado() As Date
        Get
            Return dFecUsado
        End Get
        Set(ByVal value As Date)
            dFecUsado = value
        End Set
    End Property

    Public Property IdCliente() As Integer
        Get
            Return nIdCliente
        End Get
        Set(ByVal value As Integer)
            nIdCliente = value
        End Set
    End Property

    Public Property PjeDescuento() As Double
        Get
            Return dPjeDescuento
        End Get
        Set(ByVal value As Double)
            dPjeDescuento = value
        End Set
    End Property
End Class
