﻿Public Class frmLiquidaciones
    Dim oLista As Prendas
    Dim nTotImporte As Double
    Dim dPjeComis As Double
    Dim oLiqs As List(Of T_LIQUIDACION)

    Private Sub frmLiquidaciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        oHandler.CargarCombo(Me.cboProveedor, TABLA_PROVEEDORES, "id_proveedor", "Nombre", "")
        oHandler.CargarCombo(Me.cboComisiones, "COMISIONES", "cod_comision", "pje_comision", "")
        oLiqs = oHandler.CargarLiquidaciones()
        GUI.MostrarLiquidaciones(Me.ListView1, oLiqs)
        Me.chkUsarOtra.Checked = False
        Me.cboComisiones.Enabled = False

    End Sub

    Private Sub tnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub cboProveedor_Leave(sender As Object, e As EventArgs) Handles cboProveedor.Leave
        Dim oProv As Proveedor
        oProv = oHandler.CargarProveedor(Me.cboProveedor.SelectedValue)


        oLista = oHandler.CargarPrendas("P.cod_status = " & T_STATUS.VENDIDA & " and P.id_proveedor = " & Me.cboProveedor.SelectedValue, 2)

        GUI.MostrarPrendas(oLista, Me.lvPrendas, Me.lblCantidad)
        If oLista.Count = 0 Then
            MsgBox(cboProveedor.Text & " no tiene ventas pendientes de pagar", vbExclamation)
        End If
        dPjeComis = IIf(Me.chkUsarOtra.Checked, CDbl(Me.cboComisiones.Text), CDbl(Me.lblComisionProv.Text))
        Recalcular(dPjeComis)
    End Sub
    Function GetTotal(lv As ListView) As Double
        Dim itm As ListViewItem

        GetTotal = 0
        For Each itm In lv.Items
            GetTotal = GetTotal + CDbl(itm.SubItems(3).Text)
        Next
    End Function

    Sub Recalcular(dPjecomis As Double)
        nTotImporte = GetTotal(Me.lvPrendas)
        Me.lblImpVendido.Text = nTotImporte

        nTotImporte = nTotImporte * dPjecomis / 100
        Me.lblImpPagar.Text = nTotImporte

    End Sub

    Private Sub chkUsarOtra_CheckedChanged(sender As Object, e As EventArgs) Handles chkUsarOtra.CheckedChanged
        Me.cboComisiones.Enabled = Me.chkUsarOtra.Checked
    End Sub

    Private Sub btnRecalcular_Click(sender As Object, e As EventArgs) Handles btnRecalcular.Click
        dPjeComis = IIf(Me.chkUsarOtra.Checked, CDbl(Me.cboComisiones.Text), CDbl(Me.lblComisionProv.Text))
        Recalcular(dPjeComis)
    End Sub

    Private Sub btnGenerar_Click(sender As Object, e As EventArgs) Handles btnGenerar.Click
        Dim sError As String
        Dim sListaPrendas As String

        If MsgBox("¿ Liquida la Comisión para estas prendas ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = vbYes Then
            sListaPrendas = gui.getlista(Me.lvPrendas)

            If oHandler.Liquidar(Me.cboProveedor.SelectedValue, nTotImporte, dPjeComis, sListaPrendas, sError) Then
                MsgBox("Proceso finalizado", MsgBoxStyle.Information)
                oLiqs = oHandler.CargarLiquidaciones()
                GUI.MostrarLiquidaciones(Me.ListView1, oLiqs)
            Else
                MsgBox("Error al Liquidar : " & sError, MsgBoxStyle.Critical)
            End If
        End If
    End Sub
End Class
