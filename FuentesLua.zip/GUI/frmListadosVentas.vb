﻿
Public Class frmListadosVentas

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Dim l As List(Of ITEM_VENTA_RESUMEN)
        Dim itm As ListViewItem

        l = oHandlerRep.GetVentasTotal(Me.dtDesde.Value, Me.dtHasta.Value)
        Me.lvDatos.Items.Clear()
        For Each v In l
            itm = Me.lvDatos.Items.Add(v.Fecha)
            itm.SubItems.Add(v.ImporteCompra)
            itm.SubItems.Add(v.ImporteVenta)
            itm.SubItems.Add(v.Cantidad)
        Next

    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmListadosVentas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aColumnas() As Tuple(Of String, String) = {New Tuple(Of String, String)("Codigo", "C"), New Tuple(Of String, String)("Articulo", "I"),
                New Tuple(Of String, String)("Cantidad", "D"), New Tuple(Of String, String)("Costo", "D"), New Tuple(Of String, String)("Precio", "D"),
                New Tuple(Of String, String)("SubTotCosto", "D"), New Tuple(Of String, String)("SubTotPrecio", "D"),
                New Tuple(Of String, String)("Proveedor", "I")}

        Me.dtDesde.Value = Date.Today
        Me.dtDesde.Value = DateAdd(DateInterval.Day, 1 - (Me.dtDesde.Value.Day), Me.dtDesde.Value)
        InitGrilla(Me.grDatos, aColumnas)
    End Sub

    Private Sub lvDatos_ItemActivate(sender As Object, e As EventArgs) Handles lvDatos.ItemActivate
        Dim oVentas As List(Of ITEM_VENTA_DETALLE)
        Dim sFiltro As String
        Dim dFecha As Date

        If Me.lvDatos.SelectedItems.Count > 0 Then
            dFecha = CDate(Me.lvDatos.SelectedItems(0).Text)
            sFiltro = "V.fec_venta >= " & Comillas(FechaUniversal(dFecha)) & " AND V.fec_venta <  " & Comillas(FechaUniversal(DateAdd(DateInterval.Day, 1, dFecha)))
            oVentas = oHandlerRep.GetVentasDetalle(sFiltro)
            CargarGrillaVentasEmpresa(Me.grDatos, oVentas)
        End If
    End Sub

    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        Dim sFecha, sFechaFS, sArchivoGenerado As String

        Try

            If Me.lvDatos.SelectedItems.Count > 0 Then
                sFecha = Me.lvDatos.SelectedItems(0).Text
                sFechaFS = FechaUniversal(sFecha)
                sArchivoGenerado = GrillaToPDF(CARPETA_REPORTES, "Ventas_" & sFechaFS, "Listado de Ventas", "Ventas del dia " & sFecha, Me.grDatos)

                ' sArchivoGenerado = Reportes.GrillaAExcel(Me.grDatos, CARPETA_REPORTES, "Ventas_" & sFecha, "Listado de Ventas", sFecha)

                MostrarArchivo(sArchivoGenerado)
            Else
                MsgBox("Debe elegir una fecha de la lista", MsgBoxStyle.OkOnly)
                Me.lvDatos.Focus()
            End If
        Catch ex As Exception
            MsgBox("Error a listar : " & ex.Message)
        End Try

    End Sub

    Private Sub lvDatos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDatos.SelectedIndexChanged

    End Sub
End Class