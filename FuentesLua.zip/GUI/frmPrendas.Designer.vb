<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPrendas
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPrendas))
        Me.btnNuevo = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.splitMain = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.lblCodProvBusqueda = New System.Windows.Forms.Label()
        Me.txtProveedorBusqueda = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnLimpiarFiltros = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnAplicarFiltro = New System.Windows.Forms.Button()
        Me.txtFiltro = New System.Windows.Forms.TextBox()
        Me.chkDisponibles = New System.Windows.Forms.CheckBox()
        Me.lvDatos = New System.Windows.Forms.ListView()
        Me.id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Descripcion = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Proveedor = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Stock = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Costo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Precio = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.FecIngreso = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colfotos = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colStatus = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.imgListaBotones = New System.Windows.Forms.ImageList(Me.components)
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabGeneral = New System.Windows.Forms.TabPage()
        Me.lblCodProv = New System.Windows.Forms.Label()
        Me.txtNomProv = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtCosto = New System.Windows.Forms.TextBox()
        Me.lblDatosStatus = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.btnDevolver = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDescripcion = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPrecio = New System.Windows.Forms.TextBox()
        Me.picFotoInicial = New System.Windows.Forms.PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.dtFecIngreso = New System.Windows.Forms.DateTimePicker()
        Me.tabFotos = New System.Windows.Forms.TabPage()
        Me.lvFotos = New System.Windows.Forms.ListView()
        Me.colId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colArchivoFoto = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.mnuAccionesImagenes = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.BorrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnFotos = New System.Windows.Forms.Button()
        Me.picFotoPrenda = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtId = New System.Windows.Forms.TextBox()
        Me.mnuAccionesPrendas = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AgregarAPromoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnGrabar = New System.Windows.Forms.Button()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.lblCantItems = New System.Windows.Forms.Label()
        Me.lblUltimoId = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.lblPrecioTotal = New System.Windows.Forms.Label()
        Me.lblCostoTotal = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.splitMain.Panel1.SuspendLayout()
        Me.splitMain.Panel2.SuspendLayout()
        Me.splitMain.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tabGeneral.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFotoInicial, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabFotos.SuspendLayout()
        Me.mnuAccionesImagenes.SuspendLayout()
        CType(Me.picFotoPrenda, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuAccionesPrendas.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnNuevo
        '
        Me.btnNuevo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNuevo.Image = CType(resources.GetObject("btnNuevo.Image"), System.Drawing.Image)
        Me.btnNuevo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnNuevo.Location = New System.Drawing.Point(669, 467)
        Me.btnNuevo.Name = "btnNuevo"
        Me.btnNuevo.Size = New System.Drawing.Size(85, 41)
        Me.btnNuevo.TabIndex = 7
        Me.btnNuevo.Text = "Nuevo"
        Me.btnNuevo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnNuevo.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(942, 467)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(85, 41)
        Me.btnSalir.TabIndex = 6
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'splitMain
        '
        Me.splitMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.splitMain.Dock = System.Windows.Forms.DockStyle.Top
        Me.splitMain.Location = New System.Drawing.Point(0, 0)
        Me.splitMain.Name = "splitMain"
        '
        'splitMain.Panel1
        '
        Me.splitMain.Panel1.Controls.Add(Me.SplitContainer2)
        '
        'splitMain.Panel2
        '
        Me.splitMain.Panel2.Controls.Add(Me.TabControl1)
        Me.splitMain.Panel2.Controls.Add(Me.Label3)
        Me.splitMain.Panel2.Controls.Add(Me.txtId)
        Me.splitMain.Size = New System.Drawing.Size(1039, 461)
        Me.splitMain.SplitterDistance = 528
        Me.splitMain.TabIndex = 5
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.lblCodProvBusqueda)
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtProveedorBusqueda)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Label12)
        Me.SplitContainer2.Panel1.Controls.Add(Me.btnLimpiarFiltros)
        Me.SplitContainer2.Panel1.Controls.Add(Me.Label8)
        Me.SplitContainer2.Panel1.Controls.Add(Me.btnAplicarFiltro)
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtFiltro)
        Me.SplitContainer2.Panel1.Controls.Add(Me.chkDisponibles)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.lvDatos)
        Me.SplitContainer2.Size = New System.Drawing.Size(524, 457)
        Me.SplitContainer2.SplitterDistance = 61
        Me.SplitContainer2.TabIndex = 2
        '
        'lblCodProvBusqueda
        '
        Me.lblCodProvBusqueda.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCodProvBusqueda.Location = New System.Drawing.Point(64, 36)
        Me.lblCodProvBusqueda.Name = "lblCodProvBusqueda"
        Me.lblCodProvBusqueda.Size = New System.Drawing.Size(54, 17)
        Me.lblCodProvBusqueda.TabIndex = 94
        Me.lblCodProvBusqueda.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtProveedorBusqueda
        '
        Me.txtProveedorBusqueda.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProveedorBusqueda.Location = New System.Drawing.Point(124, 36)
        Me.txtProveedorBusqueda.Name = "txtProveedorBusqueda"
        Me.txtProveedorBusqueda.Size = New System.Drawing.Size(243, 18)
        Me.txtProveedorBusqueda.TabIndex = 93
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(4, 37)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(48, 12)
        Me.Label12.TabIndex = 48
        Me.Label12.Text = "Proveedor"
        '
        'btnLimpiarFiltros
        '
        Me.btnLimpiarFiltros.Image = CType(resources.GetObject("btnLimpiarFiltros.Image"), System.Drawing.Image)
        Me.btnLimpiarFiltros.Location = New System.Drawing.Point(419, 6)
        Me.btnLimpiarFiltros.Name = "btnLimpiarFiltros"
        Me.btnLimpiarFiltros.Size = New System.Drawing.Size(44, 24)
        Me.btnLimpiarFiltros.TabIndex = 7
        Me.btnLimpiarFiltros.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(4, 12)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 12)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Descripci�n"
        '
        'btnAplicarFiltro
        '
        Me.btnAplicarFiltro.Image = CType(resources.GetObject("btnAplicarFiltro.Image"), System.Drawing.Image)
        Me.btnAplicarFiltro.Location = New System.Drawing.Point(369, 6)
        Me.btnAplicarFiltro.Name = "btnAplicarFiltro"
        Me.btnAplicarFiltro.Size = New System.Drawing.Size(44, 24)
        Me.btnAplicarFiltro.TabIndex = 6
        Me.btnAplicarFiltro.UseVisualStyleBackColor = True
        '
        'txtFiltro
        '
        Me.txtFiltro.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFiltro.Location = New System.Drawing.Point(64, 9)
        Me.txtFiltro.Name = "txtFiltro"
        Me.txtFiltro.Size = New System.Drawing.Size(145, 18)
        Me.txtFiltro.TabIndex = 1
        '
        'chkDisponibles
        '
        Me.chkDisponibles.AutoSize = True
        Me.chkDisponibles.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkDisponibles.Location = New System.Drawing.Point(227, 10)
        Me.chkDisponibles.Name = "chkDisponibles"
        Me.chkDisponibles.Size = New System.Drawing.Size(92, 16)
        Me.chkDisponibles.TabIndex = 3
        Me.chkDisponibles.Text = "Solo Disponibles"
        Me.chkDisponibles.UseVisualStyleBackColor = True
        '
        'lvDatos
        '
        Me.lvDatos.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvDatos.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.id, Me.Descripcion, Me.Proveedor, Me.Stock, Me.Costo, Me.Precio, Me.FecIngreso, Me.colfotos, Me.colStatus})
        Me.lvDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lvDatos.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvDatos.FullRowSelect = True
        Me.lvDatos.GridLines = True
        Me.lvDatos.HideSelection = False
        Me.lvDatos.Location = New System.Drawing.Point(0, 0)
        Me.lvDatos.Name = "lvDatos"
        Me.lvDatos.Size = New System.Drawing.Size(524, 392)
        Me.lvDatos.SmallImageList = Me.imgListaBotones
        Me.lvDatos.StateImageList = Me.imgListaBotones
        Me.lvDatos.TabIndex = 1
        Me.lvDatos.TabStop = False
        Me.lvDatos.UseCompatibleStateImageBehavior = False
        Me.lvDatos.View = System.Windows.Forms.View.Details
        '
        'id
        '
        Me.id.Text = "C�digo"
        Me.id.Width = 77
        '
        'Descripcion
        '
        Me.Descripcion.Text = "Descripcion"
        Me.Descripcion.Width = 120
        '
        'Proveedor
        '
        Me.Proveedor.Text = "Proveedor"
        Me.Proveedor.Width = 81
        '
        'Stock
        '
        Me.Stock.Text = "Stock"
        Me.Stock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Stock.Width = 39
        '
        'Costo
        '
        Me.Costo.Text = "Costo"
        Me.Costo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Costo.Width = 42
        '
        'Precio
        '
        Me.Precio.Text = "Precio"
        Me.Precio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Precio.Width = 43
        '
        'FecIngreso
        '
        Me.FecIngreso.Text = "Ingreso"
        Me.FecIngreso.Width = 70
        '
        'colfotos
        '
        Me.colfotos.DisplayIndex = 8
        Me.colfotos.Text = "Fotos"
        Me.colfotos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colfotos.Width = 40
        '
        'colStatus
        '
        Me.colStatus.DisplayIndex = 7
        Me.colStatus.Text = "Estado"
        '
        'imgListaBotones
        '
        Me.imgListaBotones.ImageStream = CType(resources.GetObject("imgListaBotones.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imgListaBotones.TransparentColor = System.Drawing.Color.Transparent
        Me.imgListaBotones.Images.SetKeyName(0, "Bolita Verde.bmp")
        Me.imgListaBotones.Images.SetKeyName(1, "Bolita Roja.bmp")
        Me.imgListaBotones.Images.SetKeyName(2, "Bolita Azul.bmp")
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabGeneral)
        Me.TabControl1.Controls.Add(Me.tabFotos)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TabControl1.Location = New System.Drawing.Point(0, 30)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(503, 427)
        Me.TabControl1.TabIndex = 18
        '
        'tabGeneral
        '
        Me.tabGeneral.Controls.Add(Me.lblCodProv)
        Me.tabGeneral.Controls.Add(Me.txtNomProv)
        Me.tabGeneral.Controls.Add(Me.Label6)
        Me.tabGeneral.Controls.Add(Me.NumericUpDown1)
        Me.tabGeneral.Controls.Add(Me.Label2)
        Me.tabGeneral.Controls.Add(Me.Label4)
        Me.tabGeneral.Controls.Add(Me.txtCosto)
        Me.tabGeneral.Controls.Add(Me.lblDatosStatus)
        Me.tabGeneral.Controls.Add(Me.lblStatus)
        Me.tabGeneral.Controls.Add(Me.btnDevolver)
        Me.tabGeneral.Controls.Add(Me.Label5)
        Me.tabGeneral.Controls.Add(Me.txtDescripcion)
        Me.tabGeneral.Controls.Add(Me.Label1)
        Me.tabGeneral.Controls.Add(Me.txtPrecio)
        Me.tabGeneral.Controls.Add(Me.picFotoInicial)
        Me.tabGeneral.Controls.Add(Me.Label9)
        Me.tabGeneral.Controls.Add(Me.Label7)
        Me.tabGeneral.Controls.Add(Me.dtFecIngreso)
        Me.tabGeneral.Location = New System.Drawing.Point(4, 22)
        Me.tabGeneral.Name = "tabGeneral"
        Me.tabGeneral.Padding = New System.Windows.Forms.Padding(3)
        Me.tabGeneral.Size = New System.Drawing.Size(495, 401)
        Me.tabGeneral.TabIndex = 0
        Me.tabGeneral.Text = "Generales"
        Me.tabGeneral.UseVisualStyleBackColor = True
        '
        'lblCodProv
        '
        Me.lblCodProv.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCodProv.Location = New System.Drawing.Point(71, 64)
        Me.lblCodProv.Name = "lblCodProv"
        Me.lblCodProv.Size = New System.Drawing.Size(54, 20)
        Me.lblCodProv.TabIndex = 92
        Me.lblCodProv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtNomProv
        '
        Me.txtNomProv.Location = New System.Drawing.Point(131, 64)
        Me.txtNomProv.Name = "txtNomProv"
        Me.txtNomProv.Size = New System.Drawing.Size(309, 20)
        Me.txtNomProv.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(352, 38)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 90
        Me.Label6.Text = "Stock"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(393, 34)
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {99999, 0, 0, -2147483648})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(47, 20)
        Me.NumericUpDown1.TabIndex = 5
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 11)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 88
        Me.Label2.Text = "Descripci�n"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 87
        Me.Label4.Text = "Costo"
        '
        'txtCosto
        '
        Me.txtCosto.Location = New System.Drawing.Point(71, 34)
        Me.txtCosto.Name = "txtCosto"
        Me.txtCosto.Size = New System.Drawing.Size(61, 20)
        Me.txtCosto.TabIndex = 3
        Me.txtCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'lblDatosStatus
        '
        Me.lblDatosStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDatosStatus.Location = New System.Drawing.Point(263, 124)
        Me.lblDatosStatus.Name = "lblDatosStatus"
        Me.lblDatosStatus.Size = New System.Drawing.Size(189, 19)
        Me.lblDatosStatus.TabIndex = 80
        Me.lblDatosStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStatus
        '
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatus.Location = New System.Drawing.Point(71, 124)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(186, 19)
        Me.lblStatus.TabIndex = 77
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnDevolver
        '
        Me.btnDevolver.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDevolver.Image = CType(resources.GetObject("btnDevolver.Image"), System.Drawing.Image)
        Me.btnDevolver.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnDevolver.Location = New System.Drawing.Point(71, 371)
        Me.btnDevolver.Name = "btnDevolver"
        Me.btnDevolver.Size = New System.Drawing.Size(86, 24)
        Me.btnDevolver.TabIndex = 76
        Me.btnDevolver.Text = "Devolver  "
        Me.btnDevolver.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnDevolver.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 127)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 73
        Me.Label5.Text = "Estado"
        '
        'txtDescripcion
        '
        Me.txtDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDescripcion.Location = New System.Drawing.Point(71, 8)
        Me.txtDescripcion.Name = "txtDescripcion"
        Me.txtDescripcion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtDescripcion.Size = New System.Drawing.Size(408, 20)
        Me.txtDescripcion.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(179, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 65
        Me.Label1.Text = "Precio"
        '
        'txtPrecio
        '
        Me.txtPrecio.Location = New System.Drawing.Point(222, 34)
        Me.txtPrecio.Name = "txtPrecio"
        Me.txtPrecio.Size = New System.Drawing.Size(61, 20)
        Me.txtPrecio.TabIndex = 4
        Me.txtPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'picFotoInicial
        '
        Me.picFotoInicial.Location = New System.Drawing.Point(71, 156)
        Me.picFotoInicial.Name = "picFotoInicial"
        Me.picFotoInicial.Size = New System.Drawing.Size(337, 211)
        Me.picFotoInicial.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFotoInicial.TabIndex = 63
        Me.picFotoInicial.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(4, 93)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 13)
        Me.Label9.TabIndex = 46
        Me.Label9.Text = "Ingreso"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 68)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 44
        Me.Label7.Text = "Proveedor"
        '
        'dtFecIngreso
        '
        Me.dtFecIngreso.CustomFormat = "dd/MM/yyyy"
        Me.dtFecIngreso.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtFecIngreso.Location = New System.Drawing.Point(71, 90)
        Me.dtFecIngreso.Name = "dtFecIngreso"
        Me.dtFecIngreso.Size = New System.Drawing.Size(106, 20)
        Me.dtFecIngreso.TabIndex = 12
        Me.dtFecIngreso.TabStop = False
        '
        'tabFotos
        '
        Me.tabFotos.Controls.Add(Me.lvFotos)
        Me.tabFotos.Controls.Add(Me.btnFotos)
        Me.tabFotos.Controls.Add(Me.picFotoPrenda)
        Me.tabFotos.Location = New System.Drawing.Point(4, 22)
        Me.tabFotos.Name = "tabFotos"
        Me.tabFotos.Size = New System.Drawing.Size(495, 401)
        Me.tabFotos.TabIndex = 1
        Me.tabFotos.Text = "Fotos"
        Me.tabFotos.UseVisualStyleBackColor = True
        '
        'lvFotos
        '
        Me.lvFotos.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvFotos.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colId, Me.colArchivoFoto})
        Me.lvFotos.ContextMenuStrip = Me.mnuAccionesImagenes
        Me.lvFotos.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvFotos.FullRowSelect = True
        Me.lvFotos.HideSelection = False
        Me.lvFotos.Location = New System.Drawing.Point(6, 3)
        Me.lvFotos.Name = "lvFotos"
        Me.lvFotos.Size = New System.Drawing.Size(177, 332)
        Me.lvFotos.TabIndex = 80
        Me.lvFotos.UseCompatibleStateImageBehavior = False
        Me.lvFotos.View = System.Windows.Forms.View.Details
        '
        'colId
        '
        Me.colId.Text = "N�"
        Me.colId.Width = 30
        '
        'colArchivoFoto
        '
        Me.colArchivoFoto.Text = "Archivo"
        Me.colArchivoFoto.Width = 1000
        '
        'mnuAccionesImagenes
        '
        Me.mnuAccionesImagenes.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BorrarToolStripMenuItem})
        Me.mnuAccionesImagenes.Name = "ContextMenuStrip1"
        Me.mnuAccionesImagenes.Size = New System.Drawing.Size(107, 26)
        '
        'BorrarToolStripMenuItem
        '
        Me.BorrarToolStripMenuItem.Name = "BorrarToolStripMenuItem"
        Me.BorrarToolStripMenuItem.Size = New System.Drawing.Size(106, 22)
        Me.BorrarToolStripMenuItem.Text = "Borrar"
        '
        'btnFotos
        '
        Me.btnFotos.Location = New System.Drawing.Point(6, 341)
        Me.btnFotos.Name = "btnFotos"
        Me.btnFotos.Size = New System.Drawing.Size(63, 29)
        Me.btnFotos.TabIndex = 73
        Me.btnFotos.TabStop = False
        Me.btnFotos.Text = "Agregar"
        Me.btnFotos.UseVisualStyleBackColor = True
        '
        'picFotoPrenda
        '
        Me.picFotoPrenda.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.picFotoPrenda.Location = New System.Drawing.Point(189, 3)
        Me.picFotoPrenda.Name = "picFotoPrenda"
        Me.picFotoPrenda.Size = New System.Drawing.Size(365, 332)
        Me.picFotoPrenda.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFotoPrenda.TabIndex = 70
        Me.picFotoPrenda.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Codigo"
        '
        'txtId
        '
        Me.txtId.BackColor = System.Drawing.Color.White
        Me.txtId.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtId.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtId.Location = New System.Drawing.Point(63, 6)
        Me.txtId.MaxLength = 6
        Me.txtId.Name = "txtId"
        Me.txtId.ReadOnly = True
        Me.txtId.Size = New System.Drawing.Size(54, 20)
        Me.txtId.TabIndex = 1
        Me.txtId.TabStop = False
        Me.txtId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'mnuAccionesPrendas
        '
        Me.mnuAccionesPrendas.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AgregarAPromoToolStripMenuItem})
        Me.mnuAccionesPrendas.Name = "mnuAccionesPrendas"
        Me.mnuAccionesPrendas.Size = New System.Drawing.Size(165, 26)
        '
        'AgregarAPromoToolStripMenuItem
        '
        Me.AgregarAPromoToolStripMenuItem.Name = "AgregarAPromoToolStripMenuItem"
        Me.AgregarAPromoToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.AgregarAPromoToolStripMenuItem.Text = "Agregar a Promo"
        '
        'btnGrabar
        '
        Me.btnGrabar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnGrabar.Image = CType(resources.GetObject("btnGrabar.Image"), System.Drawing.Image)
        Me.btnGrabar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGrabar.Location = New System.Drawing.Point(851, 467)
        Me.btnGrabar.Name = "btnGrabar"
        Me.btnGrabar.Size = New System.Drawing.Size(85, 41)
        Me.btnGrabar.TabIndex = 4
        Me.btnGrabar.Text = "Grabar"
        Me.btnGrabar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnGrabar.UseVisualStyleBackColor = True
        '
        'btnEliminar
        '
        Me.btnEliminar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnEliminar.Image = CType(resources.GetObject("btnEliminar.Image"), System.Drawing.Image)
        Me.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnEliminar.Location = New System.Drawing.Point(760, 467)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(85, 41)
        Me.btnEliminar.TabIndex = 8
        Me.btnEliminar.Text = "Eliminar"
        Me.btnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'lblCantItems
        '
        Me.lblCantItems.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblCantItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCantItems.Location = New System.Drawing.Point(13, 479)
        Me.lblCantItems.Name = "lblCantItems"
        Me.lblCantItems.Size = New System.Drawing.Size(136, 16)
        Me.lblCantItems.TabIndex = 9
        Me.lblCantItems.Text = "Cant Items"
        Me.lblCantItems.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUltimoId
        '
        Me.lblUltimoId.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblUltimoId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblUltimoId.Location = New System.Drawing.Point(421, 479)
        Me.lblUltimoId.Name = "lblUltimoId"
        Me.lblUltimoId.Size = New System.Drawing.Size(103, 16)
        Me.lblUltimoId.TabIndex = 10
        Me.lblUltimoId.Text = "Ultimo Id"
        Me.lblUltimoId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'lblPrecioTotal
        '
        Me.lblPrecioTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblPrecioTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPrecioTotal.Location = New System.Drawing.Point(338, 479)
        Me.lblPrecioTotal.Name = "lblPrecioTotal"
        Me.lblPrecioTotal.Size = New System.Drawing.Size(77, 16)
        Me.lblPrecioTotal.TabIndex = 11
        Me.lblPrecioTotal.Text = "Importe"
        Me.lblPrecioTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCostoTotal
        '
        Me.lblCostoTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblCostoTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostoTotal.Location = New System.Drawing.Point(217, 479)
        Me.lblCostoTotal.Name = "lblCostoTotal"
        Me.lblCostoTotal.Size = New System.Drawing.Size(78, 16)
        Me.lblCostoTotal.TabIndex = 12
        Me.lblCostoTotal.Text = "Importe"
        Me.lblCostoTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(177, 481)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 74
        Me.Label10.Text = "Costo"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(301, 481)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(37, 13)
        Me.Label11.TabIndex = 75
        Me.Label11.Text = "Precio"
        '
        'frmPrendas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(1039, 514)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.lblCostoTotal)
        Me.Controls.Add(Me.lblPrecioTotal)
        Me.Controls.Add(Me.lblUltimoId)
        Me.Controls.Add(Me.lblCantItems)
        Me.Controls.Add(Me.splitMain)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnGrabar)
        Me.Controls.Add(Me.btnNuevo)
        Me.Controls.Add(Me.btnEliminar)
        Me.Controls.Add(Me.Label10)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmPrendas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Mercaderia"
        Me.splitMain.Panel1.ResumeLayout(False)
        Me.splitMain.Panel2.ResumeLayout(False)
        Me.splitMain.Panel2.PerformLayout()
        CType(Me.splitMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.splitMain.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.PerformLayout()
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tabGeneral.ResumeLayout(False)
        Me.tabGeneral.PerformLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFotoInicial, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabFotos.ResumeLayout(False)
        Me.mnuAccionesImagenes.ResumeLayout(False)
        CType(Me.picFotoPrenda, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuAccionesPrendas.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnNuevo As System.Windows.Forms.Button
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents splitMain As System.Windows.Forms.SplitContainer
    Friend WithEvents txtId As System.Windows.Forms.TextBox
    Friend WithEvents btnGrabar As System.Windows.Forms.Button
    Friend WithEvents btnEliminar As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabGeneral As System.Windows.Forms.TabPage
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents dtFecIngreso As System.Windows.Forms.DateTimePicker
    Friend WithEvents picFotoInicial As System.Windows.Forms.PictureBox
    Friend WithEvents lblCantItems As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtPrecio As System.Windows.Forms.TextBox
    Friend WithEvents lvDatos As System.Windows.Forms.ListView
    Friend WithEvents id As System.Windows.Forms.ColumnHeader
    Friend WithEvents Proveedor As System.Windows.Forms.ColumnHeader
    Friend WithEvents Stock As System.Windows.Forms.ColumnHeader
    Friend WithEvents Costo As System.Windows.Forms.ColumnHeader
    Friend WithEvents FecIngreso As System.Windows.Forms.ColumnHeader
    Friend WithEvents Precio As System.Windows.Forms.ColumnHeader
    Friend WithEvents Descripcion As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents btnDevolver As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents tabFotos As System.Windows.Forms.TabPage
    Friend WithEvents btnFotos As System.Windows.Forms.Button
    Friend WithEvents picFotoPrenda As System.Windows.Forms.PictureBox
    Friend WithEvents lblUltimoId As System.Windows.Forms.Label
    Friend WithEvents lblDatosStatus As System.Windows.Forms.Label
    Friend WithEvents lvFotos As System.Windows.Forms.ListView
    Friend WithEvents colId As System.Windows.Forms.ColumnHeader
    Friend WithEvents colArchivoFoto As System.Windows.Forms.ColumnHeader
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents mnuAccionesImagenes As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents BorrarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents colfotos As System.Windows.Forms.ColumnHeader
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents btnAplicarFiltro As System.Windows.Forms.Button
    Friend WithEvents txtFiltro As System.Windows.Forms.TextBox
    Friend WithEvents chkDisponibles As System.Windows.Forms.CheckBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnLimpiarFiltros As System.Windows.Forms.Button
    Friend WithEvents lblPrecioTotal As System.Windows.Forms.Label
    Friend WithEvents colStatus As System.Windows.Forms.ColumnHeader
    Friend WithEvents imgListaBotones As System.Windows.Forms.ImageList
    Friend WithEvents mnuAccionesPrendas As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AgregarAPromoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtCosto As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblCodProv As System.Windows.Forms.Label
    Friend WithEvents txtNomProv As System.Windows.Forms.TextBox
    Friend WithEvents lblCostoTotal As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtProveedorBusqueda As TextBox
    Friend WithEvents lblCodProvBusqueda As Label
End Class
