﻿Public Class frmPromos
    Dim oListaPromos As Promos
    Dim oPromoActual As Promo

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmPromos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GUI.LimpiarCampos(Me)
        refrescar()
    End Sub

    Sub Refrescar()
        Me.oListaPromos = oHandler.CargarPromos()
        GUI.MostrarPromos(oListaPromos, Me.tvPromos)
    End Sub

    Private Sub btnNuevo_Click(sender As Object, e As EventArgs) Handles btnNuevo.Click
        GUI.LimpiarCampos(Me)
        Me.txtId.Text = oHandler.GetId(TABLA_PROMOS)
        Me.btnGrabar.Enabled = True
        Me.dtDesde.Value = Date.Today
        Me.dtHasta.Value = DateAdd(DateInterval.Month, 1, Me.dtDesde.Value)
        Me.txtNombre.Focus()
    End Sub

    Private Sub btnGrabar_Click(sender As Object, e As EventArgs) Handles btnGrabar.Click
        Dim sError As String

        If Not GUI.ValidarDatos(Me, sError) Then
            MsgBox("Datos incorrectos : " & vbCrLf & sError, MsgBoxStyle.Exclamation)
        Else
            If MsgBox("¿ Confirma estos datos ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                Me.oPromoActual = GUI.GetPromo(Me)
                If oHandler.GrabarPromo(Me.oPromoActual, False, sError) Then
                    MsgBox("Promo grabada OK", MsgBoxStyle.Information)
                    Refrescar()
                End If
            Else
                MsgBox("Error al grabar promo : " & vbCrLf & sError, MsgBoxStyle.Critical)
            End If

        End If

    End Sub

    Private Sub tvPromos_NodeMouseClick(sender As Object, e As TreeNodeMouseClickEventArgs) Handles tvPromos.NodeMouseClick
        If e.Node.Level = 0 Then
            Me.oPromoActual = Me.oListaPromos.GetItemByKey(CInt(e.Node.Name))
            GUI.MostrarPromo(oPromoActual, Me)
            Me.btnEliminar.Enabled = True
            Me.btnGrabar.Enabled = True
        Else
            Me.oPromoActual = Me.oListaPromos.GetItemByKey(CInt(e.Node.Parent.Name))
            Dim p As Prenda = oHandler.CargarPrenda(e.Node.Name)
            GUI.MostrarImagen(Me.picFotoInicial, p, p.PrimerIdImagen)
            Me.lblPrendaActual.Text = "Prenda : " & e.Node.Text
        End If

    End Sub

    Private Sub txtDescuento_Leave(sender As Object, e As EventArgs) Handles txtDescuento.Leave
        Dim sError As String
        If GUI.ValidarDatos(Me, sError) Then
            Me.lblPrecioFinal.Text = Format(Me.oPromoActual.ImporteFinal(CDbl(Me.txtDescuento.Text)), FORMATO_IMPORTE)
        End If
    End Sub

    Private Sub txtDescuento_TextChanged(sender As Object, e As EventArgs) Handles txtDescuento.TextChanged

    End Sub

    Private Sub QuitarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles QuitarToolStripMenuItem.Click
        If Me.tvPromos.SelectedNode.Level = 1 Then
            If MsgBox("¿ Quitamos la prenda " & Me.tvPromos.SelectedNode.Name & " de esta promo ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If oHandler.QuitarPrendaPromo(CInt(Me.tvPromos.SelectedNode.Parent.Name), CInt(Me.tvPromos.SelectedNode.Name)) Then
                    Refrescar()
                End If
            End If
        End If
    End Sub

    Private Sub tvPromos_AfterSelect(sender As Object, e As TreeViewEventArgs) Handles tvPromos.AfterSelect

    End Sub

    Private Sub QuitarTodasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles QuitarTodasToolStripMenuItem.Click
        If Me.tvPromos.SelectedNode.Level = 0 Then
            If MsgBox("¿ Quitamos TODAS las prendas de esta promo ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If oHandler.QuitarPrendaPromo(CInt(Me.tvPromos.SelectedNode.Name), 0) Then
                    Refrescar()
                End If
            End If
        End If
    End Sub

    Private Sub splitMain_Panel2_Paint(sender As Object, e As PaintEventArgs) Handles splitMain.Panel2.Paint

    End Sub
End Class