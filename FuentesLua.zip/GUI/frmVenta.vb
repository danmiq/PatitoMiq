﻿Public Class frmVenta
    Public Prenda As Prenda
    Public Accion As T_ACCION

    Dim oCliente As Cliente

    Private Sub frmVenta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Inicializar()
    End Sub

    Sub Inicializar()
        Me.dtFecha.Value = Date.Today

        Me.lvDatos.Items.Clear()
    End Sub
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim sError As String

        If Not ValidarDatos(sError) Then
            MsgBox("No se puede efectuar la venta : " & vbCrLf & serror, MsgBoxStyle.Exclamation)
        Else
            If MsgBox("¿ Confirma esta venta ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = vbYes Then
                Dim v As Venta = GUI.GetVenta(Me)
                If oHandler.Vender(v, sError) Then
                    MsgBox("Venta registrada", MsgBoxStyle.Information)

                    Me.Inicializar()
                Else
                    MsgBox("Error al registrar venta : " & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub
    Function ValidarDatos(ByRef sError As String) As Boolean
        ValidarDatos = True
        sError = ""
        If Me.lvDatos.Items.Count = 0 Then
            sError = sError & " - No ha ingresado artículos para vender" & vbCrLf
            ValidarDatos = False
        End If
    End Function
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub lvDatos_DoubleClick(sender As Object, e As EventArgs) Handles lvDatos.DoubleClick
        ModificarDatos()
    End Sub

    Private Sub lvDatos_KeyDown(sender As Object, e As KeyEventArgs) Handles lvDatos.KeyDown
        If e.KeyCode = Keys.Delete Then
            If lvDatos.SelectedItems.Count > 0 Then
                Me.lvDatos.Items.RemoveAt(lvDatos.SelectedItems(0).Index)
                CalcularTotal(Me.lvDatos)
            End If
        End If

    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        CargarArticulos()
    End Sub
    Sub CargarArticulos()
        Dim oArticulos As Prendas
        Dim oArt As Prenda
        Dim sBusqueda As String

        sBusqueda = "P.cod_status IN (" & T_STATUS.DISPONIBLE & "," & T_STATUS.DISPONIBLE_VENTA_ANULADA & ") and Stock > 0 "

        If IsNumeric(Me.txtBusqueda.Text.Trim) Then
            sBusqueda = sBusqueda & "And id_prenda = " & Me.txtBusqueda.Text.ToUpper
        Else
            sBusqueda = sBusqueda & "And Descripcion Like '%" & Me.txtBusqueda.Text.ToUpper & "%'"
        End If


        oArticulos = oHandler.CargarPrendas(sbusqueda, 2)

        Dim itm As ListViewItem

        If oArticulos.Items.Count > 0 Then
            If oArticulos.Items.Count = 1 Then
                oArt = oArticulos.Items(1)
            Else
                frmLista.Tabla = TABLA_PRENDAS
                frmLista.oLista = oArticulos
                frmLista.MostrarDatos()
                frmLista.ShowDialog()
                If frmLista.DialogResult = Windows.Forms.DialogResult.OK Then
                    oArt = oHandler.CargarPrenda(frmLista.Id)
                End If
            End If
            Me.txtBusqueda.Text = ""
        Else
            MsgBox("No existe el articulo, o no esta disponible para Venta", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
        End If

        Dim nCant As Integer = 1

        If Not (oArt Is Nothing) Then
            itm = Me.lvDatos.Items.Add(oArt.Id)

            itm.SubItems.Add(oArt.Descripcion)
            itm.SubItems.Add(nCant)
            itm.SubItems.Add(oArt.Precio)
            itm.SubItems.Add(oArt.Precio * nCant)
            itm.SubItems.Add(oArt.Stock)

            CalcularTotal(Me.lvDatos)
        End If

    End Sub
    Sub CalcularTotal(lv As ListView)
        Dim itm As ListViewItem
        Dim dTot As Double = 0

        For Each itm In lv.Items
            itm.SubItems(4).Text = (CDbl(itm.SubItems(3).Text) * CInt(itm.SubItems(2).Text))
            dTot = dTot + CDbl(itm.SubItems(4).Text)
        Next
        Me.lblPrecioFinal.Text = Format(dTot, FORMATO_IMPORTE)
    End Sub


    Private Sub ModificarDatos()
        Dim nStock As Integer
        Dim itm As ListViewItem
        Dim nCant As Integer

        If Me.lvDatos.SelectedItems.Count > 0 Then
            itm = Me.lvDatos.SelectedItems(0)
            nStock = CInt(itm.SubItems(5).Text)
            If nStock > 1 Then
                nCant = InputValor(nStock, "Cantidad", itm.SubItems(1).Text, 1)
                Me.lvDatos.SelectedItems(0).SubItems(2).Text = nCant
                CalcularTotal(Me.lvDatos)
            End If
        End If

    End Sub

    Private Sub txtBusqueda_KeyDown(sender As Object, e As KeyEventArgs) Handles txtBusqueda.KeyDown
        If e.KeyCode = Keys.Enter Then
            CargarArticulos()
        End If
    End Sub

    
    Private Sub txtNomCliente_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub lvDatos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDatos.SelectedIndexChanged

    End Sub
End Class