Public Class frmPrendas
    Private oListaPrendas As Prendas
    Public oPrendaActual As Prenda
    Public nIdImagenAct As Integer

    Public Nuevo As Boolean

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmPrendas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.chkDisponibles.Checked = True

        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor
        Me.oListaPrendas = oHandler.CargarPrendas("", 1)
        System.Windows.Forms.Cursor.Current = Cursors.Default

        Refrescar(0)

        Me.splitMain.Panel2.Enabled = False

        GUI.LimpiarCampos(Me)
    End Sub

    Private Sub btnNuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNuevo.Click
        Me.Nuevo = True
        Me.oPrendaActual = New Prenda
        GUI.LimpiarCampos(Me)

        Me.txtId.Text = oHandler.GetId(TABLA_PRENDAS)
        Me.btnGrabar.Enabled = True

        Me.splitMain.Panel2.Enabled = True
        Me.TabControl1.SelectTab(0)
        Me.txtDescripcion.Focus()
    End Sub

    Private Sub btnGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrabar.Click
        Dim sError As String

        If Not GUI.ValidarDatos(Me, sError) Then
            MsgBox("Datos incorrectos : " & vbCrLf & sError, MsgBoxStyle.Exclamation)
        Else
            If MsgBox("� Confirma la modificaci�n de esta mercader�a ? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If GUI.ValidarPrenda(Me, sError) Then
                    Me.oPrendaActual = GUI.GetPrenda(Me)
                    GUI.LimpiarPictureBox(Me.picFotoPrenda)
                    If oHandler.GrabarPrenda(Me.oPrendaActual, False, sError) Then
                        Me.oListaPrendas = oHandler.CargarPrendas("", 1)
                        Refrescar(CInt(Me.txtId.Text))
                        Me.oPrendaActual = oHandler.CargarPrenda(CInt(Me.txtId.Text))
                        GUI.MostrarPrenda(Me.oPrendaActual, Me)
                    Else
                        MsgBox("Error al grabar : " & sError, vbExclamation)
                    End If
                Else
                    MsgBox("Errores en los datos ingresados : " & vbCrLf & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        Dim nIdArticulo As Long
        Dim sError As String = ""

        If Me.lvDatos.SelectedItems.Count > 0 Then
            nIdArticulo = CLng(Me.lvDatos.SelectedItems(0).Text)
            Me.oPrendaActual = Me.oListaPrendas.GetItem(nIdArticulo)
            If oPrendaActual.Ventas > 0 Then
                MsgBox("No se puede eliminar porque tiene Ventas efectuadas", MsgBoxStyle.Critical)
            Else
                If MsgBox("� Confirma la eliminaci�n de la mercader�a " & nIdArticulo & " ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                    oHandler.GrabarPrenda(Me.oPrendaActual, True, sError)
                    Me.oListaPrendas = oHandler.CargarPrendas("", 1)
                    Refrescar(0)

                    Me.Nuevo = True
                End If
            End If
        End If
    End Sub

    Private Sub lvDatos_ItemActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvDatos.ItemActivate
        Me.splitMain.Panel2.Enabled = True
        Me.oPrendaActual = Me.oListaPrendas.GetItem(Me.lvDatos.SelectedItems(0).Text)
        Me.oPrendaActual = oHandler.CargarPrenda(Me.oPrendaActual.Id)
        GUI.MostrarPrenda(Me.oPrendaActual, Me)

        Me.Nuevo = False
        Me.btnGrabar.Enabled = True
        Me.btnEliminar.Enabled = True
    End Sub

    Private Sub lvDatos_ColumnClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs)
        Me.lvDatos.ListViewItemSorter = New ListViewItemComparer(e.Column)
    End Sub

    Friend Sub Refrescar(ByVal nIdPrenda As Integer)
        Dim nCantItems, nMaxId As Integer
        Dim dPrecioTotal, dCostoTotal As Double
        Dim v As GUI.T_VISTA_LISTVIEW

        Me.lblUltimoId.Text = ""
        Me.lblCantItems.Text = ""
        Me.lblCostoTotal.Text = ""
        Me.lblPrecioTotal.Text = ""

        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor
        GUI.MostrarPrendas(Me.oListaPrendas, Me.lvDatos, Me.txtFiltro.Text.ToUpper, Me.chkDisponibles.Checked, CInt(IIf(Me.lblCodProvBusqueda.Text = "", "0", Me.lblCodProvBusqueda.Text)), nCantItems, nIdPrenda, dCostoTotal, dPrecioTotal, v)
        System.Windows.Forms.Cursor.Current = Cursors.Default

        nMaxId = oHandler.GetId(TABLA_PRENDAS) - 1
        Me.lblUltimoId.Text = "Ultimo Id : " & nMaxId
        Me.lblCantItems.Text = Me.lvDatos.Items.Count & " / " & Me.oListaPrendas.Count.ToString & " items"
        Me.lblCostoTotal.Text = Format(dCostoTotal, FORMATO_IMPORTE) & " $"
        Me.lblPrecioTotal.Text = Format(dPrecioTotal, FORMATO_IMPORTE) & " $"

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs)
        If Me.nIdImagenAct < Me.oPrendaActual.Imagenes.Count - 1 Then
            Me.nIdImagenAct = nIdImagenAct + 1
            GUI.MostrarImagen(Me.picFotoPrenda, Me.oPrendaActual, Me.nIdImagenAct)
        End If
    End Sub

    Private Sub btnImagePrev_Click(sender As Object, e As EventArgs)
        If Me.nIdImagenAct > 0 Then
            Me.nIdImagenAct = nIdImagenAct - 1
            GUI.MostrarImagen(Me.picFotoPrenda, Me.oPrendaActual, Me.nIdImagenAct)
        End If
    End Sub

    Private Sub lvFotos_ItemActivate(sender As Object, e As EventArgs) Handles lvFotos.ItemActivate
        GUI.MostrarImagen(Me.picFotoPrenda, Me.oPrendaActual, CInt(Me.lvFotos.SelectedItems(0).Text))
    End Sub

    Private Sub btnFotos_Click(sender As Object, e As EventArgs) Handles btnFotos.Click
        Dim s As String

        Me.OpenFileDialog1.Multiselect = True
        If Me.OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim itm As ListViewItem

            Dim n As Integer = System.Math.Max(Me.oPrendaActual.UltimoIdImagen, GUI.UltimoId(Me.lvFotos))

            For Each s In Me.OpenFileDialog1.FileNames()
                n = n + 1
                itm = New ListViewItem
                itm.Text = n
                itm.SubItems.Add(s)

                itm.Tag = Prenda.T_ACCION_IMAGEN.AGREGAR
                Me.lvFotos.Items.Add(itm)
            Next
        End If
    End Sub

    Private Sub BorrarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BorrarToolStripMenuItem.Click
        Me.lvFotos.SelectedItems(0).Tag = Prenda.T_ACCION_IMAGEN.ELIMINAR
        Me.lvFotos.SelectedItems(0).ForeColor = Color.Red
    End Sub

    Private Sub btnAplicarFiltro_Click(sender As Object, e As EventArgs) Handles btnAplicarFiltro.Click
        Refrescar(0)
    End Sub

    Private Sub btnLimpiarFiltros_Click(sender As Object, e As EventArgs) Handles btnLimpiarFiltros.Click
        Me.txtFiltro.Text = ""
        Me.chkDisponibles.Checked = False
        Me.lblCodProvBusqueda.Text = "0"
        Me.txtProveedorBusqueda.Text = ""
        Refrescar(0)
    End Sub

    Private Sub btnBajar_Click(sender As Object, e As EventArgs) Handles btnDevolver.Click
        Dim s, sError As String
        Dim nCant As Integer

        s = "� Confirma la devoluci�n de " & oPrendaActual.Descripcion & " ?"
        If MsgBox(s, MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Devolver al Proveedor") = MsgBoxResult.Yes Then
            nCant = InputValor(oPrendaActual.Stock, "Devolver", "Cantidad a Devolver", oPrendaActual.Stock)
            If nCant > 0 Then
                If oHandler.Devolver(Me.oPrendaActual.Id, nCant, Date.Now, sError) Then
                    MsgBox("Art�culo devuelto", MsgBoxStyle.Information)
                    Refrescar(oPrendaActual.Id)
                End If
            End If
        End If
    End Sub

    Private Sub frmPrendas_ResizeEnd(sender As Object, e As EventArgs) Handles Me.ResizeEnd
        Me.splitMain.Height = Me.Height - 90
        Me.TabControl1.Height = Me.splitMain.Height - 31
    End Sub

    Private Sub rbGrupos_CheckedChanged(sender As Object, e As EventArgs)
        Refrescar(0)
    End Sub

    Private Sub AgregarAPromoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarAPromoToolStripMenuItem.Click
        Dim sLista As String
        Dim nAgregadas As Integer
        Dim sError As String

        frmLista.Tabla = TABLA_PROMOS
        frmLista.CargarLista("")

        If frmLista.ShowDialog() Then
            sLista = GUI.GetListaSeleccionados(Me.lvDatos)
            nAgregadas = oHandler.PromoAgregarPrendas(frmLista.Id, sLista, sError)
            If nAgregadas > 0 Then
                MsgBox("Se agregaron " & nAgregadas & " mercader�as a la promo " & frmLista.Nombre, MsgBoxStyle.Information)
            Else
                If nAgregadas = 0 Then
                    MsgBox("Ninguna mercader�a se agreg� a la promo " & frmLista.Nombre, MsgBoxStyle.Exclamation)
                Else
                    MsgBox("Ocurri� un error al agregar las mercader�as : " & vbCrLf & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub

    Private Sub txtFiltroCateg_GotFocus(sender As Object, e As EventArgs) Handles txtFiltro.GotFocus
        Me.txtFiltro.SelectAll()
    End Sub

    Private Sub txtNomProv_Enter(sender As Object, e As EventArgs) Handles txtNomProv.Enter
        Me.txtNomProv.SelectAll()
    End Sub

    Private Sub txtNomProv_Leave(sender As Object, e As EventArgs) Handles txtNomProv.Leave
        CargarProveedor(Me.lblCodProv, Me.txtNomProv)
    End Sub

    Private Sub txtProveedorBusqueda_Leave(sender As Object, e As EventArgs) Handles txtProveedorBusqueda.Leave
        If Me.txtProveedorBusqueda.Text <> "" Then
            CargarProveedor(Me.lblCodProvBusqueda, Me.txtProveedorBusqueda)

            If Me.lblCodProvBusqueda.Text <> "" Then
                If CInt(Me.lblCodProvBusqueda.Text) > 0 Then
                    Refrescar(0)
                End If
            End If
        Else
            If Me.lblCodProvBusqueda.Text <> "" Then
                Me.lblCodProvBusqueda.Text = "0"
                Refrescar(0)
            End If
        End If
    End Sub

    Private Sub txtProveedorBusqueda_TextChanged(sender As Object, e As EventArgs) Handles txtProveedorBusqueda.TextChanged

    End Sub

    Private Sub txtProveedorBusqueda_Enter(sender As Object, e As EventArgs) Handles txtProveedorBusqueda.Enter
        Me.txtProveedorBusqueda.SelectAll()
    End Sub

    Private Sub txtDescripcion_TextChanged(sender As Object, e As EventArgs) Handles txtDescripcion.TextChanged

    End Sub

    Private Sub txtDescripcion_ImeModeChanged(sender As Object, e As EventArgs) Handles txtDescripcion.ImeModeChanged

    End Sub

    Private Sub txtDescripcion_Enter(sender As Object, e As EventArgs) Handles txtDescripcion.Enter
        txtDescripcion.BackColor = COLOR_SETEADO
    End Sub

    Private Sub txtDescripcion_Leave(sender As Object, e As EventArgs) Handles txtDescripcion.Leave
        txtDescripcion.BackColor = Color.White
    End Sub
    Private Sub btnVender_Click(sender As Object, e As EventArgs) Handles btnVender.Click
        If frmVenta.IsHandleCreated Then
            frmVenta.Close()
        End If
        frmVenta.CodArticulo = oPrendaActual.Id
        GUI.UnaInstanciaDialog(frmVenta, Me)
        If frmVenta.DialogResult = DialogResult.OK Then
            Me.oListaPrendas = oHandler.CargarPrendas("", 1)
            Refrescar(0)
        End If
    End Sub
End Class


