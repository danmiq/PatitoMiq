﻿Public Class Proveedor
    Private nId As Long
    Public Property Id() As Long
        Get
            Return nId
        End Get
        Set(ByVal value As Long)
            nId = value
        End Set
    End Property
    Private sNombre As String
    Public Property Nombre() As String
        Get
            Return sNombre
        End Get
        Set(ByVal value As String)
            sNombre = value
        End Set
    End Property

    Private dFecIngreso As Date
    Private sMail As String
    Private sDireccion As String
    Private sTel As String

    Public Property FecIngreso() As Date
        Get
            Return dFecIngreso
        End Get
        Set(ByVal value As Date)
            dFecIngreso = value
        End Set
    End Property
    Public Property Mail() As String
        Get
            Return sMail
        End Get
        Set(ByVal value As String)
            sMail = value
        End Set
    End Property
    Public Property Telefono() As String
        Get
            Return sTel
        End Get
        Set(ByVal value As String)
            sTel = value
        End Set
    End Property
    Public Property Direccion() As String
        Get
            Return sDireccion
        End Get
        Set(ByVal value As String)
            sDireccion = value
        End Set
    End Property
End Class
