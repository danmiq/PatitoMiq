﻿Public Class Proveedores
    Inherits Coleccion(Of Proveedor)

    Public Function GetItemByKey(ByVal nIdSec As Long) As Proveedor
        Dim l As Proveedor = Nothing
        For Each l In Me.Items
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function

    Public Function GetItem(ByVal nIdSec As Integer) As Proveedor
        Dim l As Proveedor = Nothing
        For Each l In Me.Items
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function
End Class


