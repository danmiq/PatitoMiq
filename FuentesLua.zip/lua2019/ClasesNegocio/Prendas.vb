Public Class Prendas
    Inherits List(Of Prenda)

    Public Function GetItemByKey(ByVal nIdSec As Long) As Prenda
        Dim l As Prenda = Nothing
        For Each l In Me
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function

    Public Function GetItem(ByVal nIdSec As Integer) As Prenda
        Dim l As Prenda = Nothing
        For Each l In Me
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function
End Class
