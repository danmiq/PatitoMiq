
Public MustInherit Class Coleccion(Of t)
    Private vItems As Collection
    Public Property Items() As Collection
        Get
            Return vItems
        End Get
        Set(ByVal value As Collection)
            vItems = value
        End Set
    End Property
    Public Sub New()
        Me.vItems = New Collection
    End Sub
    Public Sub Cargar()

    End Sub
    Public Function Count() As Integer
        Return vItems.Count
    End Function

End Class
