﻿Public Class Clientes
    Inherits Coleccion(Of Cliente)

    Public Function GetItemByKey(ByVal nIdSec As Long) As Cliente
        Dim l As Cliente = Nothing
        For Each l In Me.Items
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function

    Public Function GetItem(ByVal nIdSec As Integer) As Cliente
        Dim l As Cliente = Nothing
        For Each l In Me.Items
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function
End Class