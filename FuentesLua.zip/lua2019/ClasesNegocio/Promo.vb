﻿Public Class Promo
    Public ReadOnly Property ImporteFinal(Optional nDescuento As Double = 0) As Double
        Get
            Dim p As Prenda
            If nDescuento = 0 Then
                ImporteFinal = System.Math.Round(Me.ImporteLista() * (1 - (Me.Descuento / 100)), 2)
            Else
                ImporteFinal = System.Math.Round(Me.ImporteLista() * (1 - (nDescuento / 100)), 2)
            End If

        End Get
    End Property
    Public ReadOnly Property ImporteLista As Double
        Get
            Dim p As Prenda
            ImporteLista = 0
            For Each p In Me.Prendas
                ImporteLista = ImporteLista + p.Precio
            Next
        End Get
    End Property
    Private nId As Long
    Public Property Id() As Long
        Get
            Return nId
        End Get
        Set(ByVal value As Long)
            nId = value
        End Set
    End Property

    Private sNombre As String
    Public Property Nombre() As String
        Get
            Return sNombre
        End Get
        Set(ByVal value As String)
            sNombre = value
        End Set
    End Property

    Private dDesde As Date
    Public Property Desde() As Date
        Get
            Return dDesde
        End Get
        Set(ByVal value As Date)
            dDesde = value
        End Set
    End Property
    Private dHasta As Date
    Public Property Hasta() As Date
        Get
            Return dHasta
        End Get
        Set(ByVal value As Date)
            dHasta = value
        End Set
    End Property

    Private dPje As Double
    Public Property Descuento() As Double
        Get
            Return dPje
        End Get
        Set(ByVal value As Double)
            dPje = value
        End Set
    End Property
    Public Prendas As Prendas

    Public Sub New()
        Me.Prendas = New Prendas
    End Sub

End Class
