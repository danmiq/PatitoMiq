﻿Public Class Cupones
    Inherits Coleccion(Of Cupon)

    Public Function GetItemByKey(ByVal nIdSec As Long) As Cupon
        Dim l As Cupon = Nothing
        For Each l In Me.Items
            If l.IdCupon = nIdSec Then
                Return l
            End If
        Next
    End Function

    Public Function GetItem(ByVal nIdSec As Integer) As Cupon
        Dim l As Cupon = Nothing
        For Each l In Me.Items
            If l.IdCupon = nIdSec Then
                Return l
            End If
        Next
    End Function
End Class
