﻿Public Class HandlerReporte
    Private oBase As AccesoBase.AccesoBaseSQL
    Public Property Base() As AccesoBase.AccesoBaseSQL
        Get
            Return Me.oBase
        End Get
        Set(ByVal value As AccesoBase.AccesoBaseSQL)
            Me.oBase = value
        End Set
    End Property

    Public Sub New()
        oBase = New AccesoBase.AccesoBaseSQL
        oBase.StringConexion = CONEXION_SQL
    End Sub

    Friend Function GetVentasTotal(dFecDesde As Date, dFecHasta As Date) As List(Of ITEM_VENTA_RESUMEN)
        Dim b As New VentasDAO(Me.Base)
        Return b.CargarLista(dFecDesde, dFecHasta)
    End Function
    Friend Function GetVentasDetalle(sFiltro As String) As List(Of ITEM_VENTA_DETALLE)
        Dim b As New VentasDAO(Me.Base)
        Return b.CargarLista(sFiltro)
    End Function

    Friend Function GetDevoluciones(sFiltro As String) As List(Of ITEM_DEVOLUCION)
        Dim b As New VentasDAO(Me.Base)
        Return b.GetDevoluciones(sFiltro)
    End Function



End Class
