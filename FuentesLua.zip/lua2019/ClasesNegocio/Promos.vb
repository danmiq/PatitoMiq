﻿Public Class Promos
    Inherits Coleccion(Of Promo)

    Public Function GetItemByKey(ByVal nIdSec As Long) As Promo
        Dim l As Promo = Nothing
        For Each l In Me.Items
            If l.Id = nIdSec Then
                Return l
            End If
        Next
    End Function
End Class
