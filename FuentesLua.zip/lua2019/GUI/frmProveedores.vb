﻿Public Class frmProveedores
    Dim oLista As Proveedores
    Dim oProvActual As Proveedor
    Dim Nuevo As Boolean = True

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmProveedores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GUI.LimpiarCampos(Me)
        Refrescar()
        Me.txtFiltro.Focus()
    End Sub

    Private Sub lvDatos_ItemActivate(sender As Object, e As EventArgs) Handles lvDatos.ItemActivate
        Me.oProvActual = Me.oLista.GetItemByKey(Me.lvDatos.SelectedItems(0).Text)
        GUI.MostrarProveedor(oProvActual, Me)
    End Sub

    Private Sub btnGrabar_Click(sender As Object, e As EventArgs) Handles btnGrabar.Click
        Dim sError As String

        If Not GUI.ValidarDatos(Me, sError) Then
            MsgBox("Datos incorrectos : " & vbCrLf & sError, MsgBoxStyle.Exclamation)
        Else
            If MsgBox("¿ Confirma estos datos ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                Me.oProvActual = GUI.GetProveedor(Me)
                If oHandler.GrabarProveedor(Me.oProvActual, False, sError) Then
                    MsgBox("Proveedor grabado OK", MsgBoxStyle.Information)
                    GUI.LimpiarCampos(Me)
                    Refrescar()
                Else
                    MsgBox("Error al grabar proveedor : " & vbCrLf & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub
    Sub Refrescar()
        oLista = oHandler.CargarProveedores("")
        GUI.MostrarProveedores(Me.lvDatos, oLista, Me.txtFiltro.Text.ToUpper)
        MostrarTotales(oLista.Count, Me.lvDatos.Items.Count)
    End Sub
    Sub MostrarTotales(nCant As Integer, nFiltrados As Integer)
        Me.lblCantItems.Text = "Total : " & nCant
        Me.lblFiltro.Text = "Mostrando : " & nFiltrados
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim nId As Long
        Dim sError As String = ""

        If Me.lvDatos.SelectedItems.Count > 0 Then
            nId = CLng(Me.lvDatos.SelectedItems(0).Text)
            Me.oProvActual = Me.oLista.GetItem(nId)
            If MsgBox("¿ Confirma la eliminación del proveedor " & nId & " ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                oHandler.GrabarProveedor(Me.oProvActual, True, sError)
                Refrescar()
                GUI.LimpiarCampos(Me)
                Me.Nuevo = True
            End If
        End If
    End Sub

    Private Sub btnNuevo_Click(sender As Object, e As EventArgs) Handles btnNuevo.Click
        Me.Nuevo = True
        GUI.LimpiarCampos(Me)
        Me.oProvActual = New Proveedor
        Me.txtId.Text = oHandler.GetId(TABLA_PROVEEDORES)
        Me.txtId.Enabled = False
        Me.txtNombre.Focus()
    End Sub

    Private Sub txtFiltro_Enter(sender As Object, e As EventArgs) Handles txtFiltro.Enter
        Me.txtFiltro.BackColor = COLOR_SETEADO
        Me.txtFiltro.SelectAll()
    End Sub

    Private Sub txtFiltro_Leave(sender As Object, e As EventArgs) Handles txtFiltro.Leave
        Me.txtFiltro.BackColor = Color.White
        GUI.MostrarProveedores(Me.lvDatos, Me.oLista, Me.txtFiltro.Text.ToUpper)
        Me.MostrarTotales(Me.oLista.Count, Me.lvDatos.Items.Count)
    End Sub

    Private Sub frmProveedores_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        Me.SplitContainer1.Height = Me.Height - 88
        Me.lvDatos.Height = Me.SplitContainer1.Height - 38
    End Sub

    Private Sub txtFiltro_TextChanged(sender As Object, e As EventArgs) Handles txtFiltro.TextChanged

    End Sub
End Class