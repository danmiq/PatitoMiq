﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMantenimiento
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMantenimiento))
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.grBD = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btnBackUp = New System.Windows.Forms.Button()
        Me.txtArchivoBackup = New System.Windows.Forms.TextBox()
        Me.btnDirectorio = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtEmpresa = New System.Windows.Forms.TextBox()
        Me.btnGrabarEmpresa = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtRemitente = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTelRemitente = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtMail = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtClaveMail = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.chkPreguntaRespaldo = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblSettingBase = New System.Windows.Forms.Label()
        Me.lblSettingImagenes = New System.Windows.Forms.Label()
        Me.lblSettingReportes = New System.Windows.Forms.Label()
        Me.grBD.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(434, 380)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(85, 39)
        Me.btnSalir.TabIndex = 53
        Me.btnSalir.TabStop = False
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'grBD
        '
        Me.grBD.Controls.Add(Me.Button1)
        Me.grBD.Controls.Add(Me.btnBackUp)
        Me.grBD.Controls.Add(Me.txtArchivoBackup)
        Me.grBD.Controls.Add(Me.btnDirectorio)
        Me.grBD.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grBD.ForeColor = System.Drawing.Color.Navy
        Me.grBD.Location = New System.Drawing.Point(4, 291)
        Me.grBD.Name = "grBD"
        Me.grBD.Size = New System.Drawing.Size(517, 81)
        Me.grBD.TabIndex = 54
        Me.grBD.TabStop = False
        Me.grBD.Text = "Respaldo / Recuperación "
        '
        'Button1
        '
        Me.Button1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Black
        Me.Button1.Location = New System.Drawing.Point(440, 45)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(68, 30)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Recuperar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnBackUp
        '
        Me.btnBackUp.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBackUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackUp.ForeColor = System.Drawing.Color.Black
        Me.btnBackUp.Location = New System.Drawing.Point(440, 13)
        Me.btnBackUp.Name = "btnBackUp"
        Me.btnBackUp.Size = New System.Drawing.Size(68, 30)
        Me.btnBackUp.TabIndex = 5
        Me.btnBackUp.Text = "Respaldar"
        Me.btnBackUp.UseVisualStyleBackColor = True
        '
        'txtArchivoBackup
        '
        Me.txtArchivoBackup.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtArchivoBackup.ForeColor = System.Drawing.Color.Black
        Me.txtArchivoBackup.Location = New System.Drawing.Point(13, 18)
        Me.txtArchivoBackup.Name = "txtArchivoBackup"
        Me.txtArchivoBackup.Size = New System.Drawing.Size(331, 20)
        Me.txtArchivoBackup.TabIndex = 4
        '
        'btnDirectorio
        '
        Me.btnDirectorio.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDirectorio.ForeColor = System.Drawing.Color.Black
        Me.btnDirectorio.Location = New System.Drawing.Point(350, 16)
        Me.btnDirectorio.Name = "btnDirectorio"
        Me.btnDirectorio.Size = New System.Drawing.Size(35, 25)
        Me.btnDirectorio.TabIndex = 3
        Me.btnDirectorio.Text = "..."
        Me.btnDirectorio.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(4, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 55
        Me.Label1.Text = "Empresa"
        '
        'txtEmpresa
        '
        Me.txtEmpresa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmpresa.ForeColor = System.Drawing.Color.Black
        Me.txtEmpresa.Location = New System.Drawing.Point(60, 19)
        Me.txtEmpresa.Name = "txtEmpresa"
        Me.txtEmpresa.Size = New System.Drawing.Size(408, 20)
        Me.txtEmpresa.TabIndex = 56
        '
        'btnGrabarEmpresa
        '
        Me.btnGrabarEmpresa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGrabarEmpresa.ForeColor = System.Drawing.Color.Black
        Me.btnGrabarEmpresa.Image = CType(resources.GetObject("btnGrabarEmpresa.Image"), System.Drawing.Image)
        Me.btnGrabarEmpresa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGrabarEmpresa.Location = New System.Drawing.Point(442, 123)
        Me.btnGrabarEmpresa.Name = "btnGrabarEmpresa"
        Me.btnGrabarEmpresa.Size = New System.Drawing.Size(71, 32)
        Me.btnGrabarEmpresa.TabIndex = 57
        Me.btnGrabarEmpresa.Text = "Grabar"
        Me.btnGrabarEmpresa.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnGrabarEmpresa.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(18, 22)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 60
        Me.Label2.Text = "Base"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(18, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 61
        Me.Label3.Text = "Imagenes"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(18, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 63
        Me.Label4.Text = "Reportes"
        '
        'txtRemitente
        '
        Me.txtRemitente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtRemitente.ForeColor = System.Drawing.Color.Black
        Me.txtRemitente.Location = New System.Drawing.Point(60, 45)
        Me.txtRemitente.Name = "txtRemitente"
        Me.txtRemitente.Size = New System.Drawing.Size(246, 20)
        Me.txtRemitente.TabIndex = 65
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(4, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 64
        Me.Label5.Text = "Remitente"
        '
        'txtTelRemitente
        '
        Me.txtTelRemitente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelRemitente.ForeColor = System.Drawing.Color.Black
        Me.txtTelRemitente.Location = New System.Drawing.Point(60, 71)
        Me.txtTelRemitente.Name = "txtTelRemitente"
        Me.txtTelRemitente.Size = New System.Drawing.Size(170, 20)
        Me.txtTelRemitente.TabIndex = 67
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(4, 74)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(22, 13)
        Me.Label6.TabIndex = 66
        Me.Label6.Text = "Tel"
        '
        'txtMail
        '
        Me.txtMail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMail.ForeColor = System.Drawing.Color.Black
        Me.txtMail.Location = New System.Drawing.Point(60, 97)
        Me.txtMail.Name = "txtMail"
        Me.txtMail.Size = New System.Drawing.Size(170, 20)
        Me.txtMail.TabIndex = 69
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(6, 100)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 68
        Me.Label7.Text = "e-mail"
        '
        'txtClaveMail
        '
        Me.txtClaveMail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtClaveMail.ForeColor = System.Drawing.Color.Black
        Me.txtClaveMail.Location = New System.Drawing.Point(284, 97)
        Me.txtClaveMail.Name = "txtClaveMail"
        Me.txtClaveMail.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtClaveMail.Size = New System.Drawing.Size(151, 20)
        Me.txtClaveMail.TabIndex = 71
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(244, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 70
        Me.Label8.Text = "Clave"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chkPreguntaRespaldo
        '
        Me.chkPreguntaRespaldo.AutoSize = True
        Me.chkPreguntaRespaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPreguntaRespaldo.ForeColor = System.Drawing.Color.Black
        Me.chkPreguntaRespaldo.Location = New System.Drawing.Point(60, 132)
        Me.chkPreguntaRespaldo.Name = "chkPreguntaRespaldo"
        Me.chkPreguntaRespaldo.Size = New System.Drawing.Size(196, 17)
        Me.chkPreguntaRespaldo.TabIndex = 72
        Me.chkPreguntaRespaldo.Text = "Preguntar siempre Respaldar al Salir"
        Me.chkPreguntaRespaldo.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtEmpresa)
        Me.GroupBox2.Controls.Add(Me.chkPreguntaRespaldo)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.txtClaveMail)
        Me.GroupBox2.Controls.Add(Me.btnGrabarEmpresa)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.txtMail)
        Me.GroupBox2.Controls.Add(Me.txtRemitente)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.txtTelRemitente)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox2.Location = New System.Drawing.Point(4, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(517, 162)
        Me.GroupBox2.TabIndex = 73
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Parámetros "
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblSettingReportes)
        Me.GroupBox3.Controls.Add(Me.lblSettingImagenes)
        Me.GroupBox3.Controls.Add(Me.lblSettingBase)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox3.Location = New System.Drawing.Point(4, 173)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(517, 101)
        Me.GroupBox3.TabIndex = 74
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Archivo .config "
        '
        'lblSettingBase
        '
        Me.lblSettingBase.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSettingBase.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSettingBase.ForeColor = System.Drawing.Color.Black
        Me.lblSettingBase.Location = New System.Drawing.Point(76, 21)
        Me.lblSettingBase.Name = "lblSettingBase"
        Me.lblSettingBase.Size = New System.Drawing.Size(359, 17)
        Me.lblSettingBase.TabIndex = 64
        '
        'lblSettingImagenes
        '
        Me.lblSettingImagenes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSettingImagenes.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSettingImagenes.ForeColor = System.Drawing.Color.Black
        Me.lblSettingImagenes.Location = New System.Drawing.Point(76, 48)
        Me.lblSettingImagenes.Name = "lblSettingImagenes"
        Me.lblSettingImagenes.Size = New System.Drawing.Size(359, 17)
        Me.lblSettingImagenes.TabIndex = 65
        '
        'lblSettingReportes
        '
        Me.lblSettingReportes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSettingReportes.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSettingReportes.ForeColor = System.Drawing.Color.Black
        Me.lblSettingReportes.Location = New System.Drawing.Point(76, 71)
        Me.lblSettingReportes.Name = "lblSettingReportes"
        Me.lblSettingReportes.Size = New System.Drawing.Size(359, 17)
        Me.lblSettingReportes.TabIndex = 66
        '
        'frmMantenimiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(526, 421)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.grBD)
        Me.Controls.Add(Me.btnSalir)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMantenimiento"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Configuración"
        Me.grBD.ResumeLayout(False)
        Me.grBD.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents grBD As System.Windows.Forms.GroupBox
    Friend WithEvents btnBackUp As System.Windows.Forms.Button
    Friend WithEvents txtArchivoBackup As System.Windows.Forms.TextBox
    Friend WithEvents btnDirectorio As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents btnGrabarEmpresa As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtRemitente As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtTelRemitente As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtMail As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtClaveMail As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents chkPreguntaRespaldo As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lblSettingReportes As Label
    Friend WithEvents lblSettingImagenes As Label
    Friend WithEvents lblSettingBase As Label
End Class
