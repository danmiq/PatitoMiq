﻿Public Class frmBajaVenta

    Private Sub frmVenta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Inicializar()
    End Sub

    Sub Inicializar()
        Me.dtFecha.Value = Date.Today

        Dim aColumnas() As Tuple(Of String, String) = {New Tuple(Of String, String)("Codigo", "C"), New Tuple(Of String, String)("Articulo", "I"),
                New Tuple(Of String, String)("Cantidad", "D"), New Tuple(Of String, String)("Costo", "D"), New Tuple(Of String, String)("Precio", "D"),
                New Tuple(Of String, String)("SubTotCosto", "D"), New Tuple(Of String, String)("SubTotPrecio", "D"),
                New Tuple(Of String, String)("Proveedor", "I"),
                New Tuple(Of String, String)("IdVenta", "C")}

        InitGrilla(Me.grDatos, aColumnas)
        Me.grDatos.Columns(8).Width = 1
    End Sub
    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim sError As String
        Dim nIdVenta As Integer, nIdPrenda As Integer
        Dim sArticulo As String

        nIdPrenda = grDatos.Rows(grDatos.CurrentCell.RowIndex).Cells(0).Value
        sArticulo = grDatos.Rows(grDatos.CurrentCell.RowIndex).Cells(1).Value
        nIdVenta = grDatos.Rows(grDatos.CurrentCell.RowIndex).Cells(8).Value

        If MsgBox("¿ Eliminamos la venta de " & sArticulo & " (" & nIdPrenda & ") ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = vbYes Then
            If oHandler.BajaVenta(nIdVenta, nIdPrenda, sError) Then
                MsgBox("Venta anulada", MsgBoxStyle.Information)
                Me.Cargar(Me.dtFecha.Value)
            Else
                MsgBox("Error al anular la venta : " & sError, MsgBoxStyle.Critical)
            End If
        End If

    End Sub
    Function ValidarDatos(ByRef sError As String) As Boolean
        ValidarDatos = True
        sError = ""
    End Function
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Function Cargar(dFecha As Date) As Boolean
        Dim oVentas As List(Of ITEM_VENTA_DETALLE)
        Dim sFiltro As String

        sFiltro = "V.fec_venta >= " & Comillas(FechaUniversal(dFecha)) & " AND V.fec_venta <  " & Comillas(FechaUniversal(DateAdd(DateInterval.Day, 1, dFecha)))
        oVentas = oHandlerRep.GetVentasDetalle(sFiltro)
        CargarGrillaVentasParaBaja(Me.grDatos, oVentas)

        Cargar = (oVentas.Count > 0)

    End Function

    Private Sub btnCargar_Click(sender As Object, e As EventArgs) Handles btnCargar.Click
        If Not Me.Cargar(Me.dtFecha.Value) Then
            MsgBox("No existen ventas para ese día", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
        End If
    End Sub
End Class