Public Module Constantes
    Public COLOR_SETEADO = Color.FromArgb(204, 237, 160)
    Public Const FORMATO_IMPORTE As String = "###,###,##0.00"
    Public Const ARCHIVO_CONFIG As String = "Configuracion.config"
    Public Const FECHA_CENTINELA As String = "01/01/2020"

    ' Estos valores se cargan del .config
    Public CONEXION_SQL As String
    Public CARPETA_IMAGENES As String
    Public CARPETA_BASE As String
    Public CARPETA_REPORTES As String

    ' Parametros configurables por el usuario

    Public PARAM_NOMBRE_EMPRESA As String
    Public PARAM_NOMBRE_REMITENTE As String
    Public PARAM_TELEFONO_REMITENTE As String
    Public PARAM_CASILLA_MAIL As String
    Public PARAM_CLAVE_MAIL As String
    Public PARAM_PREGUNTAR_BACKUP As Integer

    Public Const TABLA_CATEGORIAS = "CATEGORIAS"
    Public Const TABLA_CONCEPTOS_GASTO = "CONCEPTO_GASTO"
    Public Const TABLA_ESTADOS = "ESTADOS"
    Public Const TABLA_TALLES = "TALLES"
    Public Const TABLA_MARCAS = "MARCAS"
    Public Const TABLA_COMISIONES = "COMISIONES"
    Public Const TABLA_CANALES = "CANALES"
    Public Const TABLA_MEDIOS_ENVIO = "MEDIOS_ENVIO"
    Public Const TABLA_VENTAS = "VENTAS"

    Public Const TABLA_CUPONES = "CUPONES"
    Public Const TABLA_PROMOS = "PROMOS"
    Public Const TABLA_PRENDAS = "PRENDAS"
    Public Const TABLA_CLIENTES = "CLIENTES"
    Public Const TABLA_PROVEEDORES = "PROVEEDORES"
    Public Const TABLA_LIQUIDACIONES = "LIQUIDACIONES"
    Public Const TABLA_TEMPORADAS = "TEMPORADAS"


    ' Esto se usa para decidir que hace el frmVentas : Reserva o Venta
    Public Enum T_ACCION
        VENTA = 1
        RESERVA = 2
        LIBERA_RESERVA = 3
    End Enum
    Public Enum T_STATUS
        DISPONIBLE = 1
        DISPONIBLE_VENTA_ANULADA = 2
        VENDIDA = 3
        DEVUELTA_PROVEEDOR = 4
    End Enum

    Public Structure T_LIQUIDACION
        Dim IdLiq As Integer
        Dim IdProv As Integer
        Dim NomProv As String
        Dim Fecha As Date
        Dim Importe As Double
        Dim Comision As Double
    End Structure
    Public Enum T_DESTINO
        EXCEL = 1
        PDF = 2
    End Enum
End Module

