Public Class DAOBase
    Friend oBase As AccesoBase.AccesoBaseSQL

    Public Sub New(ByVal b As Object)
        Me.oBase = b
    End Sub

    Public Function GetParametro(idParam As Integer, ByRef n As Integer) As Boolean
        Dim sSQL As String
        Dim ds As System.Data.DataSet
        n = 0
        GetParametro = False
        sSQL = "SELECT * FROM PARAMETROS WHERE id_parametro = " & idParam
        ds = oBase.Consultar(sSQL)

        If (ds.Tables(0).Rows.Count > 0) Then
            n = ds.Tables(0).Rows(0).Item("num_valor")
            GetParametro = True
        End If
        ds = Nothing

    End Function

    Public Function GetParametro(idParam As Integer, ByRef sValor As String) As Boolean
        Dim sSQL As String
        Dim ds As System.Data.DataSet
        sValor = ""
        GetParametro = False
        sSQL = "SELECT * FROM PARAMETROS WHERE id_parametro = " & idParam
        ds = oBase.Consultar(sSQL)

        If (ds.Tables(0).Rows.Count > 0) Then
            sValor = ds.Tables(0).Rows(0).Item("txt_valor")
            GetParametro = True
        End If
        ds = Nothing

    End Function
    Public Function GrabarParametro(idParam As Integer, ByRef sNombre As String, ByRef nValor As Integer) As Boolean
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        GrabarParametro = False
        sSQL = "SELECT * FROM PARAMETROS WHERE id_parametro = " & idParam

        Try
            ds = oBase.Consultar(sSQL)

            If (ds.Tables(0).Rows.Count > 0) Then
                sSQL = "UPDATE PARAMETROS SET Nombre = '" & sNombre & "', num_valor = " & nValor & " WHERE id_parametro = " & idParam
            Else
                sSQL = "INSERT INTO PARAMETROS( id_parametro,Nombre,num_valor) VALUES (" & idParam & "," & Comillas(sNombre) & "," & nValor & ")"
            End If
            oBase.Actualizar(sSQL)
            GrabarParametro = True
            ds = Nothing
        Catch

        End Try
    End Function
    Public Function GrabarParametro(idParam As Integer, ByRef sNombre As String, ByRef sValor As String) As Boolean
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        GrabarParametro = False
        sSQL = "Select * FROM PARAMETROS WHERE id_parametro = " & idParam

        Try
            ds = oBase.Consultar(sSQL)

            If (ds.Tables(0).Rows.Count > 0) Then
                sSQL = "UPDATE PARAMETROS Set Nombre = '" & sNombre & "', txt_valor = '" & sValor & "' WHERE id_parametro = " & idParam
            Else
                sSQL = "INSERT INTO PARAMETROS( id_parametro,Nombre,txt_valor) VALUES (" & idParam & ",'" & sNombre & "','" & sValor & "')"
            End If
            oBase.Actualizar(sSQL)
            GrabarParametro = True
            ds = Nothing
        Catch

        End Try
    End Function
    Public Function GetId(ByVal sTabla As String) As Long
        Dim sCampo As String

        If sTabla = TABLA_PRENDAS Then
            sCampo = "id_prenda"
        End If
        If sTabla = TABLA_PROVEEDORES Then
            sCampo = "id_proveedor"
        End If
        If sTabla = TABLA_CLIENTES Then
            sCampo = "id_contacto"
        End If
        If sTabla = TABLA_LIQUIDACIONES Then
            sCampo = "id_liquidacion"
        End If
        If sTabla = TABLA_CUPONES Then
            sCampo = "id_cupon"
        End If
        If sTabla = TABLA_PROMOS Then
            sCampo = "id_promo"
        End If
        If sTabla = TABLA_VENTAS Then
            sCampo = "id_venta"
        End If

        GetId = GetIdGenerico(sTabla, sCampo)
    End Function

    Function GetIdGenerico(ByVal sTabla, ByVal sCampoClave)
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        sSQL = "select max(" & sCampoClave & ") from " & sTabla
        ds = oBase.Consultar(sSQL)
        If ds.Tables(0).Rows.Count = 0 Then
            GetIdGenerico = 1
        Else
            If ds.Tables(0).Rows(0).Item(0) Is DBNull.Value Then
                GetIdGenerico = 1
            Else
                GetIdGenerico = (ds.Tables(0).Rows(0).Item(0) + 1)
            End If

        End If
        ds = Nothing
    End Function
    Function ExisteGenerico(ByVal sTabla As String, ByVal sCond As String) As Boolean
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        sSQL = "select count(*) from " & sTabla & " where " & sCond
        ds = oBase.Consultar(sSQL)

        ExisteGenerico = (ds.Tables(0).Rows(0).Item(0) > 0)
        Return ExisteGenerico
        ds = Nothing

    End Function

    Public Function Existe(ByVal sTabla As String, ByVal sCampoClave As String, ByVal sValor As Object) As Boolean
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        sSQL = "select count(*) from " & sTabla & " where " & sCampoClave & " = " & sValor
        ds = oBase.Consultar(sSQL)

        Existe = (ds.Tables(0).Rows(0).Item(0) > 0)
        ds = Nothing
    End Function
    Public Function GetClave(ByVal sTabla As String, ByVal sCampoClave As String, ByVal sCampoDesc As String, ByVal sValor As Object) As Long
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        sSQL = "select " & sCampoClave & " from " & sTabla & " where " & sCampoDesc & " = " & sValor
        ds = oBase.Consultar(sSQL)

        GetClave = ds.Tables(0).Rows(0).Item(0)
        ds = Nothing
    End Function

    Protected Overrides Sub Finalize()
        Me.oBase = Nothing
    End Sub


    Public Function GetColumnas(ByVal sTabla As String) As DataSet
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        sSQL = "select colorder as Id, name as Nombre, prec as Largo from syscolumns  where id = object_id('" & sTabla & "')"
        ds = oBase.Consultar(sSQL)
        Return (ds)
        ds = Nothing

    End Function
    Public Function CargarTablaCodigos(ByVal sTabla As String) As DataTable
        Dim sSQL As String
        Dim ds As System.Data.DataSet

        sSQL = "select  * from " & sTabla & " order by 1"
        ds = oBase.Consultar(sSQL)
        Return (ds.Tables(0))
        ds = Nothing

    End Function
    Public Function GrabarTablaCodigos(ByVal t As T_CLASE_CODIGOS, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim elem As DictionaryEntry
        Dim sValor As String
        Dim a() As String
        Dim nOper As Integer
        Dim nCodigo As Integer
        sError = ""
        Try
            For Each elem In t.Elementos
                a = elem.Value.ToString.Split("|")
                nOper = CInt(a(0))
                sValor = a(1)
                If Not IsNumeric(sValor) Then
                    sValor = "'" & sValor & "'"
                End If
                nCodigo = CInt(elem.Key)
                If nOper >= 0 Then
                    Select Case nOper
                        Case T_CLASE_CODIGOS.T_OPERACION.NUEVO
                            sSQL = "insert into " & t.Tabla & "(" & t.CampoCodigo & "," & t.CampoDesc & ") values (" & nCodigo & "," & sValor & ")"
                        Case T_CLASE_CODIGOS.T_OPERACION.MODIFICADO
                            sSQL = "update  " & t.Tabla & " set " & t.CampoDesc & " = " & sValor & " where " & t.CampoCodigo & " = " & nCodigo
                        Case T_CLASE_CODIGOS.T_OPERACION.ELIMINADO
                            sSQL = "delete from " & t.Tabla & " where " & t.CampoCodigo & " = " & nCodigo
                    End Select
                    oBase.Actualizar(sSQL)
                End If


            Next
            Return True
        Catch ex As Exception
            sError = ex.Message
            Return False
        End Try
    End Function

    Public Function BackUp(sArchivo As String, ByRef sError As String) As Boolean
        Dim sSQL As String
        BackUp = True
        Try
            sSQL = "BACKUP DATABASE [Lua] TO  DISK = N'" & sArchivo & "' WITH NOFORMAT, INIT,  NAME = N'Lua-Full Database Backup', SKIP, NOREWIND, NOUNLOAD, STATS = 10"

            oBase.Actualizar(sSQL)
        Catch ex As Exception
            sError = ex.Message
            BackUp = False
        End Try
    End Function

    Public Function Restore(sArchivo As String, ByRef sError As String) As Boolean
        Dim sSQL As String
        Restore = True
        Try
            sSQL = "USE [master]" & vbCrLf & _
                    "ALTER DATABASE [Lua] SET SINGLE_USER WITH ROLLBACK IMMEDIATE" & vbCrLf & _
                    "RESTORE DATABASE [Lua] FROM  DISK = '" & sArchivo & "' WITH  FILE = 1, " & _
                    "           NOUNLOAD, Replace, STATS = 5" & vbCrLf & _
                    "ALTER DATABASE [Lua] SET MULTI_USER" & vbCrLf

            oBase.Actualizar(sSQL)
        Catch ex As Exception
            sError = ex.Message
            Restore = False
        End Try
    End Function

End Class
