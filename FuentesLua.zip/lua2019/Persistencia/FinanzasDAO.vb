﻿Public Class FinanzasDAO
    Inherits DAOBase

    Public Sub New(ByVal obase As Object)
        MyBase.New(obase)
    End Sub

    Public Function Liquidar(nIdProv As Integer, dImporte As Double, dPjeComis As Double, sListaPrendas As String, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim nIdLiq As Integer

        Liquidar = True
        Try
            oBase.BeginTran()

            nIdLiq = GetId(TABLA_LIQUIDACIONES)

            sSQL = "UPDATE VENTAS SET id_liquidacion = " & nIdLiq & " WHERE id_prenda IN ( " & sListaPrendas & ")"
            oBase.Actualizar(sSQL)

            sSQL = "INSERT INTO LIQUIDACIONES(id_liquidacion,id_proveedor, Fecha, Importe, pje_comision ) VALUES (" & nIdLiq & "," & nIdProv & ", getdate()," & dImporte & "," & dPjeComis & ")"
            oBase.Actualizar(sSQL)

            oBase.CommitTran()
        Catch ex As Exception
            oBase.RollbackTran()
            Liquidar = False
            sError = ex.Message
        End Try
    End Function

    Friend Function CargarLiquidaciones() As List(Of T_LIQUIDACION)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New List(Of T_LIQUIDACION)
        Dim t As T_LIQUIDACION

        sSQL = "SELECT L.*, P.Nombre FROM LIQUIDACIONES L, PROVEEDORES P WHERE P.id_proveedor = L.id_proveedor ORDER BY id_liquidacion"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows

            t.IdLiq = r.Item("id_liquidacion")
            t.IdProv = r.Item("id_proveedor")
            t.Fecha = r.Item("Fecha")
            t.Comision = r.Item("pje_comision")
            t.Importe = r.Item("Importe")
            t.NomProv = r.Item("Nombre")

            oLista.Add(t)
        Next
        Return oLista
    End Function

End Class
