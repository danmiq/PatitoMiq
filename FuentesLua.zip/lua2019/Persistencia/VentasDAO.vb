﻿Public Class VentasDAO
    Inherits DAOBase

    Const sSQLPrincipal As String = "SELECT * FROM VENTAS"

    Public Sub New(ByVal obase As Object)
        MyBase.New(obase)
    End Sub
    Public Function Baja(idVenta As Integer, idPrenda As Integer, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim nCant As Integer

        Baja = True
        Try


            sSQL = "SELECT Cantidad FROM VENTAS WHERE id_venta = " & idVenta & " AND id_prenda = " & idPrenda
            d = oBase.Consultar(sSQL)
            nCant = CInt(d.Tables(0).Rows(0).Item(0))

            oBase.BeginTran()

            sSQL = "DELETE FROM VENTAS WHERE id_venta = " & idVenta & " AND id_prenda = " & idPrenda
            oBase.Actualizar(sSQL)

            sSQL = "UPDATE PRENDAS SET Stock = Stock + " & nCant & ", cod_status = " & T_STATUS.DISPONIBLE & " WHERE id_prenda = " & idPrenda
            oBase.Actualizar(sSQL)

            oBase.CommitTran()
        Catch ex As Exception
            oBase.RollbackTran()
            Baja = False
            sError = ex.Message
        End Try
    End Function
    Friend Function CargarLista(dFecDesde As Date, dFecHasta As Date) As List(Of ITEM_VENTA_RESUMEN)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New List(Of ITEM_VENTA_RESUMEN)
        Dim v As ITEM_VENTA_RESUMEN

        sSQL = "SELECT V.fec_venta as Fecha, sum(P.Costo * V.Cantidad) as ImporteCompra, sum(P.Precio * V.Cantidad) as ImporteVenta , count(distinct V.id_venta) as Cantidad " &
               " FROM VENTAS V" &
               " JOIN PRENDAS P ON V.id_prenda = P.id_prenda"
        sSQL = sSQL & " WHERE V.fec_venta >= " & Comillas(FechaUniversal(dFecDesde)) & " AND V.fec_venta <  " & Comillas(FechaUniversal(DateAdd(DateInterval.Day, 1, dFecHasta)))
        sSQL = sSQL & " GROUP BY V.fec_venta"
        sSQL = sSQL & " ORDER BY 1"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            v.Fecha = r.Item("Fecha")
            v.Cantidad = r.Item("Cantidad")
            v.ImporteCompra = r.Item("ImporteCompra")
            v.ImporteVenta = r.Item("ImporteVenta")
            oLista.Add(v)
        Next
        Return oLista
    End Function


    Public Function Vender(v As Venta, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim t As Venta.T_VENTA
        Dim nIdVenta As Integer

        Vender = True
        Try
            oBase.BeginTran()
            nIdVenta = GetId(TABLA_VENTAS)

            For Each t In v.aArticulos

                sSQL = "insert into VENTAS (id_venta,fec_venta, id_prenda, Precio, Cantidad) values (" + _
                           nIdVenta.ToString + "," + Comillas(FechaUniversal(v.Fecha)) + "," + t.CodPrenda.ToString + "," + t.Precio.ToString + "," + t.Cantidad.ToString + ")"
                oBase.Actualizar(sSQL)

                sSQL = "UPDATE PRENDAS SET Stock = Stock - " & t.Cantidad & " WHERE id_prenda = " & t.CodPrenda
                oBase.Actualizar(sSQL)

                sSQL = "UPDATE PRENDAS SET cod_status = " & T_STATUS.VENDIDA & " WHERE id_prenda = " & t.CodPrenda & " AND Stock = 0"
                oBase.Actualizar(sSQL)
            Next
            oBase.CommitTran()
        Catch ex As Exception
            oBase.RollbackTran()
            Vender = False
            sError = ex.Message
        End Try
    End Function

    Friend Function CargarLista(sFiltro As String) As List(Of ITEM_VENTA_DETALLE)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New List(Of ITEM_VENTA_DETALLE)
        Dim v As ITEM_VENTA_DETALLE

        sSQL = "SELECT P.id_prenda as IdPrenda, P.Descripcion, P.Costo, P.Precio, V.cantidad, P.id_proveedor, PR.Nombre as Proveedor, V.fec_venta as Fecha, V.id_venta" &
               " FROM VENTAS V" &
               " JOIN PRENDAS P ON V.id_prenda = P.id_prenda" &
               " JOIN PROVEEDORES PR ON P.id_proveedor = PR.id_proveedor"
        sSQL = sSQL & " WHERE " & sFiltro
        sSQL = sSQL & " ORDER BY V.fec_venta, P.id_prenda"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            v.Cantidad = r.Item("Cantidad")
            v.Costo = r.Item("Costo")
            v.IdProveedor = r.Item("id_proveedor")
            v.IdPrenda = r.Item("IdPrenda")
            v.Precio = r.Item("Precio")
            v.NomPrenda = r.Item("Descripcion")
            v.NomProveedor = r.Item("Proveedor")
            v.Fecha = r.Item("Fecha")
            v.IdVenta = r.Item("id_venta")
            oLista.Add(v)
        Next
        Return oLista
    End Function
    Friend Function GetDevoluciones(sFiltro As String) As List(Of ITEM_DEVOLUCION)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New List(Of ITEM_DEVOLUCION)
        Dim v As ITEM_DEVOLUCION

        sSQL = "SELECT P.id_prenda as IdPrenda, P.Descripcion, P.Costo, D.cantidad, D.fec_devolucion as Fecha" &
               " FROM DEVOLUCIONES D" &
               " JOIN PRENDAS P ON D.id_prenda = P.id_prenda"
        sSQL = sSQL & " WHERE " & sFiltro
        sSQL = sSQL & " ORDER BY D.fec_devolucion, P.id_prenda"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            v.Cantidad = r.Item("Cantidad")
            v.Costo = r.Item("Costo")
            v.IdPrenda = r.Item("IdPrenda")
            v.NomPrenda = r.Item("Descripcion")
            v.Fecha = r.Item("Fecha")
            oLista.Add(v)
        Next
        Return oLista
    End Function


End Class
