


Module Generales
    Public oHandler As Handler

#Region "VARIOS"
    Public Sub CargarProveedor(ByRef lblProv As Label, ByRef txtNombre As TextBox, Optional ByRef sMail As String = "")
        Dim oProvs As Proveedores
        Dim oProv As Proveedor
        Dim sFiltro As String

        lblProv.Text = ""

        If IsNumeric(txtNombre.Text) Then
            sFiltro = "id_proveedor = " & txtNombre.Text.Trim
        Else
            sFiltro = "upper(Nombre) LIKE '%" & txtNombre.Text.Trim.ToUpper & "%'"
        End If
        oProvs = oHandler.CargarProveedores(sFiltro)

        If oProvs.Items.Count > 0 Then
            If oProvs.Items.Count = 1 Then
                oProv = oProvs.Items(1)
            Else
                frmLista.Tabla = TABLA_PROVEEDORES
                frmLista.oLista = oProvs
                frmLista.MostrarDatos()
                frmLista.ShowDialog()
                If frmLista.DialogResult = Windows.Forms.DialogResult.OK Then
                    oProv = oHandler.CargarProveedor(frmLista.Id)
                End If
            End If
        End If
        If Not (oProv Is Nothing) Then
            lblProv.Text = oProv.Id
            txtNombre.Text = oProv.Nombre
            sMail = oProv.Mail
        Else
            MsgBox("No se encontr� Proveedor", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
        End If
    End Sub


    Public Function InputValor(nMax As Integer, sLeyenda As String, sTitulo As String, nDefault As Integer) As Integer
        Dim s As String = ""
        Dim bFin As Boolean = False

        While Not bFin
            s = InputBox(sLeyenda & " (hasta " & nMax & "):", sTitulo, nDefault)
            bFin = (s = "" Or IsNumeric(s))
            If IsNumeric(s) Then
                If CInt(s) > nMax Or CInt(s) < 1 Then
                    bFin = False
                End If
            End If
        End While
        If IsNumeric(s) Then
            Return CInt(s)
        Else
            Return nDefault
        End If
    End Function

    Function Comillas(sIn As String) As String
        Comillas = "'" & sIn & "'"
    End Function
    Function FiltrarTexto(sIn As String) As String
        FiltrarTexto = sIn.Replace("'", "�")
    End Function
    Public Function SINOtoBool(ByVal s As String) As Boolean
        Return (s = "SI")
    End Function

    Public Function BoolToNumber(ByVal b As Boolean) As Integer
        If b Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Public Function NumberToBool(ByVal n As Integer) As Boolean
        Return (n = 1)
    End Function
    Public Function BoolToSINO(ByVal b As Boolean) As String
        If b Then
            Return "SI"
        Else
            Return "NO"
        End If
    End Function

    Public Function FechaUniversal(ByVal d As DateTime, Optional ByVal bConSegundos As Boolean = False) As String
        If bConSegundos Then
            Return Format(d.Year, "0000") & Format(d.Month, "00") & Format(d.Day, "00") & " " & Format(d.Hour, "00") & ":" & Format(d.Minute, "00") & ":" & Format(d.Second, "00")
        Else
            Return Format(d.Year, "0000") & Format(d.Month, "00") & Format(d.Day, "00")
        End If
    End Function

    Public Function NoNulo(ByVal v As Object, ByVal vDefault As Object) As Object
        If v Is DBNull.Value Then
            Return vDefault
        Else
            Return v
        End If
    End Function
    Public Sub ValidarInt(ByRef e As Windows.Forms.KeyEventArgs)
        If (e.KeyCode >= Asc("0") And e.KeyCode <= Asc("9")) Or (e.KeyCode >= Windows.Forms.Keys.NumPad0 And e.KeyCode <= Windows.Forms.Keys.NumPad9) Or (e.KeyCode = Windows.Forms.Keys.Back Or e.KeyCode = Windows.Forms.Keys.Home Or e.KeyCode = Windows.Forms.Keys.Delete Or e.KeyCode = Windows.Forms.Keys.End Or e.KeyCode = Windows.Forms.Keys.Left Or e.KeyCode = Windows.Forms.Keys.Right) Then
            e.SuppressKeyPress = False
        Else
            e.SuppressKeyPress = True
        End If
    End Sub


    Function AbrirArchivoConfig(ByRef sError As String) As Boolean
        Dim s As String
        Dim a() As String
        Try
            Dim fr As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(ARCHIVO_CONFIG)

            While Not fr.EndOfStream
                s = fr.ReadLine
                a = s.Split("|")

                If a(0) = "CARPETA_IMAGENES" Then
                    CARPETA_IMAGENES = a(1)
                End If
                If a(0) = "CONEXION_SQL" Then
                    CONEXION_SQL = a(1)
                End If
                If a(0) = "CARPETA_BASE" Then
                    CARPETA_BASE = a(1)
                End If
                If a(0) = "CARPETA_REPORTES" Then
                    CARPETA_REPORTES = a(1)
                End If
            End While
            fr.Close()
            AbrirArchivoConfig = True
        Catch ex As Exception
            sError = "No se pudo abrir archivo " & ARCHIVO_CONFIG & vbCrLf & ex.Message
            AbrirArchivoConfig = False
        End Try

    End Function
#End Region
    Public Sub CargarParametros()
        PARAM_NOMBRE_EMPRESA = ""
        PARAM_NOMBRE_REMITENTE = ""
        PARAM_TELEFONO_REMITENTE = ""
        PARAM_CASILLA_MAIL = ""
        PARAM_CLAVE_MAIL = ""
        PARAM_TEXTO_MAIL = ""
        PARAM_PREGUNTAR_BACKUP = 1

        oHandler.GetParametro(1, PARAM_NOMBRE_EMPRESA)
        oHandler.GetParametro(2, PARAM_NOMBRE_REMITENTE)
        oHandler.GetParametro(3, PARAM_TELEFONO_REMITENTE)
        oHandler.GetParametro(4, PARAM_CASILLA_MAIL)
        oHandler.GetParametro(5, PARAM_CLAVE_MAIL)
        oHandler.GetParametro(6, PARAM_PREGUNTAR_BACKUP)
        oHandler.GetParametro(7, PARAM_TEXTO_MAIL)
    End Sub


End Module


