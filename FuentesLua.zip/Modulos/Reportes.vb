﻿Imports System.IO
Imports System.Net
Imports System.Net.Mail
Imports iText.IO.Image
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.Tuple

Module Reportes
    Public Structure ITEM_VENTA_RESUMEN
        Dim Fecha As Date
        Dim ImporteCompra As Double
        Dim ImporteVenta As Double
        Dim Cantidad As Integer
    End Structure

    Friend Structure ITEM_VENTA_DETALLE
        Dim IdPrenda As Integer
        Dim IdProveedor As Integer
        Dim Costo As Double
        Dim Precio As Double
        Dim Cantidad As Integer
        Dim NomPrenda As String
        Dim NomProveedor As String
        Dim Fecha As Date
        Dim IdVenta As Integer
    End Structure
    Friend Structure ITEM_DEVOLUCION
        Dim IdPrenda As Integer
        Dim Costo As Double
        Dim Cantidad As Integer
        Dim NomPrenda As String
        Dim Fecha As Date
    End Structure

    Public oHandlerRep As HandlerReporte

    Sub InitGrilla(ByRef gr As DataGridView, aColumnas() As Tuple(Of String, String))
        Dim s As Tuple(Of String, String)
        Dim col As DataGridViewTextBoxColumn

        gr.ShowEditingIcon = False
        gr.RowHeadersVisible = False

        For Each s In aColumnas
            col = New DataGridViewTextBoxColumn
            col.DataPropertyName = "PropertyName"
            col.HeaderText = s.Item1
            col.Name = "col" & s.Item1.Replace(" ", "")
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            If s.Item2 = "I" Then
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft
            Else
                If s.Item2 = "D" Then
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                Else
                    col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                End If
            End If

            gr.Columns.Add(col)
        Next

    End Sub

    Public Sub MostrarArchivo(sArchivo As String)
        ' Abre archivo XLS o PDF
        If Strings.Right(sArchivo, 4).ToUpper.Contains("XLS") Then

            Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
            p.EnableRaisingEvents = False
            System.Diagnostics.Process.Start("Excel.exe", sArchivo)
        Else
            System.Diagnostics.Process.Start(sArchivo)
        End If
    End Sub

    Public Sub MandaMail(sTo As String, sSubject As String, sBody As String, sAttach As String)
        Dim fromAddress As MailAddress
        Dim toAddress As MailAddress
        Dim fromPassword As String = PARAM_CLAVE_MAIL
        Dim subject As String = sSubject
        Dim body As String = sBody

        Try
            fromAddress = New MailAddress(PARAM_CASILLA_MAIL, PARAM_CASILLA_MAIL)
            toAddress = New MailAddress(sTo, "Nombre")

            Dim smtp = New SmtpClient With {
                .Host = "smtp.gmail.com",
                .Port = 587,
                .UseDefaultCredentials = False,
                .DeliveryMethod = SmtpDeliveryMethod.Network,
                .Credentials = New NetworkCredential(fromAddress.Address, fromPassword),
                .EnableSsl = True
            }

            Dim a As System.Net.Mail.Attachment

            If sAttach <> "" Then
                a = New System.Net.Mail.Attachment(sAttach)
            End If

            Using m = New MailMessage(fromAddress, toAddress) With {
                .Subject = subject,
                .Body = body
            }
                If sAttach <> "" Then
                    m.Attachments.Add(a)
                End If
                smtp.Send(m)
            End Using
        Catch ex As Exception
            MsgBox("Error al mandar el mail" & vbCrLf & ex.Message)
        End Try
    End Sub


    Sub AddTotales(ByRef gr As DataGridView, ByRef n As Integer, aDatos() As Tuple(Of Integer, Double))
        If n >= 0 Then
            n = gr.Rows.Add()
            gr.Rows(n).Cells(0).Value = "Totales"
            gr.Rows(n).Cells(0).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
            For Each t In aDatos
                gr.Rows(n).Cells(t.Item1).Value = Format(t.Item2, FORMATO_IMPORTE)
                gr.Rows(n).Cells(t.Item1).Style.Font = New Drawing.Font(gr.Font, FontStyle.Bold)
            Next
        End If
    End Sub

    Friend Sub CargarGrillaVentasProv(ByRef gr As DataGridView, oVentas As List(Of ITEM_VENTA_DETALLE))
        Dim v As ITEM_VENTA_DETALLE
        Dim r As DataGridViewRow
        Dim n As Integer = -1
        Dim nTotCosto As Double

        nTotCosto = 0

        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()
            gr.Rows(n).Cells(0).Value = Format(v.Fecha, "dd/MM/yyyy")
            gr.Rows(n).Cells(1).Value = v.IdPrenda
            gr.Rows(n).Cells(2).Value = v.NomPrenda
            gr.Rows(n).Cells(3).Value = v.Costo
            gr.Rows(n).Cells(4).Value = v.Cantidad
            gr.Rows(n).Cells(5).Value = Format(v.Costo * v.Cantidad, FORMATO_IMPORTE)

            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
        Next

        ' AddTotales(gr, n, {New Tuple(Of Integer, Double)(5, nTotCosto)})
    End Sub
    Friend Sub CargarGrillaDevoluciones(ByRef gr As DataGridView, oVentas As List(Of ITEM_DEVOLUCION))
        Dim v As ITEM_DEVOLUCION
        Dim r As DataGridViewRow
        Dim n As Integer = -1
        Dim nTotCosto As Double

        ' {"Fecha", "Codigo", "Articulo", "Costo", "Cantidad", "Subtotal"}

        nTotCosto = 0
        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()
            gr.Rows(n).Cells(0).Value = Format(v.Fecha, "dd/MM/yyyy")
            gr.Rows(n).Cells(1).Value = v.IdPrenda
            gr.Rows(n).Cells(2).Value = v.NomPrenda
            gr.Rows(n).Cells(3).Value = v.Costo
            gr.Rows(n).Cells(4).Value = v.Cantidad
            gr.Rows(n).Cells(5).Value = Format(v.Costo * v.Cantidad, FORMATO_IMPORTE)
            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
        Next

        ' AddTotales(gr, n, {New Tuple(Of Integer, Double)(5, nTotCosto)})
    End Sub

    Friend Sub CargarGrillaStockProv(ByRef gr As DataGridView, l As Prendas)
        gr.AutoGenerateColumns = False
        gr.Columns(0).DataPropertyName = "Id"
        gr.Columns(1).DataPropertyName = "Descripcion"
        gr.Columns(2).DataPropertyName = "Costo"
        gr.Columns(3).DataPropertyName = "Stock"
        gr.Columns(4).DataPropertyName = "Status"
        gr.Columns(5).DataPropertyName = "FecIngreso"
        gr.DataSource = l

    End Sub
    Friend Sub CargarGrillaStockProvManual(ByRef gr As DataGridView, l As Prendas)
        Dim p As Prenda
        Dim r As DataGridViewRow
        Dim n As Integer = -1
        Dim nTotCosto As Double

        nTotCosto = 0

        gr.Rows.Clear()

        For Each p In l
            r = New DataGridViewRow
            n = gr.Rows.Add()
            gr.Rows(n).Cells(0).Value = p.Id
            gr.Rows(n).Cells(1).Value = p.Descripcion
            gr.Rows(n).Cells(2).Value = p.Costo
            gr.Rows(n).Cells(3).Value = p.Stock
            gr.Rows(n).Cells(4).Value = Format(p.Costo * p.Stock, FORMATO_IMPORTE)
            gr.Rows(n).Cells(5).Value = p.Status
            nTotCosto = nTotCosto + Format((p.Costo * p.Stock), FORMATO_IMPORTE)
        Next

        ' AddTotales(gr, n, {New Tuple(Of Integer, Double)(4, nTotCosto)})
    End Sub

    Function GrillaToPDF(sPath As String, sArchivo As String, sTitulo As String, sParametros As String, ByRef g As DataGridView) As String
        Dim sArchGenerado As String = sPath & sArchivo & ".pdf"
        Dim pdfDoc As Document
        Dim tablaDatos As PdfPTable
        Dim P As Paragraph
        Dim cellvalue As String
        Dim celdaPdf As PdfPCell
        Dim i As Integer

        Dim sArchLogo As String = My.Application.Info.DirectoryPath & "\Logo.png"
        Dim oImagen As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(sArchLogo)
        oImagen.ScaleAbsolute(80, 30)

        ' Array de Columnas y sus anchos
        Dim colWidths As Single()
        ReDim colWidths(0 To g.ColumnCount - 1)
        For i = 0 To g.ColumnCount - 1
            colWidths(i) = System.Math.Round((g.Columns(i).Width / g.Width) * 100, 2)
        Next

        ' Crea tabla
        tablaDatos = New PdfPTable(colWidths)
        tablaDatos.WidthPercentage = 100
        tablaDatos.HorizontalAlignment = Element.ALIGN_LEFT
        tablaDatos.DefaultCell.Padding = 3
        tablaDatos.DefaultCell.BorderWidth = 1
        tablaDatos.DefaultCell.NoWrap = True

        ' Cabezales
        For Each column As DataGridViewColumn In g.Columns
            celdaPdf = New PdfPCell(New Phrase(column.HeaderText))
            celdaPdf.Phrase.Chunks(0).Font = New Font(Font.FontFamily.HELVETICA, 8, Font.BOLD)
            celdaPdf.BackgroundColor = New iTextSharp.text.BaseColor(240, 240, 240)
            tablaDatos.AddCell(celdaPdf)
        Next

        ' Datos
        cellvalue = ""
        Dim alinea As Integer

        For Each row As DataGridViewRow In g.Rows
            For Each cell As DataGridViewCell In row.Cells
                If IsNumeric(cell.Value) Then
                    alinea = Element.ALIGN_RIGHT
                Else
                    alinea = Element.ALIGN_LEFT
                End If
                celdaPdf = NuevaCelda(New Phrase(cell.Value, FontFactory.GetFont("Arial", 7)), alinea, Element.ALIGN_MIDDLE, True)
                tablaDatos.AddCell(celdaPdf)
            Next
        Next

        'Exporting to PDF

        If Not Directory.Exists(sPath) Then
            Directory.CreateDirectory(sPath)
        End If
        Using stream As New FileStream(sArchGenerado, FileMode.Create)
            pdfDoc = New Document
            PdfWriter.GetInstance(pdfDoc, stream)
            pdfDoc.Open()

            pdfDoc.AddTitle(sTitulo)

            Dim tablaHeader As PdfPTable = New PdfPTable({1.5, 1, 1})
            tablaHeader.WidthPercentage = 100
            tablaHeader.AddCell(NuevaCelda(sArchLogo, Element.ALIGN_LEFT))
            tablaHeader.AddCell(NuevaCelda(New Phrase(PARAM_NOMBRE_EMPRESA, FontFactory.GetFont("Arial", 8)), Element.ALIGN_MIDDLE, Element.ALIGN_TOP, False))
            tablaHeader.AddCell(NuevaCelda(New Phrase(Date.Now, FontFactory.GetFont("Arial", 7)), Element.ALIGN_RIGHT, Element.ALIGN_TOP, False))
            pdfDoc.Add(tablaHeader)

            P = New Paragraph(sTitulo, FontFactory.GetFont("Arial", 12))
            P.Alignment = 1
            pdfDoc.Add(P)
            P = New Paragraph(" ", FontFactory.GetFont("Arial", 12))
            pdfDoc.Add(P)

            P = New Paragraph(sParametros, FontFactory.GetFont("Arial", 10))
            P.Alignment = 1
            pdfDoc.Add(P)
            P = New Paragraph(" ", FontFactory.GetFont("Arial", 12))
            pdfDoc.Add(P)

            pdfDoc.Add(tablaDatos)
            pdfDoc.Close()
            stream.Close()
        End Using
        Return (sArchGenerado)
    End Function

    Public Function NuevaCelda(f As Phrase, alineamiento As Integer, vert As Integer, bConBorde As Boolean) As PdfPCell
        Dim cell As PdfPCell = New PdfPCell()
        Dim p As Paragraph = New Paragraph(f)
        p.Alignment = alineamiento
        cell.VerticalAlignment = vert
        cell.AddElement(p)
        If bConBorde Then
            cell.Border = Rectangle.LEFT_BORDER + Rectangle.RIGHT_BORDER + Rectangle.TOP_BORDER + Rectangle.BOTTOM_BORDER
        Else
            cell.Border = Rectangle.NO_BORDER
        End If
        Return cell
    End Function

    Public Function NuevaCelda(path As String, alineacion As Integer) As PdfPCell
        Dim img As Image = Image.GetInstance(path)
        img.ScaleAbsolute(80, 30)
        Dim cell As PdfPCell = New PdfPCell(img)
        cell.HorizontalAlignment = alineacion
        cell.Border = 0
        Return cell
    End Function

    Friend Sub CargarGrillaVentasEmpresa(ByRef gr As DataGridView, oVentas As List(Of ITEM_VENTA_DETALLE))
        Dim v As ITEM_VENTA_DETALLE
        Dim r As DataGridViewRow
        Dim n As Integer = -1
        Dim nTotCosto, nTotPrecio As Double

        nTotCosto = 0
        nTotPrecio = 0

        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()

            gr.Rows(n).Cells(0).Value = v.IdPrenda
            gr.Rows(n).Cells(1).Value = v.NomPrenda
            gr.Rows(n).Cells(2).Value = v.Cantidad
            gr.Rows(n).Cells(3).Value = Format(v.Costo, FORMATO_IMPORTE)
            gr.Rows(n).Cells(4).Value = Format(v.Precio, FORMATO_IMPORTE)
            gr.Rows(n).Cells(5).Value = Format(v.Costo * v.Cantidad, FORMATO_IMPORTE)
            gr.Rows(n).Cells(6).Value = Format(v.Precio * v.Cantidad, FORMATO_IMPORTE)
            gr.Rows(n).Cells(7).Value = v.NomProveedor
            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
            nTotPrecio = nTotPrecio + (v.Precio * v.Cantidad)
        Next

        AddTotales(gr, n, {New Tuple(Of Integer, Double)(5, nTotCosto), New Tuple(Of Integer, Double)(6, nTotPrecio)})
    End Sub

    Friend Sub CargarGrillaVentasParaBaja(ByRef gr As DataGridView, oVentas As List(Of ITEM_VENTA_DETALLE))
        Dim v As ITEM_VENTA_DETALLE
        Dim r As DataGridViewRow
        Dim n As Integer = -1
        Dim nTotCosto, nTotPrecio As Double

        nTotCosto = 0
        nTotPrecio = 0

        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()

            gr.Rows(n).Cells(0).Value = v.IdPrenda
            gr.Rows(n).Cells(1).Value = v.NomPrenda
            gr.Rows(n).Cells(2).Value = v.Cantidad
            gr.Rows(n).Cells(3).Value = Format(v.Costo, FORMATO_IMPORTE)
            gr.Rows(n).Cells(4).Value = Format(v.Precio, FORMATO_IMPORTE)
            gr.Rows(n).Cells(5).Value = Format(v.Costo * v.Cantidad, FORMATO_IMPORTE)
            gr.Rows(n).Cells(6).Value = Format(v.Precio * v.Cantidad, FORMATO_IMPORTE)
            gr.Rows(n).Cells(7).Value = v.NomProveedor
            gr.Rows(n).Cells(8).Value = v.IdVenta
            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
            nTotPrecio = nTotPrecio + (v.Precio * v.Cantidad)

        Next

    End Sub


End Module



