﻿Public Class PromoDAO
    Inherits DAOBase

    Const sSQLPrincipal As String = "SELECT PR.*, P.* FROM PROMOS PR " & _
                            " LEFT JOIN (PROMOS_PRENDAS PP JOIN V_PRENDAS P ON P.id_prenda = PP.id_prenda) ON PR.id_promo = PP.id_promo"

    Public Sub New(ByVal obase As Object)
        MyBase.New(obase)
    End Sub
    Public Function RemovePrendas(nIdPromo As Integer, nIdPrenda As Integer) As Boolean
        Dim sSQL As String
        
        Try
            sSQL = "DELETE FROM PROMOS_PRENDAS WHERE id_promo = " & nIdPromo
            If nIdPrenda <> 0 Then
                sSQL = sSQL & " AND id_prenda = " & nIdPrenda
            End If
            oBase.Actualizar(sSQL)

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    Public Function CargarLista(Optional sFiltro As String = "") As Promos
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As Promos = New Promos
        Dim oPromo As Promo
        Dim oPrenda As Prenda
        Dim nIdPromo As Integer = 0

        sSQL = sSQLPrincipal
        If sFiltro <> "" Then
            sSQL = sSQL & " WHERE " & sFiltro
        End If
        sSQL = sSQL & " ORDER BY PR.id_promo, P.id_prenda"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            If nIdPromo <> r.Item("id_promo") Then
                oPromo = New Promo()
                oPromo.Id = r.Item("id_promo")
                oPromo.Nombre = r.Item("Nombre")
                oPromo.Desde = r.Item("fec_vig_desde")
                oPromo.Hasta = r.Item("fec_vig_hasta")
                oPromo.Descuento = r.Item("pje_descuento")
                oLista.Items.Add(oPromo)
                nIdPromo = r.Item("id_promo")
            End If
            If sFiltro = "" Then
                If Not IsDBNull(r.Item("id_prenda")) Then
                    oPrenda = New Prenda
                    oPrenda.Id = r.Item("id_prenda")
                    oPrenda.Categoria = r.Item("NomCategoria")
                    oPrenda.Marca = r.Item("NomMarca")
                    oPrenda.Tamanio = r.Item("NomTamanio")
                    oPrenda.Precio = r.Item("Precio")
                    oPromo.Prendas.Items.Add(oPrenda)
                End If
            End If

        Next
        Return oLista
    End Function
    Public Function AddPrendas(nId As Integer, sListaPrendas As String, ByRef sError As String) As String
        Dim sSQL As String
        Dim d As System.Data.DataSet

        Try
            ' Averiguo cuantas voy a realmente insertar
            sSQL = " SELECT count(*) FROM PRENDAS WHERE id_prenda in (" & sListaPrendas & ")" & _
                "    AND id_prenda NOT IN (SELECT id_prenda FROM PROMOS_PRENDAS PP WHERE PP.id_promo = " & nId & ")" & _
                "    AND cod_status = " & T_STATUS.DISPONIBLE
            d = oBase.Consultar(sSQL)
            AddPrendas = d.Tables(0).Rows(0).Item(0)
            d = Nothing

            sSQL = "INSERT INTO PROMOS_PRENDAS (id_promo, id_prenda)" & _
                " SELECT " & nId & ", id_prenda FROM PRENDAS WHERE id_prenda in (" & sListaPrendas & ")" & _
                "    AND id_prenda NOT IN (SELECT id_prenda FROM PROMOS_PRENDAS PP WHERE PP.id_promo = " & nId & ")" & _
                "    AND cod_status = " & T_STATUS.DISPONIBLE
            oBase.Actualizar(sSQL)

            Return AddPrendas
        Catch ex As Exception
            Return -1
        End Try
    End Function
    Public Function ExisteBD(ByVal o As Promo) As Boolean
        Return Existe(TABLA_PROMOS, "id_promo", o.Id)
    End Function

    Public Function Grabar(ByVal o As Promo, ByVal bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim bOk As Boolean = True

        Try
            oBase.BeginTran()
            If Not bEliminar Then
                If ExisteBD(o) Then
                    sSQL = "UPDATE PROMOS SET Nombre = '" & o.Nombre & "', fec_vig_desde = '" & FechaUniversal(o.Desde) & _
                            "', fec_vig_hasta = '" & FechaUniversal(o.Hasta) & "', pje_descuento = " & o.Descuento & " WHERE id_promo = " & o.Id
                    oBase.Actualizar(sSQL)
                Else
                    sSQL = "insert into PROMOS (id_promo, Nombre, fec_vig_desde, fec_vig_hasta, pje_descuento) values (" & _
                            o.Id & ",'" & o.Nombre & "','" & FechaUniversal(o.Desde) & "','" & FechaUniversal(o.Hasta) & "'," & o.Descuento & ")"
                    oBase.Actualizar(sSQL)
                End If
            Else
                sSQL = "DELETE FROM PROMOS WHERE id_promo = " & o.Id
                oBase.Actualizar(sSQL)
            End If

            sError = ""
            oBase.CommitTran()

        Catch ex As Exception
            oBase.RollbackTran()
            sError = ex.Message
            bOk = False
        End Try
        Return bOk
    End Function

End Class
