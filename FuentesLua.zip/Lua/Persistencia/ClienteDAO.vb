﻿Public Class ClienteDAO
    Inherits DAOBase

    Const sSQLPrincipal As String = "SELECT *, " & _
                                    " (SELECT COUNT(*) FROM VENTAS WHERE id_contacto = C.id_contacto) as CantCompras ," & _
                                    " (SELECT COUNT(*) FROM CUPONES CU WHERE CU.id_cliente = C.id_contacto) as CantCupones " & _
                                    " FROM CLIENTES C"

    Public Sub New(ByVal obase As Object)
        MyBase.New(obase)
    End Sub

    Public Function EntregarCupon(nIdCliente As Integer, nIdCupon As Integer, dPje As Double, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim bOk As Boolean = True


        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        
        sSQL = "SELECT * FROM CUPONES U, CLIENTES C WHERE U.id_cupon = " & nIdCupon & " AND U.id_cliente = C.id_contacto"

        d = oBase.Consultar(sSQL)
        If d.Tables(0).Rows.Count > 0 Then
            bOk = False
            sError = "El cupon " & nIdCupon & " ya fue entregado a " & d.Tables(0).Rows(0).Item("Nombre")
        Else
            Try
                oBase.BeginTran()
                sSQL = "INSERT INTO CUPONES (id_cupon, fec_emitido, pje_descuento, fec_usado, id_cliente) VALUES (" & nIdCupon & ",getdate()," & dPje & ",NULL," & nIdCliente & ")"
                oBase.Actualizar(sSQL)

                sError = ""
                oBase.CommitTran()

            Catch ex As Exception
                oBase.RollbackTran()
                sError = ex.Message
                bOk = False
            End Try
        End If
        Return bOk

    End Function

    Public Function CargarLista(sFiltro As String, bSoloCuponesDisponibles As Boolean) As Clientes
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim oLista As New Clientes
        Dim p As Cliente

        Try
            sSQL = sSQLPrincipal
            If sFiltro <> "" Then
                sSQL = sSQL & " WHERE " & sFiltro
            End If
            sSQL = sSQL & " ORDER BY id_contacto"

            d = oBase.Consultar(sSQL)
            For Each r In d.Tables(0).Rows
                p = New Cliente()
                p.Id = r.Item("id_contacto")
                p.Nombre = NoNulo(r.Item("Nombre"), "")
                p.Direccion = NoNulo(r.Item("Direccion"), "")
                p.Telefono = NoNulo(r.Item("Telefono"), "")
                p.Mail = NoNulo(r.Item("Mail"), "")
                p.FecIngreso = NoNulo(r.Item("FecIngreso"), "")
                p.CantCompras = r.Item("CantCompras")
                p.CantCupones = r.Item("CantCupones")
                p.Credito = NoNulo(r.Item("imp_credito"), 0)
                ' CargarCupones(p, bSoloCuponesDisponibles)
                oLista.Items.Add(p)
            Next
        Catch ex As Exception
            Stop
        End Try
        Return oLista
    End Function

    Public Function Cargar(ByVal idObjeto As Integer) As Cliente
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim p As Cliente

        sSQL = sSQLPrincipal & " WHERE id_contacto = " & idObjeto

        d = oBase.Consultar(sSQL)
        If d.Tables(0).Rows.Count > 0 Then
            r = d.Tables(0).Rows(0)
            p = New Cliente()
            p.Id = r.Item("id_contacto")
            p.Direccion = NoNulo(r.Item("Direccion"), "")
            p.Telefono = NoNulo(r.Item("Telefono"), "")
            p.Mail = NoNulo(r.Item("Mail"), "")
            p.FecIngreso = NoNulo(r.Item("FecIngreso"), "")
            p.CantCompras = r.Item("CantCompras")
            p.CantCupones = r.Item("CantCupones")
            p.Credito = r.Item("imp_credito")
            CargarCupones(p, False)
        End If
        Return p
    End Function
    Public Function CargarCupones(ByRef o As Cliente, bSoloDisponibles As Boolean)
        Dim sSQL As String
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim c As Cupon

        sSQL = "SELECT * FROM CUPONES WHERE id_cliente = " & o.Id
        If bSoloDisponibles Then
            sSQL = sSQL & " AND fec_usado IS NULL"
        End If
        sSQL = sSQL & " ORDER BY id_cupon"

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            c = New Cupon
            c.IdCupon = r.Item("id_cupon")
            c.IdCliente = o.Id
            c.FecEntrega = r.Item("fec_emitido")
            c.FecUsado = NoNulo(r.Item("fec_usado"), FECHA_CENTINELA)
            c.PjeDescuento = r.Item("pje_descuento")
            o.Cupones.Items.Add(c)
        Next

    End Function

    Public Function Grabar(ByVal o As Cliente, ByVal bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim sSQL As String
        Dim bOk As Boolean = True

        Try
            oBase.BeginTran()
            If Not bEliminar Then
                If ExisteBD(o) Then
                    sSQL = "UPDATE CLIENTES SET " & _
                        " Telefono = '" & o.Telefono & "', Nombre = '" & o.Nombre & "'" & _
                        " , Direccion = '" & o.Direccion & "', Mail = '" & o.Mail & "'" & _
                     " WHERE id_contacto = " & o.Id
                    oBase.Actualizar(sSQL)
                Else
                    sSQL = "insert into CLIENTES (id_contacto ,Nombre ,Telefono, Direccion, Mail, imp_credito) values (" & _
                            o.Id & ",'" & o.Nombre & "','" & o.Telefono & "','" & o.Direccion & "'," & Comillas(o.Mail) & ",0)"
                    oBase.Actualizar(sSQL)
                End If

            Else
                sSQL = "DELETE FROM CLIENTES WHERE id_contacto = " & o.Id
                oBase.Actualizar(sSQL)
            End If

            sError = ""
            oBase.CommitTran()

        Catch ex As Exception
            oBase.RollbackTran()
            sError = ex.Message
            bOk = False
        End Try
        Return bOk
    End Function

    Public Function ExisteBD(ByVal o As Cliente) As Boolean
        Return Existe(TABLA_CLIENTES, "id_contacto", o.Id)
    End Function
    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub


End Class
