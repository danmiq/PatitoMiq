<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblVersion = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.mnuPrendas = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProveedoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClientes = New System.Windows.Forms.ToolStripMenuItem()
        Me.VentasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuConsultas = New System.Windows.Forms.ToolStripMenuItem()
        Me.MercaderiaPorProveedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CajaventasPorDiaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMantenimiento = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuABMTablas = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuConfiguracion = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLiquidaciones = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPromos = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSalir = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip.SuspendLayout()
        Me.MenuStrip.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblVersion})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 437)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.StatusStrip.Size = New System.Drawing.Size(739, 24)
        Me.StatusStrip.TabIndex = 9
        Me.StatusStrip.Text = "StatusStrip"
        '
        'lblVersion
        '
        Me.lblVersion.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(50, 19)
        Me.lblVersion.Text = "Versi�n"
        '
        'MenuStrip
        '
        Me.MenuStrip.BackColor = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(225, Byte), Integer))
        Me.MenuStrip.Dock = System.Windows.Forms.DockStyle.Left
        Me.MenuStrip.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPrendas, Me.ProveedoresToolStripMenuItem, Me.mnuClientes, Me.VentasToolStripMenuItem, Me.mnuConsultas, Me.mnuMantenimiento, Me.mnuLiquidaciones, Me.mnuPromos, Me.ToolStripMenuItem1, Me.mnuSalir})
        Me.MenuStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Padding = New System.Windows.Forms.Padding(5, 2, 0, 2)
        Me.MenuStrip.Size = New System.Drawing.Size(137, 437)
        Me.MenuStrip.TabIndex = 10
        Me.MenuStrip.Text = "MenuStrip"
        '
        'mnuPrendas
        '
        Me.mnuPrendas.Image = CType(resources.GetObject("mnuPrendas.Image"), System.Drawing.Image)
        Me.mnuPrendas.Name = "mnuPrendas"
        Me.mnuPrendas.Size = New System.Drawing.Size(113, 28)
        Me.mnuPrendas.Text = "Mercader�a"
        '
        'ProveedoresToolStripMenuItem
        '
        Me.ProveedoresToolStripMenuItem.Image = CType(resources.GetObject("ProveedoresToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ProveedoresToolStripMenuItem.Name = "ProveedoresToolStripMenuItem"
        Me.ProveedoresToolStripMenuItem.Size = New System.Drawing.Size(123, 28)
        Me.ProveedoresToolStripMenuItem.Text = "Proveedores"
        '
        'mnuClientes
        '
        Me.mnuClientes.Image = CType(resources.GetObject("mnuClientes.Image"), System.Drawing.Image)
        Me.mnuClientes.Name = "mnuClientes"
        Me.mnuClientes.Size = New System.Drawing.Size(92, 28)
        Me.mnuClientes.Text = "Clientes"
        '
        'VentasToolStripMenuItem
        '
        Me.VentasToolStripMenuItem.Image = CType(resources.GetObject("VentasToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VentasToolStripMenuItem.Name = "VentasToolStripMenuItem"
        Me.VentasToolStripMenuItem.Size = New System.Drawing.Size(86, 28)
        Me.VentasToolStripMenuItem.Text = "Ventas"
        '
        'mnuConsultas
        '
        Me.mnuConsultas.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MercaderiaPorProveedorToolStripMenuItem, Me.CajaventasPorDiaToolStripMenuItem})
        Me.mnuConsultas.Image = CType(resources.GetObject("mnuConsultas.Image"), System.Drawing.Image)
        Me.mnuConsultas.Name = "mnuConsultas"
        Me.mnuConsultas.Size = New System.Drawing.Size(95, 28)
        Me.mnuConsultas.Text = "Listados"
        '
        'MercaderiaPorProveedorToolStripMenuItem
        '
        Me.MercaderiaPorProveedorToolStripMenuItem.Name = "MercaderiaPorProveedorToolStripMenuItem"
        Me.MercaderiaPorProveedorToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.MercaderiaPorProveedorToolStripMenuItem.Text = "Proveedores"
        '
        'CajaventasPorDiaToolStripMenuItem
        '
        Me.CajaventasPorDiaToolStripMenuItem.Name = "CajaventasPorDiaToolStripMenuItem"
        Me.CajaventasPorDiaToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.CajaventasPorDiaToolStripMenuItem.Text = "Ventas"
        '
        'mnuMantenimiento
        '
        Me.mnuMantenimiento.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuABMTablas, Me.mnuConfiguracion})
        Me.mnuMantenimiento.Image = CType(resources.GetObject("mnuMantenimiento.Image"), System.Drawing.Image)
        Me.mnuMantenimiento.Name = "mnuMantenimiento"
        Me.mnuMantenimiento.Size = New System.Drawing.Size(131, 28)
        Me.mnuMantenimiento.Text = "Mantenimiento"
        '
        'mnuABMTablas
        '
        Me.mnuABMTablas.Image = CType(resources.GetObject("mnuABMTablas.Image"), System.Drawing.Image)
        Me.mnuABMTablas.Name = "mnuABMTablas"
        Me.mnuABMTablas.Size = New System.Drawing.Size(166, 30)
        Me.mnuABMTablas.Text = "Tablas"
        '
        'mnuConfiguracion
        '
        Me.mnuConfiguracion.Image = CType(resources.GetObject("mnuConfiguracion.Image"), System.Drawing.Image)
        Me.mnuConfiguracion.Name = "mnuConfiguracion"
        Me.mnuConfiguracion.Size = New System.Drawing.Size(166, 30)
        Me.mnuConfiguracion.Text = "Configuracion"
        '
        'mnuLiquidaciones
        '
        Me.mnuLiquidaciones.Enabled = False
        Me.mnuLiquidaciones.Image = CType(resources.GetObject("mnuLiquidaciones.Image"), System.Drawing.Image)
        Me.mnuLiquidaciones.Name = "mnuLiquidaciones"
        Me.mnuLiquidaciones.Size = New System.Drawing.Size(128, 28)
        Me.mnuLiquidaciones.Text = "Liquidaciones"
        '
        'mnuPromos
        '
        Me.mnuPromos.Enabled = False
        Me.mnuPromos.Image = CType(resources.GetObject("mnuPromos.Image"), System.Drawing.Image)
        Me.mnuPromos.Name = "mnuPromos"
        Me.mnuPromos.Size = New System.Drawing.Size(91, 28)
        Me.mnuPromos.Text = "Promos"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(132, 20)
        Me.ToolStripMenuItem1.Text = "----------------------------"
        '
        'mnuSalir
        '
        Me.mnuSalir.Image = CType(resources.GetObject("mnuSalir.Image"), System.Drawing.Image)
        Me.mnuSalir.Name = "mnuSalir"
        Me.mnuSalir.Size = New System.Drawing.Size(74, 28)
        Me.mnuSalir.Text = " Salir"
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(137, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(602, 437)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(739, 461)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip)
        Me.Controls.Add(Me.StatusStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "frmMain"
        Me.Text = "Second Hand"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents lblVersion As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuPrendas As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuConsultas As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMantenimiento As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSalir As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents mnuABMTablas As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPromos As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuClientes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLiquidaciones As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuConfiguracion As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProveedoresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VentasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MercaderiaPorProveedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CajaventasPorDiaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
