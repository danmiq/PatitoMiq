﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListadosVentas
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmListadosVentas))
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnBuscar = New System.Windows.Forms.Button()
        Me.panelVentas = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtHasta = New System.Windows.Forms.DateTimePicker()
        Me.dtDesde = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbPDF = New System.Windows.Forms.RadioButton()
        Me.rbExcel = New System.Windows.Forms.RadioButton()
        Me.btnListar = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.lvDatos = New System.Windows.Forms.ListView()
        Me.colFecha = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colImporte = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colImporteVenta = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCant = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grDatos = New System.Windows.Forms.DataGridView()
        Me.panelVentas.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.grDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBuscar
        '
        Me.btnBuscar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBuscar.Location = New System.Drawing.Point(357, 3)
        Me.btnBuscar.Name = "btnBuscar"
        Me.btnBuscar.Size = New System.Drawing.Size(55, 27)
        Me.btnBuscar.TabIndex = 101
        Me.btnBuscar.Text = "Buscar"
        Me.btnBuscar.UseVisualStyleBackColor = True
        '
        'panelVentas
        '
        Me.panelVentas.Controls.Add(Me.Label2)
        Me.panelVentas.Controls.Add(Me.dtHasta)
        Me.panelVentas.Controls.Add(Me.dtDesde)
        Me.panelVentas.Location = New System.Drawing.Point(6, 3)
        Me.panelVentas.Name = "panelVentas"
        Me.panelVentas.Size = New System.Drawing.Size(345, 26)
        Me.panelVentas.TabIndex = 100
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(2, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Vendidas entre"
        '
        'dtHasta
        '
        Me.dtHasta.CustomFormat = "dd/MM/yyyy"
        Me.dtHasta.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtHasta.Location = New System.Drawing.Point(228, 4)
        Me.dtHasta.Name = "dtHasta"
        Me.dtHasta.Size = New System.Drawing.Size(101, 20)
        Me.dtHasta.TabIndex = 1
        '
        'dtDesde
        '
        Me.dtDesde.CustomFormat = "dd/MM/yyyy"
        Me.dtDesde.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtDesde.Location = New System.Drawing.Point(121, 4)
        Me.dtDesde.Name = "dtDesde"
        Me.dtDesde.Size = New System.Drawing.Size(101, 20)
        Me.dtDesde.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.rbPDF)
        Me.GroupBox1.Controls.Add(Me.rbExcel)
        Me.GroupBox1.Controls.Add(Me.btnListar)
        Me.GroupBox1.Location = New System.Drawing.Point(458, 440)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(244, 40)
        Me.GroupBox1.TabIndex = 99
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Destino "
        '
        'rbPDF
        '
        Me.rbPDF.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.rbPDF.Location = New System.Drawing.Point(76, 14)
        Me.rbPDF.Name = "rbPDF"
        Me.rbPDF.Size = New System.Drawing.Size(58, 20)
        Me.rbPDF.TabIndex = 1
        Me.rbPDF.TabStop = True
        Me.rbPDF.Text = "PDF"
        Me.rbPDF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbPDF.UseVisualStyleBackColor = True
        '
        'rbExcel
        '
        Me.rbExcel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.rbExcel.Location = New System.Drawing.Point(16, 15)
        Me.rbExcel.Name = "rbExcel"
        Me.rbExcel.Size = New System.Drawing.Size(54, 18)
        Me.rbExcel.TabIndex = 0
        Me.rbExcel.TabStop = True
        Me.rbExcel.Text = "Excel"
        Me.rbExcel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.rbExcel.UseVisualStyleBackColor = True
        '
        'btnListar
        '
        Me.btnListar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnListar.Location = New System.Drawing.Point(140, 13)
        Me.btnListar.Name = "btnListar"
        Me.btnListar.Size = New System.Drawing.Size(73, 24)
        Me.btnListar.TabIndex = 0
        Me.btnListar.Text = "Exportar"
        Me.btnListar.UseVisualStyleBackColor = True
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatus.ForeColor = System.Drawing.Color.Navy
        Me.lblStatus.Location = New System.Drawing.Point(12, 451)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(430, 23)
        Me.lblStatus.TabIndex = 98
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(791, 440)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(73, 36)
        Me.btnSalir.TabIndex = 97
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'lvDatos
        '
        Me.lvDatos.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colFecha, Me.colImporte, Me.colImporteVenta, Me.colCant})
        Me.lvDatos.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvDatos.FullRowSelect = True
        Me.lvDatos.GridLines = True
        Me.lvDatos.HideSelection = False
        Me.lvDatos.Location = New System.Drawing.Point(12, 54)
        Me.lvDatos.Name = "lvDatos"
        Me.lvDatos.Size = New System.Drawing.Size(280, 381)
        Me.lvDatos.TabIndex = 102
        Me.lvDatos.UseCompatibleStateImageBehavior = False
        Me.lvDatos.View = System.Windows.Forms.View.Details
        '
        'colFecha
        '
        Me.colFecha.Text = "Día"
        Me.colFecha.Width = 69
        '
        'colImporte
        '
        Me.colImporte.Text = "Imp. Compra"
        Me.colImporte.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colImporte.Width = 67
        '
        'colImporteVenta
        '
        Me.colImporteVenta.Text = "Imp. Venta"
        Me.colImporteVenta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colCant
        '
        Me.colCant.Text = "Cantidad"
        Me.colCant.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 13)
        Me.Label1.TabIndex = 103
        Me.Label1.Text = "Fechas de Ventas"
        '
        'grDatos
        '
        Me.grDatos.AllowUserToAddRows = False
        Me.grDatos.AllowUserToDeleteRows = False
        Me.grDatos.AllowUserToOrderColumns = True
        Me.grDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.grDatos.DefaultCellStyle = DataGridViewCellStyle2
        Me.grDatos.Location = New System.Drawing.Point(298, 54)
        Me.grDatos.Name = "grDatos"
        Me.grDatos.ReadOnly = True
        Me.grDatos.Size = New System.Drawing.Size(566, 381)
        Me.grDatos.TabIndex = 104
        '
        'frmListadosVentas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(876, 483)
        Me.Controls.Add(Me.grDatos)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lvDatos)
        Me.Controls.Add(Me.btnBuscar)
        Me.Controls.Add(Me.panelVentas)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.btnSalir)
        Me.Name = "frmListadosVentas"
        Me.Text = "Ventas"
        Me.panelVentas.ResumeLayout(False)
        Me.panelVentas.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.grDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnBuscar As System.Windows.Forms.Button
    Friend WithEvents panelVentas As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtHasta As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtDesde As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbPDF As System.Windows.Forms.RadioButton
    Friend WithEvents rbExcel As System.Windows.Forms.RadioButton
    Friend WithEvents btnListar As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents lvDatos As System.Windows.Forms.ListView
    Friend WithEvents colFecha As System.Windows.Forms.ColumnHeader
    Friend WithEvents colImporte As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grDatos As System.Windows.Forms.DataGridView
    Friend WithEvents colImporteVenta As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCant As System.Windows.Forms.ColumnHeader
End Class
