﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLiquidaciones
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLiquidaciones))
        Me.lvPrendas = New System.Windows.Forms.ListView()
        Me.id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Categoria = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Marca = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Precio = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Comentarios = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colFecVenta = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCliente = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboProveedor = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblComisionProv = New System.Windows.Forms.Label()
        Me.lblImpPagar = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnGenerar = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.colId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colNomProv = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colFecha = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colImporte = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCodComision = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cboComisiones = New System.Windows.Forms.ComboBox()
        Me.lblCantidad = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblImpVendido = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.chkUsarOtra = New System.Windows.Forms.CheckBox()
        Me.btnRecalcular = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lvPrendas
        '
        Me.lvPrendas.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvPrendas.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.id, Me.Categoria, Me.Marca, Me.Precio, Me.Comentarios, Me.colFecVenta, Me.colCliente})
        Me.lvPrendas.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvPrendas.FullRowSelect = True
        Me.lvPrendas.GridLines = True
        Me.lvPrendas.HideSelection = False
        Me.lvPrendas.Location = New System.Drawing.Point(5, 31)
        Me.lvPrendas.Name = "lvPrendas"
        Me.lvPrendas.Size = New System.Drawing.Size(489, 383)
        Me.lvPrendas.TabIndex = 2
        Me.lvPrendas.TabStop = False
        Me.lvPrendas.UseCompatibleStateImageBehavior = False
        Me.lvPrendas.View = System.Windows.Forms.View.Details
        '
        'id
        '
        Me.id.Text = "Id"
        Me.id.Width = 34
        '
        'Categoria
        '
        Me.Categoria.Text = "Categoria"
        Me.Categoria.Width = 64
        '
        'Marca
        '
        Me.Marca.Text = "Marca"
        Me.Marca.Width = 69
        '
        'Precio
        '
        Me.Precio.Text = "Precio"
        Me.Precio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Precio.Width = 50
        '
        'Comentarios
        '
        Me.Comentarios.Text = "Comentarios"
        Me.Comentarios.Width = 150
        '
        'colFecVenta
        '
        Me.colFecVenta.Text = "Vendida"
        '
        'colCliente
        '
        Me.colCliente.Text = "Cliente"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(2, 10)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "Proveedor"
        '
        'cboProveedor
        '
        Me.cboProveedor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProveedor.FormattingEnabled = True
        Me.cboProveedor.Location = New System.Drawing.Point(60, 5)
        Me.cboProveedor.Name = "cboProveedor"
        Me.cboProveedor.Size = New System.Drawing.Size(163, 21)
        Me.cboProveedor.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(242, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "Comisión"
        '
        'lblComisionProv
        '
        Me.lblComisionProv.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblComisionProv.Location = New System.Drawing.Point(290, 9)
        Me.lblComisionProv.Name = "lblComisionProv"
        Me.lblComisionProv.Size = New System.Drawing.Size(34, 17)
        Me.lblComisionProv.TabIndex = 48
        '
        'lblImpPagar
        '
        Me.lblImpPagar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblImpPagar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblImpPagar.Location = New System.Drawing.Point(400, 422)
        Me.lblImpPagar.Name = "lblImpPagar"
        Me.lblImpPagar.Size = New System.Drawing.Size(64, 19)
        Me.lblImpPagar.TabIndex = 50
        Me.lblImpPagar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(305, 425)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 13)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "Comisión a pagar "
        '
        'btnGenerar
        '
        Me.btnGenerar.Location = New System.Drawing.Point(500, 63)
        Me.btnGenerar.Name = "btnGenerar"
        Me.btnGenerar.Size = New System.Drawing.Size(69, 34)
        Me.btnGenerar.TabIndex = 51
        Me.btnGenerar.TabStop = False
        Me.btnGenerar.Text = "Liquidar"
        Me.btnGenerar.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(787, 420)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(85, 39)
        Me.btnSalir.TabIndex = 52
        Me.btnSalir.TabStop = False
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colId, Me.colNomProv, Me.colFecha, Me.colImporte, Me.colCodComision})
        Me.ListView1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Location = New System.Drawing.Point(575, 47)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(305, 367)
        Me.ListView1.TabIndex = 53
        Me.ListView1.TabStop = False
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'colId
        '
        Me.colId.Text = "Id"
        Me.colId.Width = 34
        '
        'colNomProv
        '
        Me.colNomProv.Text = "Proveedor"
        Me.colNomProv.Width = 90
        '
        'colFecha
        '
        Me.colFecha.Text = "Fecha"
        Me.colFecha.Width = 70
        '
        'colImporte
        '
        Me.colImporte.Text = "Importe"
        Me.colImporte.Width = 50
        '
        'colCodComision
        '
        Me.colCodComision.Text = "Comisión"
        Me.colCodComision.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(572, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 54
        Me.Label2.Text = "Liquidaciones"
        '
        'cboComisiones
        '
        Me.cboComisiones.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboComisiones.FormattingEnabled = True
        Me.cboComisiones.Location = New System.Drawing.Point(397, 6)
        Me.cboComisiones.Name = "cboComisiones"
        Me.cboComisiones.Size = New System.Drawing.Size(65, 21)
        Me.cboComisiones.TabIndex = 55
        '
        'lblCantidad
        '
        Me.lblCantidad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCantidad.Location = New System.Drawing.Point(5, 422)
        Me.lblCantidad.Name = "lblCantidad"
        Me.lblCantidad.Size = New System.Drawing.Size(67, 18)
        Me.lblCantidad.TabIndex = 57
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(470, 425)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(13, 13)
        Me.Label5.TabIndex = 58
        Me.Label5.Text = "$"
        '
        'lblImpVendido
        '
        Me.lblImpVendido.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblImpVendido.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblImpVendido.Location = New System.Drawing.Point(200, 422)
        Me.lblImpVendido.Name = "lblImpVendido"
        Me.lblImpVendido.Size = New System.Drawing.Size(88, 19)
        Me.lblImpVendido.TabIndex = 60
        Me.lblImpVendido.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(103, 425)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 13)
        Me.Label8.TabIndex = 59
        Me.Label8.Text = "Importe Vendido"
        '
        'chkUsarOtra
        '
        Me.chkUsarOtra.AutoSize = True
        Me.chkUsarOtra.Location = New System.Drawing.Point(346, 8)
        Me.chkUsarOtra.Name = "chkUsarOtra"
        Me.chkUsarOtra.Size = New System.Drawing.Size(54, 17)
        Me.chkUsarOtra.TabIndex = 61
        Me.chkUsarOtra.Text = "Usar :"
        Me.chkUsarOtra.UseVisualStyleBackColor = True
        '
        'btnRecalcular
        '
        Me.btnRecalcular.Location = New System.Drawing.Point(468, 5)
        Me.btnRecalcular.Name = "btnRecalcular"
        Me.btnRecalcular.Size = New System.Drawing.Size(30, 23)
        Me.btnRecalcular.TabIndex = 62
        Me.btnRecalcular.Text = "..."
        Me.btnRecalcular.UseVisualStyleBackColor = True
        '
        'frmLiquidaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnSalir
        Me.ClientSize = New System.Drawing.Size(884, 460)
        Me.Controls.Add(Me.btnRecalcular)
        Me.Controls.Add(Me.lblImpVendido)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblCantidad)
        Me.Controls.Add(Me.cboComisiones)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ListView1)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnGenerar)
        Me.Controls.Add(Me.lblImpPagar)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblComisionProv)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cboProveedor)
        Me.Controls.Add(Me.lvPrendas)
        Me.Controls.Add(Me.chkUsarOtra)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmLiquidaciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Liquidaciones"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lvPrendas As System.Windows.Forms.ListView
    Friend WithEvents id As System.Windows.Forms.ColumnHeader
    Friend WithEvents Categoria As System.Windows.Forms.ColumnHeader
    Friend WithEvents Marca As System.Windows.Forms.ColumnHeader
    Friend WithEvents Precio As System.Windows.Forms.ColumnHeader
    Friend WithEvents Comentarios As System.Windows.Forms.ColumnHeader
    Friend WithEvents colFecVenta As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCliente As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboProveedor As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblComisionProv As System.Windows.Forms.Label
    Friend WithEvents lblImpPagar As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnGenerar As System.Windows.Forms.Button
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents colId As System.Windows.Forms.ColumnHeader
    Friend WithEvents colFecha As System.Windows.Forms.ColumnHeader
    Friend WithEvents colImporte As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCodComision As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cboComisiones As System.Windows.Forms.ComboBox
    Friend WithEvents lblCantidad As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblImpVendido As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chkUsarOtra As System.Windows.Forms.CheckBox
    Friend WithEvents btnRecalcular As System.Windows.Forms.Button
    Friend WithEvents colNomProv As System.Windows.Forms.ColumnHeader
End Class
