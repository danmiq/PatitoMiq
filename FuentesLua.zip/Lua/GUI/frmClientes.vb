﻿Public Class frmClientes
    Public VieneDeVenta As Boolean
    Public IdCliente As Integer
    Public NombreCliente As String

    Dim Nuevo As Boolean
    Dim oClienteActual As Cliente
    Dim oLista As Clientes

    Private Sub btnNuevo_Click_1(sender As Object, e As EventArgs) Handles btnNuevo.Click
        GUI.LimpiarCampos(Me)
        Me.txtId.Text = oHandler.GetId(TABLA_CLIENTES)
        Me.txtId.Enabled = False
        Me.btnGrabar.Enabled = True
        Me.txtNombre.Focus()
    End Sub

    Sub Refrescar()
        oLista = oHandler.CargarClientes("", False)
        GUI.MostrarClientes(Me.lvDatos, oLista)
    End Sub
    Private Sub btnGrabar_Click(sender As Object, e As EventArgs) Handles btnGrabar.Click
        Dim sError As String

        If Not GUI.ValidarDatos(Me, sError) Then
            MsgBox("Datos incorrectos : " & vbCrLf & sError, MsgBoxStyle.Exclamation)
        Else
            If MsgBox("¿ Confirma estos datos ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                Me.oClienteActual = GUI.GetCliente(Me)
                If oHandler.GrabarCliente(Me.oClienteActual, False, sError) Then
                    If Me.VieneDeVenta Then
                        Me.IdCliente = Me.oClienteActual.Id
                        Me.NombreCliente = Me.oClienteActual.Nombre
                        Me.Close()
                    Else
                        MsgBox("Cliente grabado OK", MsgBoxStyle.Information)
                        GUI.LimpiarCampos(Me)
                        Refrescar()
                    End If
                Else
                    MsgBox("Error al grabar cliente : " & vbCrLf & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmContactos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GUI.LimpiarCampos(Me)
        If Me.VieneDeVenta Then
            Me.Nuevo = True
            Me.Text = "Alta de nuevo Cliente por venta"
            Me.oClienteActual = New Cliente
            Me.txtId.Text = oHandler.GetId(TABLA_CLIENTES)
            Me.txtId.Enabled = False
        Else
            Me.Text = "Clientes"
            Refrescar()
        End If
    End Sub

    Private Sub lvDatos_ItemActivate(sender As Object, e As EventArgs) Handles lvDatos.ItemActivate
        Me.oClienteActual = Me.oLista.GetItemByKey(Me.lvDatos.SelectedItems(0).Text)
        GUI.MostrarCliente(oClienteActual, Me)

        Me.btnEliminar.Enabled = True
        Me.btnGrabar.Enabled = True

    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim nId As Long
        Dim sError As String = ""

        If Me.lvDatos.SelectedItems.Count > 0 Then
            nId = CLng(Me.lvDatos.SelectedItems(0).Text)
            Me.oClienteActual = Me.oLista.GetItem(nId)
            If MsgBox("¿ Confirma la eliminación del cliente " & nId & " ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                oHandler.GrabarCliente(Me.oClienteActual, True, sError)
                GUI.LimpiarCampos(Me)
                Refrescar()

                Me.Nuevo = True
            End If
        End If
    End Sub



    Private Sub btnAddCupon_Click(sender As Object, e As EventArgs)
        Dim sIdCupon, sPje, sError As String

        sIdCupon = oHandler.GetId(TABLA_CUPONES)
        sIdCupon = InputBox("N° de Cupon a entregar", "Entrega de Cupon", sIdCupon)
        If sIdCupon <> "" Then
            sPje = InputBox("Porcentaje de Descuento", "Entrega de Cupon")
            If sPje <> "" Then
                If MsgBox("¿ Le entregamos a " & oClienteActual.Nombre & " un cupón por " & sPje & "% de descuento ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                    If oHandler.NuevoCupon(Me.oClienteActual.Id, CInt(sIdCupon), CDbl(sPje), sError) Then
                        Me.oClienteActual = oHandler.CargarCliente(oClienteActual.Id, False)
                        GUI.MostrarCliente(Me.oClienteActual, Me)
                    Else
                        MsgBox("Error al entregar cupón : " & vbCrLf & sError, MsgBoxStyle.Exclamation)
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim sArchivo As String

        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor
        If oHandler.GenCaratulaEnvio(Me.oClienteActual, sArchivo) Then
            System.Windows.Forms.Cursor.Current = Cursors.Default
            MsgBox("Archivo generado correctamente : " & sArchivo, MsgBoxStyle.Information)
        Else
            System.Windows.Forms.Cursor.Current = Cursors.Default
            MsgBox("Error al generar")
        End If
    End Sub

    Private Sub txtMail_Enter(sender As Object, e As EventArgs) Handles txtMail.Enter
        Me.txtMail.SelectAll()
    End Sub

    Private Sub txtNombre_Enter(sender As Object, e As EventArgs) Handles txtNombre.Enter
        Me.txtNombre.SelectAll()
    End Sub

    Private Sub txtTelefono_Enter(sender As Object, e As EventArgs) Handles txtTelefono.Enter
        Me.txtTelefono.SelectAll()
    End Sub

    Private Sub txtDireccion_Enter(sender As Object, e As EventArgs) Handles txtDireccion.Enter
        Me.txtDireccion.SelectAll()
    End Sub

    Private Sub lvDatos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDatos.SelectedIndexChanged

    End Sub
End Class