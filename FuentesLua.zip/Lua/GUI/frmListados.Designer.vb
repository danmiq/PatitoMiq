﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListados
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmListados))
        Me.btnListar = New System.Windows.Forms.Button()
        Me.btnSalir = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbPDF = New System.Windows.Forms.RadioButton()
        Me.rbExcel = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cboProveedor = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.panelStock = New System.Windows.Forms.Panel()
        Me.lvEstados = New System.Windows.Forms.ListView()
        Me.colId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDesc = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelVentas = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtHasta = New System.Windows.Forms.DateTimePicker()
        Me.dtDesde = New System.Windows.Forms.DateTimePicker()
        Me.rbListadoStock = New System.Windows.Forms.RadioButton()
        Me.rbListadoVentas = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.panelStock.SuspendLayout()
        Me.panelVentas.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnListar
        '
        Me.btnListar.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnListar.Location = New System.Drawing.Point(276, 347)
        Me.btnListar.Name = "btnListar"
        Me.btnListar.Size = New System.Drawing.Size(73, 36)
        Me.btnListar.TabIndex = 0
        Me.btnListar.Text = "Listar"
        Me.btnListar.UseVisualStyleBackColor = True
        '
        'btnSalir
        '
        Me.btnSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSalir.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnSalir.Image = CType(resources.GetObject("btnSalir.Image"), System.Drawing.Image)
        Me.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSalir.Location = New System.Drawing.Point(369, 347)
        Me.btnSalir.Name = "btnSalir"
        Me.btnSalir.Size = New System.Drawing.Size(73, 36)
        Me.btnSalir.TabIndex = 7
        Me.btnSalir.Text = "Salir    "
        Me.btnSalir.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnSalir.UseVisualStyleBackColor = True
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatus.ForeColor = System.Drawing.Color.Navy
        Me.lblStatus.Location = New System.Drawing.Point(11, 318)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(435, 23)
        Me.lblStatus.TabIndex = 8
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbPDF)
        Me.GroupBox1.Controls.Add(Me.rbExcel)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 227)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(140, 73)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Destino "
        '
        'rbPDF
        '
        Me.rbPDF.Image = CType(resources.GetObject("rbPDF.Image"), System.Drawing.Image)
        Me.rbPDF.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.rbPDF.Location = New System.Drawing.Point(76, 16)
        Me.rbPDF.Name = "rbPDF"
        Me.rbPDF.Size = New System.Drawing.Size(58, 51)
        Me.rbPDF.TabIndex = 1
        Me.rbPDF.TabStop = True
        Me.rbPDF.Text = "PDF"
        Me.rbPDF.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.rbPDF.UseVisualStyleBackColor = True
        '
        'rbExcel
        '
        Me.rbExcel.Image = CType(resources.GetObject("rbExcel.Image"), System.Drawing.Image)
        Me.rbExcel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.rbExcel.Location = New System.Drawing.Point(16, 16)
        Me.rbExcel.Name = "rbExcel"
        Me.rbExcel.Size = New System.Drawing.Size(54, 49)
        Me.rbExcel.TabIndex = 0
        Me.rbExcel.TabStop = True
        Me.rbExcel.Text = "Excel"
        Me.rbExcel.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.rbExcel.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(-1, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "Proveedor"
        '
        'cboProveedor
        '
        Me.cboProveedor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboProveedor.FormattingEnabled = True
        Me.cboProveedor.Location = New System.Drawing.Point(68, 4)
        Me.cboProveedor.Name = "cboProveedor"
        Me.cboProveedor.Size = New System.Drawing.Size(163, 21)
        Me.cboProveedor.TabIndex = 45
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.panelStock)
        Me.GroupBox2.Controls.Add(Me.panelVentas)
        Me.GroupBox2.Controls.Add(Me.rbListadoStock)
        Me.GroupBox2.Controls.Add(Me.rbListadoVentas)
        Me.GroupBox2.Location = New System.Drawing.Point(2, 31)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(431, 190)
        Me.GroupBox2.TabIndex = 50
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Tipo de Listado "
        '
        'panelStock
        '
        Me.panelStock.Controls.Add(Me.lvEstados)
        Me.panelStock.Controls.Add(Me.Label1)
        Me.panelStock.Location = New System.Drawing.Point(76, 31)
        Me.panelStock.Name = "panelStock"
        Me.panelStock.Size = New System.Drawing.Size(217, 114)
        Me.panelStock.TabIndex = 52
        '
        'lvEstados
        '
        Me.lvEstados.Activation = System.Windows.Forms.ItemActivation.TwoClick
        Me.lvEstados.CheckBoxes = True
        Me.lvEstados.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colId, Me.colDesc})
        Me.lvEstados.FullRowSelect = True
        Me.lvEstados.GridLines = True
        Me.lvEstados.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None
        Me.lvEstados.HideSelection = False
        Me.lvEstados.Location = New System.Drawing.Point(6, 14)
        Me.lvEstados.Name = "lvEstados"
        Me.lvEstados.Size = New System.Drawing.Size(163, 97)
        Me.lvEstados.TabIndex = 51
        Me.lvEstados.UseCompatibleStateImageBehavior = False
        Me.lvEstados.View = System.Windows.Forms.View.Details
        '
        'colId
        '
        Me.colId.Text = "Id"
        Me.colId.Width = 40
        '
        'colDesc
        '
        Me.colDesc.Text = "Nombre"
        Me.colDesc.Width = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "Estados"
        '
        'panelVentas
        '
        Me.panelVentas.Controls.Add(Me.Label2)
        Me.panelVentas.Controls.Add(Me.dtHasta)
        Me.panelVentas.Controls.Add(Me.dtDesde)
        Me.panelVentas.Location = New System.Drawing.Point(76, 159)
        Me.panelVentas.Name = "panelVentas"
        Me.panelVentas.Size = New System.Drawing.Size(345, 26)
        Me.panelVentas.TabIndex = 51
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(37, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Vendidas entre"
        '
        'dtHasta
        '
        Me.dtHasta.CustomFormat = "dd/MM/yyyy"
        Me.dtHasta.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtHasta.Location = New System.Drawing.Point(228, 4)
        Me.dtHasta.Name = "dtHasta"
        Me.dtHasta.Size = New System.Drawing.Size(101, 20)
        Me.dtHasta.TabIndex = 1
        '
        'dtDesde
        '
        Me.dtDesde.CustomFormat = "dd/MM/yyyy"
        Me.dtDesde.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtDesde.Location = New System.Drawing.Point(121, 4)
        Me.dtDesde.Name = "dtDesde"
        Me.dtDesde.Size = New System.Drawing.Size(101, 20)
        Me.dtDesde.TabIndex = 0
        '
        'rbListadoStock
        '
        Me.rbListadoStock.AutoSize = True
        Me.rbListadoStock.Location = New System.Drawing.Point(12, 19)
        Me.rbListadoStock.Name = "rbListadoStock"
        Me.rbListadoStock.Size = New System.Drawing.Size(53, 17)
        Me.rbListadoStock.TabIndex = 1
        Me.rbListadoStock.TabStop = True
        Me.rbListadoStock.Text = "Stock"
        Me.rbListadoStock.UseVisualStyleBackColor = True
        '
        'rbListadoVentas
        '
        Me.rbListadoVentas.AutoSize = True
        Me.rbListadoVentas.Location = New System.Drawing.Point(12, 156)
        Me.rbListadoVentas.Name = "rbListadoVentas"
        Me.rbListadoVentas.Size = New System.Drawing.Size(58, 17)
        Me.rbListadoVentas.TabIndex = 0
        Me.rbListadoVentas.TabStop = True
        Me.rbListadoVentas.Text = "Ventas"
        Me.rbListadoVentas.UseVisualStyleBackColor = True
        '
        'frmListados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(454, 385)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cboProveedor)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.btnSalir)
        Me.Controls.Add(Me.btnListar)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmListados"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Listados"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.panelStock.ResumeLayout(False)
        Me.panelStock.PerformLayout()
        Me.panelVentas.ResumeLayout(False)
        Me.panelVentas.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnListar As System.Windows.Forms.Button
    Friend WithEvents btnSalir As System.Windows.Forms.Button
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbPDF As System.Windows.Forms.RadioButton
    Friend WithEvents rbExcel As System.Windows.Forms.RadioButton
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboProveedor As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents panelVentas As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents dtHasta As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtDesde As System.Windows.Forms.DateTimePicker
    Friend WithEvents rbListadoStock As System.Windows.Forms.RadioButton
    Friend WithEvents rbListadoVentas As System.Windows.Forms.RadioButton
    Friend WithEvents panelStock As System.Windows.Forms.Panel
    Friend WithEvents lvEstados As System.Windows.Forms.ListView
    Friend WithEvents colId As System.Windows.Forms.ColumnHeader
    Friend WithEvents colDesc As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
