﻿Public Class frmListadosVentas

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Dim l As List(Of ITEM_VENTA_RESUMEN)
        Dim itm As ListViewItem

        l = oHandlerRep.GetVentasTotal(Me.dtDesde.Value, Me.dtHasta.Value)
        Me.lvdatos.items.clear()
        For Each v In l
            itm = Me.lvDatos.Items.Add(v.Fecha)
            itm.SubItems.Add(v.ImporteCompra)
            itm.SubItems.Add(v.ImporteVenta)
            itm.SubItems.Add(v.Cantidad)
        Next

    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmListadosVentas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aColumnas() As String = {"Articulo", "Precio", "Costo", "Cantidad", "Cliente", "Proveedor"}
        Me.dtDesde.Value = Date.Today
        Me.dtDesde.Value = DateAdd(DateInterval.Day, 1 - (Me.dtDesde.Value.Day), Me.dtDesde.Value)
        Me.rbExcel.Checked = True
        InitGrilla(Me.grDatos, aColumnas)
    End Sub

    Private Sub lvDatos_ItemActivate(sender As Object, e As EventArgs) Handles lvDatos.ItemActivate
        Dim oVentas As List(Of ITEM_VENTA_DETALLE)
        If Me.lvDatos.SelectedItems.Count > 0 Then
            oVentas = oHandlerRep.GetVentasDetalle(Me.lvDatos.SelectedItems(0).Text)
            CargarGrilla(Me.grDatos, oVentas)
        End If
    End Sub


    Private Sub lvDatos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDatos.SelectedIndexChanged

    End Sub

    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        Dim sFecha, sArchivoGenerado As String

        Try
            If Me.lvDatos.SelectedItems.Count > 0 Then
                sFecha = FechaUniversal(Me.lvDatos.SelectedItems(0).Text)
                sArchivoGenerado = Reportes.GrillaAExcel(Me.grDatos, CARPETA_REPORTES, "Ventas_" & sFecha, "Listado de Ventas", sFecha)

                If rbPDF.Checked Then
                    sArchivoGenerado = Reportes.ToPDF(sArchivoGenerado)
                End If
                MostrarArchivo(sArchivoGenerado)
            End If
        Catch ex As Exception
            MsgBox("Error a listar : " & ex.Message)
        End Try

    End Sub
End Class