Imports System.Windows.Forms
Imports System.Net.Mail
Imports System.Net.Mime
Imports System.Net

Public Class frmMain

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sError As String

        If Not AbrirArchivoConfig(sError) Then
            MsgBox(sError, MsgBoxStyle.Critical)
            Me.Close()
        Else
            Try
                oHandler = New Handler()
                If oHandler.GetParametro(1, NOMBRE_EMPRESA) Then
                    Me.Text = NOMBRE_EMPRESA
                End If
                oHandler.GetParametro(2, NOMBRE_REMITENTE)
                oHandler.GetParametro(3, TELEFONO_REMITENTE)

                Me.lblVersion.Text = "Version : " & My.Application.Info.Version.ToString
                Me.PictureBox1.Load(My.Application.Info.DirectoryPath & "\Fondo.png")

            Catch ex As Exception
                'MsgBox("Error iniciando sistema : " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub mnuSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSalir.Click
        Me.Close()
    End Sub

    Private Sub mnuPersonas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPrendas.Click
        frmPrendas.Show(Me)
    End Sub

    Private Sub CodigosVariosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuABMTablas.Click
        frmABMTablas.Show(Me)
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles mnuPromos.Click
        frmPromos.Show(Me)
    End Sub

    Private Sub ContactosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuClientes.Click
        frmClientes.VieneDeVenta = False
        frmClientes.Show(Me)
    End Sub

    Private Sub ProveedoresToolStripMenuItem_Click(sender As Object, e As EventArgs)
        frmProveedores.Show(Me)
    End Sub

    Private Sub LiquidacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuLiquidaciones.Click
        frmLiquidaciones.Show(Me)
    End Sub

    Private Sub RespaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuConfiguracion.Click
        frmMantenimiento.Show(Me)
    End Sub

    Private Sub mnuConsultas_Click(sender As Object, e As EventArgs) Handles mnuConsultas.Click
        frmListados.Show(Me)
    End Sub

    Private Sub MenuStrip_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip.ItemClicked

    End Sub

    Private Sub ProveedoresToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ProveedoresToolStripMenuItem.Click
        frmProveedores.Show()
    End Sub

    Private Sub VentasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VentasToolStripMenuItem.Click
        frmVenta.Show(Me)
    End Sub

    Public Sub mandamail()
        Dim myMessage As MailMessage
        Dim file As String = "c:\lua\reportes\ventas.pdf"
        Dim server As String
        Try

            myMessage = New MailMessage(
                      "dmiquele@gmail.com",
                      "dmiquele@gmail.com",
                      "Quarterly data report.",
                      "See the attached spreadsheet.")
            '// Create  the file attachment for this email message.
            Dim data As Attachment = New Attachment(file, MediaTypeNames.Application.Octet)

            ' // Add time stamp information for the file.
            Dim disposition As ContentDisposition = data.ContentDisposition
            disposition.CreationDate = System.IO.File.GetCreationTime(file)
            disposition.ModificationDate = System.IO.File.GetLastWriteTime(file)
            disposition.ReadDate = System.IO.File.GetLastAccessTime(file)
            '// Add the file attachment to this email message.
            myMessage.Attachments.Add(data)

            '//Send the message.
            'Dim client As SmtpClient = New SmtpClient("smtp.gmail.com")
            Dim client As SmtpClient = New SmtpClient("10.141.64.131")


            '// Add credentials if the SMTP server requires them.
            client.Credentials = CredentialCache.DefaultNetworkCredentials

            Try
                client.Send(myMessage)
            Catch ex As Exception
                Console.WriteLine("Exception caught in CreateMessageWithAttachment(): {0}", ex.ToString())
            End Try
        Catch

        End Try
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        ' mandamail()
    End Sub
End Class
