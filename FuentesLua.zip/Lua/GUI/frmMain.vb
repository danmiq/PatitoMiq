Imports System.Windows.Forms
Imports System.Net.Mail
Imports System.Net.Mime
Imports System.Net

Public Class frmMain

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim sError As String

        If Not AbrirArchivoConfig(sError) Then
            MsgBox(sError, MsgBoxStyle.Critical)
            Me.Close()
        Else
            Try
                oHandler = New Handler()
                oHandlerRep = New HandlerReporte()

                CargarParametros()
                Me.Text = NOMBRE_EMPRESA
                Me.lblVersion.Text = "Version : " & My.Application.Info.Version.ToString
                Me.PictureBox1.Load(My.Application.Info.DirectoryPath & "\Fondo.png")

            Catch ex As Exception
                'MsgBox("Error iniciando sistema : " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub mnuSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuSalir.Click
        If MsgBox("� Respalda la base ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Dim sError As String
            If Not oHandler.BackUp(CARPETA_BASE & "RespaldoLua.bak", sError) Then
                MsgBox("Atencion : No se hizo bien respaldo" & vbCrLf & vbCrLf & sError, MsgBoxStyle.OkOnly)
            End If
        End If
        Me.Close()
    End Sub

    Private Sub mnuPersonas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPrendas.Click
        frmPrendas.Show(Me)
    End Sub

    Private Sub CodigosVariosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuABMTablas.Click
        frmABMTablas.Show(Me)
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles mnuPromos.Click
        frmPromos.Show(Me)
    End Sub

    Private Sub ContactosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuClientes.Click
        frmClientes.VieneDeVenta = False
        frmClientes.Show(Me)
    End Sub

    Private Sub ProveedoresToolStripMenuItem_Click(sender As Object, e As EventArgs)
        frmProveedores.Show(Me)
    End Sub

    Private Sub LiquidacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuLiquidaciones.Click
        frmLiquidaciones.Show(Me)
    End Sub

    Private Sub RespaldoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuConfiguracion.Click
        frmMantenimiento.Show(Me)
    End Sub

    Private Sub ProveedoresToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ProveedoresToolStripMenuItem.Click
        frmProveedores.Show()
    End Sub

    Private Sub VentasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VentasToolStripMenuItem.Click
        frmVenta.Show(Me)
    End Sub

    Private Sub MercaderiaPorProveedorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MercaderiaPorProveedorToolStripMenuItem.Click
        frmListadosProv.Show(Me)
    End Sub

    Private Sub CajaventasPorDiaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CajaventasPorDiaToolStripMenuItem.Click
        frmlistadosVentas.show(Me)
    End Sub

    Private Sub mnuMantenimiento_Click(sender As Object, e As EventArgs) Handles mnuMantenimiento.Click

    End Sub

    Private Sub mnuConsultas_Click(sender As Object, e As EventArgs) Handles mnuConsultas.Click

    End Sub
End Class
