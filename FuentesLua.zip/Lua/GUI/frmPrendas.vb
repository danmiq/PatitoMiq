Public Class frmPrendas
    Private oListaPrendas As Prendas
    Private oPrendaActual As Prenda
    Public nIdImagenAct As Integer

    Public Nuevo As Boolean

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmPrendas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.chkDisponibles.Checked = True
        oHandler.CargarCombo(Me.cboProveedor, TABLA_PROVEEDORES, "id_proveedor", "Nombre", "", "0", "*** TODOS ***")

        Me.cboProveedor.SelectedIndex = Me.cboProveedor.Items.Count - 1

        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor
        Me.oListaPrendas = oHandler.CargarPrendas("", 1)
        System.Windows.Forms.Cursor.Current = Cursors.Default

        Refrescar(0)

        Me.splitMain.Panel2.Enabled = False

        GUI.LimpiarCampos(Me)
    End Sub

    Private Sub btnNuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNuevo.Click
        Me.Nuevo = True
        Me.oPrendaActual = New Prenda
        GUI.LimpiarCampos(Me)

        Me.txtId.Text = oHandler.GetId(TABLA_PRENDAS)
        Me.btnGrabar.Enabled = True

        Me.splitMain.Panel2.Enabled = True
        Me.TabControl1.SelectTab(0)
    End Sub

    Private Sub btnGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrabar.Click
        Dim sError As String

        If Not GUI.ValidarDatos(Me, sError) Then
            MsgBox("Datos incorrectos : " & vbCrLf & sError, MsgBoxStyle.Exclamation)
        Else
            If MsgBox("� Confirma la modificaci�n de esta mercader�a ? ", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                If GUI.ValidarPrenda(Me, sError) Then
                    Me.oPrendaActual = GUI.GetPrenda(Me)
                    GUI.LimpiarPictureBox(Me.picFotoPrenda)
                    If oHandler.GrabarPrenda(Me.oPrendaActual, False, sError) Then
                        Me.oListaPrendas = oHandler.CargarPrendas("", 1)
                        Refrescar(CInt(Me.txtId.Text))
                        Me.oPrendaActual = oHandler.CargarPrenda(CInt(Me.txtId.Text))
                        GUI.MostrarPrenda(Me.oPrendaActual, Me)
                    Else
                        MsgBox("Error al grabar : " & sError, vbExclamation)
                    End If
                Else
                    MsgBox("Errores en los datos ingresados : " & vbCrLf & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub

    Private Sub btnEliminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminar.Click
        Dim nId As Long
        Dim sError As String = ""

        If Me.lvDatos.SelectedItems.Count > 0 Then
            nId = CLng(Me.lvDatos.SelectedItems(0).Text)
            Me.oPrendaActual = Me.oListaPrendas.GetItem(nId)
            If MsgBox("� Confirma la eliminaci�n de la mercader�a " & nId & " ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                oHandler.GrabarPrenda(Me.oPrendaActual, True, sError)
                Me.oListaPrendas = oHandler.CargarPrendas("", 1)
                Refrescar(0)

                Me.Nuevo = True
            End If
        End If
    End Sub

    Private Sub lvDatos_ItemActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvDatos.ItemActivate
        Me.splitMain.Panel2.Enabled = True
        Me.oPrendaActual = Me.oListaPrendas.GetItem(Me.lvDatos.SelectedItems(0).Text)
        Me.oPrendaActual = oHandler.CargarPrenda(Me.oPrendaActual.Id)
        GUI.MostrarPrenda(Me.oPrendaActual, Me)

        Me.Nuevo = False
        Me.btnGrabar.Enabled = True
        Me.btnEliminar.Enabled = True

    End Sub

    Private Sub lvDatos_ColumnClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs)
        Me.lvDatos.ListViewItemSorter = New ListViewItemComparer(e.Column)
    End Sub

    Friend Sub Refrescar(ByVal nIdPrenda As Integer)
        Dim nCantItems, nMaxId As Integer
        Dim dPrecioTotal, dCostoTotal As Double
        Dim v As GUI.T_VISTA_LISTVIEW

        Me.lblUltimoId.Text = ""
        Me.lblCantItems.Text = ""
        Me.lblCostoTotal.Text = ""
        Me.lblPrecioTotal.Text = ""

        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor
        GUI.MostrarPrendas(Me.oListaPrendas, Me.lvDatos, Me.txtFiltro.Text.ToUpper, Me.chkDisponibles.Checked, Me.cboProveedor.SelectedValue, nCantItems, nIdPrenda, dCostoTotal, dPrecioTotal, v)
        System.Windows.Forms.Cursor.Current = Cursors.Default

        nMaxId = oHandler.GetId(TABLA_PRENDAS) - 1
        Me.lblUltimoId.Text = "Ultimo Id : " & nMaxId
        Me.lblCantItems.Text = Me.lvDatos.Items.Count & " / " & Me.oListaPrendas.Count.ToString & " items"
        Me.lblCostoTotal.Text = Format(dCostoTotal, FORMATO_IMPORTE) & " $"
        Me.lblPrecioTotal.Text = Format(dPrecioTotal, FORMATO_IMPORTE) & " $"

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs)
        If Me.nIdImagenAct < Me.oPrendaActual.Imagenes.Count - 1 Then
            Me.nIdImagenAct = nIdImagenAct + 1
            GUI.MostrarImagen(Me.picFotoPrenda, Me.oPrendaActual, Me.nIdImagenAct)
        End If
    End Sub

    Private Sub btnImagePrev_Click(sender As Object, e As EventArgs)
        If Me.nIdImagenAct > 0 Then
            Me.nIdImagenAct = nIdImagenAct - 1
            GUI.MostrarImagen(Me.picFotoPrenda, Me.oPrendaActual, Me.nIdImagenAct)
        End If
    End Sub

    Private Sub lvFotos_ItemActivate(sender As Object, e As EventArgs) Handles lvFotos.ItemActivate
        GUI.MostrarImagen(Me.picFotoPrenda, Me.oPrendaActual, CInt(Me.lvFotos.SelectedItems(0).Text))
    End Sub

    Private Sub btnFotos_Click(sender As Object, e As EventArgs) Handles btnFotos.Click
        Dim s As String

        Me.OpenFileDialog1.Multiselect = True
        If Me.OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim itm As ListViewItem

            Dim n As Integer = System.Math.Max(Me.oPrendaActual.UltimoIdImagen, GUI.UltimoId(Me.lvFotos))

            For Each s In Me.OpenFileDialog1.FileNames()
                n = n + 1
                itm = New ListViewItem
                itm.Text = n
                itm.SubItems.Add(s)

                itm.Tag = Prenda.T_ACCION_IMAGEN.AGREGAR
                Me.lvFotos.Items.Add(itm)
            Next
        End If
    End Sub

    Private Sub BorrarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BorrarToolStripMenuItem.Click
        Me.lvFotos.SelectedItems(0).Tag = Prenda.T_ACCION_IMAGEN.ELIMINAR
        Me.lvFotos.SelectedItems(0).ForeColor = Color.Red
    End Sub

    Private Sub btnVender_Click(sender As Object, e As EventArgs)
        frmVenta.Accion = T_ACCION.VENTA
        frmVenta.Prenda = Me.oPrendaActual
        If frmVenta.ShowDialog = Windows.Forms.DialogResult.OK Then
            GUI.HabilitarAcciones(Me, T_STATUS.VENDIDA)
            Me.oListaPrendas = oHandler.CargarPrendas("", 1)
            Refrescar(0)
        End If
    End Sub

    Private Sub btnAplicarFiltro_Click(sender As Object, e As EventArgs) Handles btnAplicarFiltro.Click
        Refrescar(0)
    End Sub

    Private Sub btnLimpiarFiltros_Click(sender As Object, e As EventArgs) Handles btnLimpiarFiltros.Click
        Me.txtFiltro.Text = ""
        Me.chkDisponibles.Checked = False
        Me.cboProveedor.SelectedIndex = Me.cboProveedor.Items.Count - 1

        Refrescar(0)
    End Sub

    Private Sub btnBajar_Click(sender As Object, e As EventArgs) Handles btnDevolver.Click
        Dim s, sError As String

        s = "� Confirma la devoluci�n de " & oPrendaActual.Descripcion & " ?"
        If MsgBox(s, MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Devolver al Proveedor") = MsgBoxResult.Yes Then
            If oHandler.Devolver(Me.oPrendaActual.Id, Date.Now, sError) Then
                MsgBox("Art�culo devuelto", MsgBoxStyle.Information)
                Refrescar(0)
            End If
        End If
    End Sub

    Private Sub frmPrendas_ResizeEnd(sender As Object, e As EventArgs) Handles Me.ResizeEnd
        Me.splitMain.Height = Me.Height - 90
        Me.TabControl1.Height = Me.splitMain.Height - 31
    End Sub

    Private Sub rbGrupos_CheckedChanged(sender As Object, e As EventArgs)
        Refrescar(0)
    End Sub

    Private Sub AgregarAPromoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarAPromoToolStripMenuItem.Click
        Dim sLista As String
        Dim nAgregadas As Integer
        Dim sError As String

        frmLista.Tabla = TABLA_PROMOS
        frmLista.CargarLista("")

        If frmLista.ShowDialog() Then
            sLista = GUI.GetListaSeleccionados(Me.lvDatos)
            nAgregadas = oHandler.PromoAgregarPrendas(frmLista.Id, sLista, sError)
            If nAgregadas > 0 Then
                MsgBox("Se agregaron " & nAgregadas & " mercader�as a la promo " & frmLista.Nombre, MsgBoxStyle.Information)
            Else
                If nAgregadas = 0 Then
                    MsgBox("Ninguna mercader�a se agreg� a la promo " & frmLista.Nombre, MsgBoxStyle.Exclamation)
                Else
                    MsgBox("Ocurri� un error al agregar las mercader�as : " & vbCrLf & sError, MsgBoxStyle.Critical)
                End If
            End If
        End If
    End Sub

    Private Sub txtFiltroCateg_GotFocus(sender As Object, e As EventArgs) Handles txtFiltro.GotFocus
        Me.txtFiltro.SelectAll()
    End Sub

    Private Sub txtNomProv_Enter(sender As Object, e As EventArgs) Handles txtNomProv.Enter
        Me.txtNomProv.SelectAll()
    End Sub

    Private Sub txtNomProv_Leave(sender As Object, e As EventArgs) Handles txtNomProv.Leave
        CargarProveedor()
    End Sub

    Sub CargarProveedor()
        Dim oProvs As Proveedores
        Dim oProv As Proveedor
        Dim sFiltro As String

        Me.lblCodProv.Text = ""

        If IsNumeric(Me.txtNomProv.Text) Then
            sFiltro = "id_proveedor = " & Me.txtNomProv.Text.Trim
        Else
            sFiltro = "upper(Nombre) LIKE '%" & Me.txtNomProv.Text.Trim.ToUpper & "%'"
        End If
        oProvs = oHandler.CargarProveedores(sFiltro)

        If oProvs.Items.Count > 0 Then
            If oProvs.Items.Count = 1 Then
                oProv = oProvs.Items(1)
            Else
                frmLista.Tabla = TABLA_PROVEEDORES
                frmLista.oLista = oProvs
                frmLista.MostrarDatos()
                frmLista.ShowDialog()
                If frmLista.DialogResult = Windows.Forms.DialogResult.OK Then
                    oProv = oHandler.CargarProveedor(frmLista.Id)
                End If
            End If
        Else
            ' frmProveedores.VieneDeVenta = True
            ' frmProveedores.ShowDialog()
            ' oProv = oHandler.CargarProveedor(frmClientes.IdCliente)
            'frmClientes = Nothing
        End If
        If Not (oProv Is Nothing) Then
            Me.lblCodProv.Text = oProv.Id
            Me.txtNomProv.Text = oProv.Nombre
        Else
            MsgBox("No se encontr� Proveedor", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
        End If
    End Sub

    Private Sub txtNomProv_TextChanged(sender As Object, e As EventArgs) Handles txtNomProv.TextChanged

    End Sub

    Private Sub lvDatos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDatos.SelectedIndexChanged

    End Sub
End Class


