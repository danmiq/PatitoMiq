﻿Public Class frmListadosProv

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub frmListados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim aColumnasMerc() As String = {"Codigo", "Articulo", "Costo", "Precio", "Stock", "SubTotCosto", "SubTotPrecio", "Estado"}

        Me.lblStatus.Text = ""
        Me.rbExcel.Checked = True
        Me.dtDesde.Value = Date.Today
        Me.dtDesde.Value = DateAdd(DateInterval.Day, 1 - (Me.dtDesde.Value.Day), Me.dtDesde.Value)

        Me.rbExcel.Checked = True
        InitGrilla(Me.grDatosMerc, aColumnasMerc)
        Me.txtNomProv.Focus()
    End Sub


    Private Sub txtNomProv_Leave(sender As Object, e As EventArgs) Handles txtNomProv.Leave
        Dim sMail As String
        CargarProveedor(Me.lblCodProv, Me.txtNomProv, sMail)
        Me.txtMail.Text = sMail
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim oLista As Prendas

        oLista = oHandler.CargarPrendas("P.id_proveedor = " & Me.lblCodProv.Text, 2)
        CargarGrilla(Me.grDatosMerc, oLista)
    End Sub

    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        Dim sArchivoGenerado As String

        Try
            Me.lblStatus.Text = "Generando Excel ..."
            sArchivoGenerado = Reportes.GrillaAExcel(Me.grDatosMerc, CARPETA_REPORTES, "Stock_" & Me.lblCodProv.Text, "Stock del Proveedor", Me.txtNomProv.Text)

            If rbPDF.Checked Then
                Me.lblStatus.Text = "Convirtiendo a PDF ..."
                sArchivoGenerado = Reportes.ToPDF(sArchivoGenerado)
            End If
            If Me.chkMail.Checked And Me.txtMail.Text <> "" Then
                Me.lblStatus.Text = "Enviando mail ..."
                Reportes.MandaMail(Me.txtMail.Text, "Su stock de mercaderia en " & NOMBRE_EMPRESA, "Gracias por trabajar con nosotros.", sArchivoGenerado)
            End If
            MostrarArchivo(sArchivoGenerado)
            Me.lblStatus.Text = "Archivo " & sArchivoGenerado & " generado"
        Catch ex As Exception
            MsgBox("Error a generar : " & ex.Message)
        End Try
    End Sub
End Class