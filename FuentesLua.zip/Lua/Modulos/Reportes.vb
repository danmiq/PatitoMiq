﻿Imports System.IO
Imports Microsoft.Office.Interop
Imports System
Imports System.Net
Imports System.Net.Mail

Module Reportes
    Public Structure ITEM_VENTA_RESUMEN
        Dim Fecha As Date
        Dim ImporteCompra As Double
        Dim ImporteVenta As Double
        Dim Cantidad As Integer
    End Structure

    Friend Structure ITEM_VENTA_DETALLE
        Dim IdPrenda As Integer
        Dim IdCliente As Integer
        Dim IdProveedor As Integer
        Dim Costo As Double
        Dim Precio As Double
        Dim Cantidad As Integer
        Dim NomPrenda As String
        Dim NomCliente As String
        Dim NomProveedor As String
    End Structure

    Public oHandlerRep As HandlerReporte

    Sub InitGrilla(ByRef gr As DataGridView, aColumnas() As String)
        Dim s As String
        Dim col As DataGridViewTextBoxColumn

        gr.ShowEditingIcon = False
        gr.RowHeadersVisible = False

        For Each s In aColumnas
            col = New DataGridViewTextBoxColumn
            col.DataPropertyName = "PropertyName"
            col.HeaderText = s
            col.Name = "col" & s.Replace(" ", "")
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
            gr.Columns.Add(col)
        Next

    End Sub

#Region "Listados a Excel"

    Public Sub MostrarArchivo(sArchivo As String)
        ' Abre archivo XLS o PDF
        If Right(sArchivo, 4).ToUpper.Contains("XLS") Then

            Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
            p.EnableRaisingEvents = False
            Process.Start("Excel.exe", sArchivo)
        Else
            Process.Start(sArchivo)
        End If
    End Sub
    Public Function GrillaAExcel(gr As DataGridView, sPath As String, sArchivo As String, sTitulo As String, sParametros As String) As String
        Dim Exc As Excel.Application = New Excel.Application
        Dim oLibro As Excel.Workbook
        Dim oHoja As Excel.Worksheet
        Dim nColTitulos As Integer
        Dim sLetraColTitulos As String = "C"

        nColTitulos = 3
        oLibro = Exc.Workbooks.Add
        oHoja = oLibro.ActiveSheet

        ' Font por defecto de toda la hoja
        oHoja.Cells.Select()
        With Exc.Selection.Font
            .Name = "Calibri"
            .Size = 8
            .Strikethrough = False
            .Superscript = False
            .Subscript = False
            .OutlineFont = False
            .Shadow = False
            .TintAndShade = 0
        End With
        ' Inserta logo
        oHoja.Pictures.Insert(My.Application.Info.DirectoryPath & "\Logo.png").Select()
        Exc.Selection.ShapeRange.ScaleWidth(0.5, 0, 0)
        Exc.Selection.ShapeRange.ScaleHeight(0.5, 0, 0)

        ' Nombre de la empresa
        oHoja.Cells(1, nColTitulos) = NOMBRE_EMPRESA

        ' Fecha / Hora de Impresion
        oHoja.Cells(1, nColTitulos + 3) = "Emitido : " & Format(Date.Now, "dd/MM/yyyy hh:mm")

        ' Titulo
        oHoja.Cells(3, nColTitulos) = sTitulo
        oHoja.Range(sLetraColTitulos & "3").Select()
        With Exc.Selection.Font
            .Name = "Calibri"
            .Size = 14
            .Strikethrough = False
            .Superscript = False
            .Subscript = False
            .OutlineFont = False
            .Shadow = False
            .TintAndShade = 0
        End With

        ' Parametros
        oHoja.Cells(5, nColTitulos) = sParametros

        Dim r As DataGridViewRow
        Dim c As DataGridViewCell
        Dim g As DataGridViewTextBoxColumn
        Dim nFila, nColumna As Integer

        ' Pone Cabezales de Datos
        nFila = 7
        nColumna = 1
        For Each g In gr.Columns
            oHoja.Cells(nFila, nColumna) = g.HeaderText
            nColumna = nColumna + 1
        Next
        nFila = nFila + 1


        ' Pone Datos
        For Each r In gr.Rows
            nColumna = 1
            For Each c In r.Cells
                oHoja.Cells(nFila, nColumna) = c.Value
                nColumna = nColumna + 1
            Next
            nFila = nFila + 1
        Next

        ' Guarda
        If My.Computer.FileSystem.FileExists(sPath & sArchivo) Then
            My.Computer.FileSystem.DeleteFile(sPath & sArchivo)
        End If


        sArchivo = sArchivo & ".xls"

        Exc.ActiveWorkbook.SaveAs(sPath & sArchivo, Excel.XlTextQualifier.xlTextQualifierNone - 1)
        Exc.ActiveWorkbook.Saved = True
        Exc.Workbooks.Close()
        Exc.Quit()
        oHoja = Nothing
        oLibro = Nothing
        Exc = Nothing
        GC.Collect()
        Return sPath & sArchivo
    End Function

    Public Function GenerarCaratula(oCliente As Cliente, ByRef sArchivo As String) As Boolean
        Dim oWord As New Microsoft.Office.Interop.Word.Document
        Dim oPara1, oPara2, oPara3 As Word.Paragraph
        Dim save_changes As Object = False
        Dim apWord As New Microsoft.Office.Interop.Word.Application
        Dim n As Integer

        Try
            sArchivo = CARPETA_REPORTES & "EnvioPostal_" & oCliente.Nombre.Replace(" ", "") & ".doc"

            apWord.Visible = False

            oWord = apWord.Documents.Add()
            oWord.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait
            oWord.PageSetup.PaperSize = Word.WdPaperSize.wdPaperA4

            oPara1 = oWord.Content.Paragraphs.Add

            oPara1.Range.Font.Size = 28
            oPara1.Range.Text = oCliente.Nombre.ToUpper & vbCrLf & _
                                oCliente.Direccion.ToUpper & vbCrLf & _
                                oCliente.Localidad.ToUpper & vbCrLf & _
                                oCliente.Telefono.ToUpper
            ' Inserto Logo
            Dim s As Microsoft.Office.Interop.Word.InlineShape
            s = oPara1.Range.InlineShapes.AddPicture(My.Application.Info.DirectoryPath & "\Logo.png")
            s.Height = 70
            s.Width = 70

            s.Select()
            s.Borders.Enable = 1
            s.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle
            s.Borders.OutsideLineWidth = Word.WdLineWidth.wdLineWidth025pt
            s.Borders.OutsideColor = Word.WdColor.wdColorDarkRed

            apWord.Selection.ShapeRange.WrapFormat.Type = Microsoft.Office.Interop.Word.WdWrapType.wdWrapThrough
            n = 440             ' Esto deberia ser : n = Ancho util del papel (ancho de la zona blanca en word)
            apWord.Selection.ShapeRange.Left = n - s.Width
            apWord.Selection.ShapeRange.RelativeVerticalPosition = Word.WdRelativeVerticalPosition.wdRelativeVerticalPositionMargin


            oPara1.Format.SpaceBefore = 0
            oPara1.Format.SpaceAfter = 20
            oPara1.Range.InsertParagraphAfter()

            oPara2 = oWord.Content.Paragraphs.Add()
            oPara2.Range.Text = vbCrLf & vbCrLf & "Rte : " & Constantes.NOMBRE_REMITENTE
            oPara2.Format.SpaceBefore = 10
            oPara2.Format.SpaceAfter = 0
            oPara2.Range.Font.Size = 20
            oPara2.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphRight
            oPara2.Range.InsertParagraphAfter()

            oPara3 = oWord.Content.Paragraphs.Add()
            oPara3.Range.Text = TELEFONO_REMITENTE
            oPara3.Format.SpaceBefore = 10
            oPara3.Format.SpaceAfter = 0
            oPara3.Range.Font.Size = 20
            oPara3.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphRight
            oPara3.Range.InsertParagraphAfter()

            oWord.SaveAs(sArchivo)
            apWord.Quit(save_changes)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub DatosAExcel(sSQL As String, sPath As String, ByVal sArchivo As String, sTitulo As String, sParametros As String, d As T_DESTINO, aColsTotalizar() As Integer, ByRef sError As String)
        Dim r As System.Data.DataRow
        Dim dt As System.Data.DataSet

        Try
            sArchivo = sArchivo & ".TMP"
            dt = oHandler.Base.Consultar(sSQL)

            If My.Computer.FileSystem.FileExists(sPath & sArchivo) Then
                My.Computer.FileSystem.DeleteFile(sPath & sArchivo)
            End If

            FileOpen(1, sPath & sArchivo, OpenMode.Output)
            Dim sb As String = ""
            Dim i As Integer

            For i = 0 To dt.Tables(0).Columns.Count - 1
                sb &= dt.Tables(0).Columns(i).ColumnName & Microsoft.VisualBasic.ControlChars.Tab
            Next
            PrintLine(1, sb)
            i = 0
            For Each r In dt.Tables(0).Rows
                i = 0 : sb = ""
                For i = 0 To dt.Tables(0).Columns.Count - 1
                    If Not IsDBNull(r.Item(i)) Then
                        If dt.Tables(0).Columns(i).GetType.Name = "DateTime" Then
                            sb &= Format(r.Item(i).ToString, "dd/MM/yyyy") & Microsoft.VisualBasic.ControlChars.Tab
                        Else
                            sb &= CStr(r.Item(i).ToString) & Microsoft.VisualBasic.ControlChars.Tab
                        End If
                    Else
                        sb &= Microsoft.VisualBasic.ControlChars.Tab
                    End If

                Next
                PrintLine(1, sb)
            Next
            FileClose(1)

            If TextToExcel(sPath, sArchivo, sTitulo, sParametros, d, aColsTotalizar, sError) Then
                sError = "Datos exportados correctamente"
            End If
        Catch ex As Exception
            sError = ex.Message
        End Try
    End Sub

    Public Function TextToExcel(sPath As String, ByVal sArchivo As String, sTitulo As String, sParametros As String, d As T_DESTINO, aColsTotalizar() As Integer, ByRef sError As String) As String
        Dim valor As Integer = 1
        Dim sArchivoTMP As String = sPath & sArchivo
        Dim sArchivoDestino As String
        Dim i As Integer
        Dim nCol, nFilaInicioData, nFilaFinData As Integer
        Dim sCol As String

        Dim nColTitulos As Integer = 3
        Dim sLetraColTitulos As String = "C"
        Const FILAS_DESPLAZAR = 8

        Try

            Dim vFormato As Microsoft.Office.Interop.Excel.XlRangeAutoFormat
            Dim vCultura As System.Globalization.CultureInfo = New Globalization.CultureInfo("es-UY")

            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("es-UY")

            Dim Exc As Excel.Application = New Excel.Application
            Exc.Workbooks.OpenText(sPath & sArchivo, , , , Excel.XlTextQualifier.xlTextQualifierNone, , True)

            Dim oLibro As Excel.Workbook = Exc.ActiveWorkbook
            Dim oHoja As Excel.Worksheet = oLibro.ActiveSheet

            vFormato = Excel.XlRangeAutoFormat.xlRangeAutoFormatTable1


            nFilaFinData = oHoja.UsedRange.Rows.Count

            ' Carga Datos
            oHoja.Range(oHoja.Cells(1, 1), oHoja.Cells(oHoja.UsedRange.Rows.Count, oHoja.UsedRange.Columns.Count)).AutoFormat(vFormato)

            ' Muevo todos los datos para abajo 7 lineas
            For i = 1 To FILAS_DESPLAZAR
                oHoja.Rows("1:1").Select()
                Exc.Selection.Insert(Shift:=-4121, CopyOrigin:=0)
            Next
            nFilaFinData = nFilaFinData + FILAS_DESPLAZAR
            nFilaInicioData = FILAS_DESPLAZAR + 2

            ' Totales
            For i = 0 To UBound(aColsTotalizar)
                nCol = aColsTotalizar(i)
                sCol = Chr(Asc("A") + nCol - 1)
                oHoja.Range(sCol & nFilaFinData + 1).Select()
                Exc.ActiveCell.Formula = "=SUM(" & sCol & nFilaInicioData & ":" & sCol & nFilaFinData & ")"
                oHoja.Range(sCol & nFilaFinData + 2).Select()
            Next

            ' Font por defecto de toda la hoja
            oHoja.Cells.Select()
            With Exc.Selection.Font
                .Name = "Calibri"
                .Size = 8
                .Strikethrough = False
                .Superscript = False
                .Subscript = False
                .OutlineFont = False
                .Shadow = False
                .TintAndShade = 0
            End With

            ' Inserta logo
            oHoja.Pictures.Insert(My.Application.Info.DirectoryPath & "\Logo.png").Select()
            Exc.Selection.ShapeRange.ScaleWidth(0.5, 0, 0)
            Exc.Selection.ShapeRange.ScaleHeight(0.5, 0, 0)

            ' Nombre de la empresa
            oHoja.Cells(1, nColTitulos) = NOMBRE_EMPRESA

            ' Fecha / Hora de Impresion
            oHoja.Cells(1, nColTitulos + 3) = "Emitido : " & Format(Date.Now, "dd/MM/yyyy hh:mm")

            ' Titulo
            oHoja.Cells(3, nColTitulos) = sTitulo
            oHoja.Range(sLetraColTitulos & "3").Select()
            With Exc.Selection.Font
                .Name = "Calibri"
                .Size = 14
                .Strikethrough = False
                .Superscript = False
                .Subscript = False
                .OutlineFont = False
                .Shadow = False
                .TintAndShade = 0
            End With

            ' Parametros
            oHoja.Cells(5, nColTitulos) = sParametros

            If d = T_DESTINO.EXCEL Then
                sArchivoDestino = sArchivoTMP.Replace(".TMP", ".XLS")
                If My.Computer.FileSystem.FileExists(sArchivoDestino) Then
                    My.Computer.FileSystem.DeleteFile(sArchivoDestino)
                End If

                Exc.ActiveWorkbook.SaveAs(sArchivoDestino, Excel.XlTextQualifier.xlTextQualifierNone - 1)
            Else
                sArchivoDestino = sArchivoTMP.Replace(".TMP", ".PDF")
                If My.Computer.FileSystem.FileExists(sArchivoDestino) Then
                    My.Computer.FileSystem.DeleteFile(sArchivoDestino)
                End If

                Exc.ActiveWorkbook.ExportAsFixedFormat(Microsoft.Office.Interop.Excel.XlFixedFormatType.xlTypePDF, sArchivoDestino)
            End If
            Exc.ActiveWorkbook.Saved = True
            Exc.Workbooks.Close()
            Exc.Quit()
            oHoja = Nothing
            oLibro = Nothing
            Exc = Nothing
            GC.Collect()
            File.Delete(sArchivoTMP)

            ' Abre archivo
            If d = T_DESTINO.EXCEL Then
                If valor > -1 Then
                    Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
                    p.EnableRaisingEvents = False
                    Process.Start("Excel.exe", sArchivoDestino)
                End If
                '                System.Threading.Thread.CurrentThread.CurrentCulture = vCultura
            Else
                Process.Start(sArchivoDestino)
            End If
            sError = ""
            Return True
        Catch ex As Exception
            sError = ex.Message
            Return False
        End Try

    End Function

#End Region
    Function ToPDF(sArcIn As String) As String
        Dim Exc As Excel.Application = New Excel.Application
        Dim sArchivoDestino As String

        sArchivoDestino = sArcIn.ToUpper.Replace(".XLS", ".PDF")
        If My.Computer.FileSystem.FileExists(sArchivoDestino) Then
            My.Computer.FileSystem.DeleteFile(sArchivoDestino)
        End If
        Exc.Workbooks.Open(sArcIn)

        Exc.ActiveWorkbook.ExportAsFixedFormat(Microsoft.Office.Interop.Excel.XlFixedFormatType.xlTypePDF, sArchivoDestino)
        Exc.ActiveWorkbook.Saved = True
        Exc.Workbooks.Close()
        Exc.Quit()
        Exc = Nothing
        GC.Collect()
        File.Delete(sArcIn)

        Return sArchivoDestino
    End Function

    Public Sub MandaMail(sTo As String, sSubject As String, sBody As String, sAttach As String)
        Dim fromAddress As MailAddress
        Dim toAddress As MailAddress
        Dim fromPassword As String = CLAVE_MAIL
        Dim subject As String = sSubject
        Dim body As String = sBody

        Try
            fromAddress = New MailAddress(CASILLA_MAIL, CASILLA_MAIL)
            toAddress = New MailAddress(sTo, "Nombre")

            Dim smtp = New SmtpClient With {
                .Host = "smtp.gmail.com",
                .Port = 587,
                .UseDefaultCredentials = False,
                .DeliveryMethod = SmtpDeliveryMethod.Network,
                .Credentials = New NetworkCredential(fromAddress.Address, fromPassword),
                .EnableSsl = True
            }

            Dim a As System.Net.Mail.Attachment

            If sAttach <> "" Then
                a = New System.Net.Mail.Attachment(sAttach)
            End If

            Using m = New MailMessage(fromAddress, toAddress) With {
                .Subject = subject,
                .Body = body
            }
                If sAttach <> "" Then
                    m.Attachments.Add(a)
                End If
                smtp.Send(m)
            End Using
        Catch ex As Exception
            MsgBox("Error al mandar el mail" & vbCrLf & ex.Message)
        End Try
    End Sub

    Friend Sub CargarGrilla(ByRef gr As DataGridView, oVentas As List(Of ITEM_VENTA_DETALLE))
        Dim v As ITEM_VENTA_DETALLE
        Dim r As DataGridViewRow
        Dim n As Integer
        Dim nTotCosto, nTotPrecio As Double

        nTotCosto = 0
        nTotPrecio = 0

        gr.Rows.Clear()

        For Each v In oVentas
            r = New DataGridViewRow
            n = gr.Rows.Add()

            gr.Rows(n).Cells(0).Value = v.NomPrenda
            gr.Rows(n).Cells(1).Value = v.Precio
            gr.Rows(n).Cells(2).Value = v.Costo
            gr.Rows(n).Cells(3).Value = v.Cantidad
            gr.Rows(n).Cells(4).Value = v.NomCliente
            gr.Rows(n).Cells(5).Value = v.NomProveedor
            nTotCosto = nTotCosto + (v.Costo * v.Cantidad)
            nTotPrecio = nTotPrecio + (v.Precio * v.Cantidad)
        Next
        n = gr.Rows.Add()
        n = gr.Rows.Add()

        gr.Rows(n).Cells(0).Value = "Totales"
        gr.Rows(n).Cells(1).Value = nTotCosto
        gr.Rows(n).Cells(2).Value = nTotPrecio
    End Sub

    Friend Sub CargarGrilla(ByRef gr As DataGridView, l As Prendas)
        Dim p As Prenda
        Dim r As DataGridViewRow
        Dim n As Integer
        Dim nTotCosto, nTotPrecio As Double

        nTotCosto = 0
        nTotPrecio = 0

        gr.Rows.Clear()

        For Each p In l.Items
            r = New DataGridViewRow
            n = gr.Rows.Add()

            gr.Rows(n).Cells(0).Value = p.Id
            gr.Rows(n).Cells(1).Value = p.Descripcion
            gr.Rows(n).Cells(2).Value = p.Costo
            gr.Rows(n).Cells(3).Value = p.Precio
            gr.Rows(n).Cells(4).Value = p.Stock
            gr.Rows(n).Cells(5).Value = p.Costo * p.Stock
            gr.Rows(n).Cells(6).Value = p.Precio * p.Stock
            gr.Rows(n).Cells(7).Value = p.Status
            nTotCosto = nTotCosto + (p.Costo * p.Stock)
            nTotPrecio = nTotPrecio + (p.Precio * p.Stock)
        Next
        n = gr.Rows.Add()
        n = gr.Rows.Add()

        gr.Rows(n).Cells(0).Value = "Totales"
        gr.Rows(n).Cells(5).Value = nTotCosto
        gr.Rows(n).Cells(6).Value = nTotPrecio
    End Sub

End Module
