Imports Microsoft.Office.Interop
Imports System.IO

Module Generales
    Public oHandler As Handler

#Region "VARIOS"
    Function Comillas(sIn As String) As String
        Comillas = "'" & sIn & "'"
    End Function
    Function FiltrarTexto(sIn As String) As String
        FiltrarTexto = sIn.Replace("'", "�")
    End Function
    Public Function SINOtoBool(ByVal s As String) As Boolean
        Return (s = "SI")
    End Function

    Public Function BoolToSINO(ByVal b As Boolean) As String
        If b Then
            Return "SI"
        Else
            Return "NO"
        End If
    End Function
    Public Function SNtoBool(ByVal n As Integer) As Boolean
        Return (n = -1)
    End Function
    Public Function BoolToSN(ByVal b As Boolean) As Integer
        If b Then
            Return -1
        Else
            Return 0
        End If
    End Function

    Public Function FechaUniversal(ByVal d As DateTime, Optional ByVal bConSegundos As Boolean = False) As String
        If bConSegundos Then
            Return Format(d.Year, "0000") & Format(d.Month, "00") & Format(d.Day, "00") & " " & Format(d.Hour, "00") & ":" & Format(d.Minute, "00") & ":" & Format(d.Second, "00")
        Else
            Return Format(d.Year, "0000") & Format(d.Month, "00") & Format(d.Day, "00")
        End If
    End Function

    Public Function NoNulo(ByVal v As Object, ByVal vDefault As Object) As Object
        If v Is DBNull.Value Then
            Return vDefault
        Else
            Return v
        End If
    End Function
    Public Sub ValidarInt(ByRef e As Windows.Forms.KeyEventArgs)
        If (e.KeyCode >= Asc("0") And e.KeyCode <= Asc("9")) Or (e.KeyCode >= Windows.Forms.Keys.NumPad0 And e.KeyCode <= Windows.Forms.Keys.NumPad9) Or (e.KeyCode = Windows.Forms.Keys.Back Or e.KeyCode = Windows.Forms.Keys.Home Or e.KeyCode = Windows.Forms.Keys.Delete Or e.KeyCode = Windows.Forms.Keys.End Or e.KeyCode = Windows.Forms.Keys.Left Or e.KeyCode = Windows.Forms.Keys.Right) Then
            e.SuppressKeyPress = False
        Else
            e.SuppressKeyPress = True
        End If
    End Sub


    Function AbrirArchivoConfig(ByRef sError As String) As Boolean
        Dim s As String
        Dim a() As String
        Try
            Dim fr As System.IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(ARCHIVO_CONFIG)

            While Not fr.EndOfStream
                s = fr.ReadLine
                a = s.Split("|")

                If a(0) = "CARPETA_IMAGENES" Then
                    CARPETA_IMAGENES = a(1)
                End If
                If a(0) = "CONEXION_SQL" Then
                    CONEXION_SQL = a(1)
                End If
                If a(0) = "CARPETA_BASE" Then
                    CARPETA_BASE = a(1)
                End If
                If a(0) = "CARPETA_REPORTES" Then
                    CARPETA_REPORTES = a(1)
                End If
            End While
            fr.Close()
            AbrirArchivoConfig = True
        Catch ex As Exception
            sError = "No se pudo abrir archivo " & ARCHIVO_CONFIG & vbCrLf & ex.Message
            AbrirArchivoConfig = False
        End Try

    End Function
#End Region

#Region "Listados a Excel"
    Public Function GenerarCaratula(oCliente As Cliente, ByRef sArchivo As String) As Boolean
        Dim oWord As New Microsoft.Office.Interop.Word.Document
        Dim oPara1, oPara2, oPara3 As Word.Paragraph
        Dim save_changes As Object = False
        Dim apWord As New Microsoft.Office.Interop.Word.Application
        Dim n As Integer

        Try
            sArchivo = CARPETA_REPORTES & "EnvioPostal_" & oCliente.Nombre.Replace(" ", "") & ".doc"

            apWord.Visible = False

            oWord = apWord.Documents.Add()
            oWord.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait
            oWord.PageSetup.PaperSize = Word.WdPaperSize.wdPaperA4

            oPara1 = oWord.Content.Paragraphs.Add

            oPara1.Range.Font.Size = 28
            oPara1.Range.Text = oCliente.Nombre.ToUpper & vbCrLf & _
                                oCliente.Direccion.ToUpper & vbCrLf & _
                                oCliente.Localidad.ToUpper & vbCrLf & _
                                oCliente.Telefono.ToUpper
            ' Inserto Logo
            Dim s As Microsoft.Office.Interop.Word.InlineShape
            s = oPara1.Range.InlineShapes.AddPicture(My.Application.Info.DirectoryPath & "\Logo.png")
            s.Height = 70
            s.Width = 70

            s.Select()
            s.Borders.Enable = 1
            s.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle
            s.Borders.OutsideLineWidth = Word.WdLineWidth.wdLineWidth025pt
            s.Borders.OutsideColor = Word.WdColor.wdColorDarkRed

            apWord.Selection.ShapeRange.WrapFormat.Type = Microsoft.Office.Interop.Word.WdWrapType.wdWrapThrough
            n = 440             ' Esto deberia ser : n = Ancho util del papel (ancho de la zona blanca en word)
            apWord.Selection.ShapeRange.Left = n - s.Width
            apWord.Selection.ShapeRange.RelativeVerticalPosition = Word.WdRelativeVerticalPosition.wdRelativeVerticalPositionMargin


            oPara1.Format.SpaceBefore = 0
            oPara1.Format.SpaceAfter = 20
            oPara1.Range.InsertParagraphAfter()

            oPara2 = oWord.Content.Paragraphs.Add()
            oPara2.Range.Text = vbCrLf & vbCrLf & "Rte : " & Constantes.NOMBRE_REMITENTE
            oPara2.Format.SpaceBefore = 10
            oPara2.Format.SpaceAfter = 0
            oPara2.Range.Font.Size = 20
            oPara2.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphRight
            oPara2.Range.InsertParagraphAfter()

            oPara3 = oWord.Content.Paragraphs.Add()
            oPara3.Range.Text = TELEFONO_REMITENTE
            oPara3.Format.SpaceBefore = 10
            oPara3.Format.SpaceAfter = 0
            oPara3.Range.Font.Size = 20
            oPara3.Range.ParagraphFormat.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphRight
            oPara3.Range.InsertParagraphAfter()

            oWord.SaveAs(sArchivo)
            apWord.Quit(save_changes)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub DatosAExcel(sSQL As String, sPath As String, ByVal sArchivo As String, sTitulo As String, sParametros As String, d As T_DESTINO, aColsTotalizar() As Integer, ByRef sError As String)
        Dim r As System.Data.DataRow
        Dim dt As System.Data.DataSet

        Try
            sArchivo = sArchivo & ".TMP"
            dt = oHandler.Base.Consultar(sSQL)

            If My.Computer.FileSystem.FileExists(sPath & sArchivo) Then
                My.Computer.FileSystem.DeleteFile(sPath & sArchivo)
            End If

            FileOpen(1, sPath & sArchivo, OpenMode.Output)
            Dim sb As String = ""
            Dim i As Integer

            For i = 0 To dt.Tables(0).Columns.Count - 1
                sb &= dt.Tables(0).Columns(i).ColumnName & Microsoft.VisualBasic.ControlChars.Tab
            Next
            PrintLine(1, sb)
            i = 0
            For Each r In dt.Tables(0).Rows
                i = 0 : sb = ""
                For i = 0 To dt.Tables(0).Columns.Count - 1
                    If Not IsDBNull(r.Item(i)) Then
                        If dt.Tables(0).Columns(i).GetType.Name = "DateTime" Then
                            sb &= Format(r.Item(i).ToString, "dd/MM/yyyy") & Microsoft.VisualBasic.ControlChars.Tab
                        Else
                            sb &= CStr(r.Item(i).ToString) & Microsoft.VisualBasic.ControlChars.Tab
                        End If
                    Else
                        sb &= Microsoft.VisualBasic.ControlChars.Tab
                    End If

                Next
                PrintLine(1, sb)
            Next
            FileClose(1)

            If TextToExcel(sPath, sArchivo, sTitulo, sParametros, d, aColsTotalizar, sError) Then
                sError = "Datos exportados correctamente"
            End If
        Catch ex As Exception
            sError = ex.Message
        End Try
    End Sub

    Public Function TextToExcel(sPath As String, ByVal sArchivo As String, sTitulo As String, sParametros As String, d As T_DESTINO, aColsTotalizar() As Integer, ByRef sError As String) As String
        Dim valor As Integer = 1
        Dim sArchivoTMP As String = sPath & sArchivo
        Dim sArchivoDestino As String
        Dim i As Integer
        Dim nCol, nFilaInicioData, nFilaFinData As Integer
        Dim sCol As String

        Dim nColTitulos As Integer = 3
        Dim sLetraColTitulos As String = "C"
        Const FILAS_DESPLAZAR = 8

        Try

            Dim vFormato As Microsoft.Office.Interop.Excel.XlRangeAutoFormat
            Dim vCultura As System.Globalization.CultureInfo = New Globalization.CultureInfo("es-UY")

            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("es-UY")

            Dim Exc As Excel.Application = New Excel.Application
            Exc.Workbooks.OpenText(sPath & sArchivo, , , , Excel.XlTextQualifier.xlTextQualifierNone, , True)

            Dim oLibro As Excel.Workbook = Exc.ActiveWorkbook
            Dim oHoja As Excel.Worksheet = oLibro.ActiveSheet

            vFormato = Excel.XlRangeAutoFormat.xlRangeAutoFormatTable1


            nFilaFinData = oHoja.UsedRange.Rows.Count

            ' Carga Datos
            oHoja.Range(oHoja.Cells(1, 1), oHoja.Cells(oHoja.UsedRange.Rows.Count, oHoja.UsedRange.Columns.Count)).AutoFormat(vFormato)

            ' Muevo todos los datos para abajo 7 lineas
            For i = 1 To FILAS_DESPLAZAR
                oHoja.Rows("1:1").Select()
                Exc.Selection.Insert(Shift:=-4121, CopyOrigin:=0)
            Next
            nFilaFinData = nFilaFinData + FILAS_DESPLAZAR
            nFilaInicioData = FILAS_DESPLAZAR + 2

            ' Totales
            For i = 0 To UBound(aColsTotalizar)
                nCol = aColsTotalizar(i)
                sCol = Chr(Asc("A") + nCol - 1)
                oHoja.Range(sCol & nFilaFinData + 1).Select()
                Exc.ActiveCell.Formula = "=SUM(" & sCol & nFilaInicioData & ":" & sCol & nFilaFinData & ")"
                oHoja.Range(sCol & nFilaFinData + 2).Select()
            Next

            ' Font por defecto de toda la hoja
            oHoja.Cells.Select()
            With Exc.Selection.Font
                .Name = "Calibri"
                .Size = 8
                .Strikethrough = False
                .Superscript = False
                .Subscript = False
                .OutlineFont = False
                .Shadow = False
                .TintAndShade = 0
            End With

            ' Inserta logo
            oHoja.Pictures.Insert(My.Application.Info.DirectoryPath & "\Logo.png").Select()
            Exc.Selection.ShapeRange.ScaleWidth(0.5, 0, 0)
            Exc.Selection.ShapeRange.ScaleHeight(0.5, 0, 0)

            ' Nombre de la empresa
            oHoja.Cells(1, nColTitulos) = NOMBRE_EMPRESA

            ' Fecha / Hora de Impresion
            oHoja.Cells(1, nColTitulos + 3) = "Emitido : " & Format(Date.Now, "dd/MM/yyyy hh:mm")

            ' Titulo
            oHoja.Cells(3, nColTitulos) = sTitulo
            oHoja.Range(sLetraColTitulos & "3").Select()
            With Exc.Selection.Font
                .Name = "Calibri"
                .Size = 14
                .Strikethrough = False
                .Superscript = False
                .Subscript = False
                .OutlineFont = False
                .Shadow = False
                .TintAndShade = 0
            End With

            ' Parametros
            oHoja.Cells(5, nColTitulos) = sParametros

            If d = T_DESTINO.EXCEL Then
                sArchivoDestino = sArchivoTMP.Replace(".TMP", ".XLS")
                If My.Computer.FileSystem.FileExists(sArchivoDestino) Then
                    My.Computer.FileSystem.DeleteFile(sArchivoDestino)
                End If

                Exc.ActiveWorkbook.SaveAs(sArchivoDestino, Excel.XlTextQualifier.xlTextQualifierNone - 1)
            Else
                sArchivoDestino = sArchivoTMP.Replace(".TMP", ".PDF")
                If My.Computer.FileSystem.FileExists(sArchivoDestino) Then
                    My.Computer.FileSystem.DeleteFile(sArchivoDestino)
                End If

                Exc.ActiveWorkbook.ExportAsFixedFormat(Microsoft.Office.Interop.Excel.XlFixedFormatType.xlTypePDF, sArchivoDestino)
            End If
            Exc.ActiveWorkbook.Saved = True
            Exc.Workbooks.Close()
            Exc.Quit()
            oHoja = Nothing
            oLibro = Nothing
            Exc = Nothing
            GC.Collect()
            File.Delete(sArchivoTMP)

            ' Abre archivo
            If d = T_DESTINO.EXCEL Then
                If valor > -1 Then
                    Dim p As System.Diagnostics.Process = New System.Diagnostics.Process
                    p.EnableRaisingEvents = False
                    Process.Start("Excel.exe", sArchivoDestino)
                End If
                '                System.Threading.Thread.CurrentThread.CurrentCulture = vCultura
            Else
                Process.Start(sArchivoDestino)
            End If
            sError = ""
            Return True
        Catch ex As Exception
            sError = ex.Message
            Return False
        End Try

    End Function

#End Region


End Module


