Public Class Handler

    Private oBase As AccesoBase.AccesoBaseSQL

#Region "GENERALES"
    Public Function GetParametro(idParam As Integer, ByRef sValor As String) As Boolean
        Dim b As New DAOBase(Me.Base)
        Return b.GetParametro(idParam, sValor)
    End Function

    Public Function SetParametro(idParam As Integer, sNombre As String, sValor As String) As Boolean
        Dim b As New DAOBase(Me.Base)
        Return b.GrabarParametro(idParam, sNombre, sValor)
    End Function
    Public Function Restore(sArchivo As String, ByRef sError As String) As Boolean
        Dim b As New DAOBase(Me.Base)
        Return b.Restore(sArchivo, sError)
    End Function

    Public Function BackUp(sArchivo As String, ByRef sError As String) As Boolean
        Dim b As New DAOBase(Me.Base)
        Return b.BackUp(sArchivo, sError)
    End Function
    Public Function GetId(ByVal sTabla) As Long
        Dim d As New DAOBase(Me.Base)
        Return d.GetId(sTabla)
    End Function

    Public Property Base() As AccesoBase.AccesoBaseSQL
        Get
            Return Me.oBase
        End Get
        Set(ByVal value As AccesoBase.AccesoBaseSQL)
            Me.oBase = value
        End Set
    End Property

    Private Function Conectar(ByRef sError As String) As Boolean
        Dim d As System.Data.DataSet

        Try
            oBase = New AccesoBase.AccesoBaseSQL
            oBase.StringConexion = CONEXION_SQL

            d = oBase.Consultar("select count(*) from PARAMETROS")

            If d.Tables.Count = 0 Then
                sError = "No se encontraron tablas necesarias para el programa."
                Conectar = False
            Else
                Conectar = True
            End If
        Catch ex As Exception
            sError = "Imposible conectarse al servidor. Conexion : " & CONEXION_SQL
            Conectar = False
        End Try

    End Function
    Public Sub New()
        Dim sError As String = ""
        If Not Me.Conectar(sError) Then
            MsgBox("No se pudo conectar : " & sError)
        End If
    End Sub

    Public Sub CargarLista(ByRef l As Windows.Forms.ListView, ByVal sTabla As String, ByVal sCampoCod As String, ByVal sCampoDesc As String, ByVal sCond As String, ByVal bChecked As Boolean)
        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim sSQL As String
        Dim itm As New ListViewItem

        sSQL = "select " & sCampoCod & "," & sCampoDesc & " from " & sTabla
        If sCond <> "" Then
            sSQL = sSQL & " where " & sCond
        End If

        sSQL = sSQL & " order by " & sCampoCod

        l.Items.Clear()
        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            itm = New ListViewItem
            itm.Tag = r.Item(0)
            itm.Text = r.Item(0)
            itm.SubItems.Add(r.Item(1))
            If Not (l.SmallImageList Is Nothing) Then
                If r.Item(0) <= l.SmallImageList.Images.Count Then
                    itm.ImageIndex = r.Item(0) - 1
                End If
            End If
            itm.Checked = bChecked
            l.Items.Add(itm)
        Next
        d = Nothing
    End Sub

    Public Sub CargarCombo(ByRef c As Windows.Forms.ComboBox, ByVal sTabla As String, ByVal sCampoCod As String, ByVal sCampoDesc As String, ByVal sCond As String, Optional ByVal sCodEsp As String = "", Optional ByVal sDescEsp As String = "")
        Dim oCol As New ArrayList
        Dim elem As ElementoCombo

        Dim d As System.Data.DataSet
        Dim r As System.Data.DataRow
        Dim sSQL As String

        sSQL = "select " & sCampoCod & "," & sCampoDesc & " from " & sTabla
        If sCond <> "" Then
            sSQL = sSQL & " where " & sCond
        End If
        sSQL = sSQL & " order by " & sCampoDesc

        d = oBase.Consultar(sSQL)
        For Each r In d.Tables(0).Rows
            elem = New ElementoCombo(r.Item(0), r.Item(1))
            oCol.Add(elem)
        Next
        d = Nothing

        If sCodEsp <> "" Then
            elem = New ElementoCombo(sCodEsp, sDescEsp)
            oCol.Add(elem)
        End If
        c.ValueMember = "Codigo"
        c.DisplayMember = "Descripcion"
        c.DataSource = oCol

        If c.Items.Count > 0 Then
            c.SelectedIndex = 0
        End If
    End Sub

    Function CargarTablaCodigos(ByVal sTabla As String) As DataTable
        Dim o As New DAOBase(Me.oBase)
        Return o.CargarTablaCodigos(sTabla)
    End Function
    Function GetColumnas(ByVal sTabla As String) As DataSet
        Dim o As New DAOBase(Me.oBase)
        Return o.GetColumnas(sTabla)
    End Function

    Function GrabarTablaCodigos(ByVal t As T_CLASE_CODIGOS, ByRef sError As String) As Boolean
        Dim o As New DAOBase(Me.oBase)
        Return o.GrabarTablaCodigos(t, sError)
    End Function
#End Region
#Region "PRENDAS"
    Public Function Vender(v As Venta, ByRef sError As String) As Boolean
        Dim oP As New VentasDAO(Me.oBase)
        Return oP.Vender(v, sError)
    End Function

    Public Function Devolver(nIdPrenda As Integer, nCant As Integer, dtFecha As Date, ByRef sError As String) As Boolean
        Dim oP As New PrendaDAO(Me.oBase)
        Return oP.Devolver(nIdPrenda, nCant, dtFecha, sError)
    End Function
    Public Function GrabarPrenda(ByVal o As Prenda, ByVal bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim oP As New PrendaDAO(Me.oBase)
        If oP.Grabar(o, bEliminar, sError) Then
            Return oP.GrabarImagenes(o, sError)
        Else
            Return False
        End If

    End Function

    Public Function GrabarImagenesPrenda(ByVal o As Prenda, ByRef sError As String) As Boolean
        Dim oP As New PrendaDAO(Me.oBase)
        Return oP.GrabarImagenes(o, sError)
    End Function

    Public Function CargarPrenda(ByVal nid As Long) As Prenda
        Dim oP As New PrendaDAO(Me.oBase)
        Return oP.Cargar(nid, False)
    End Function

    Public Function CargarPrendas(sFiltro As String, nTipo As Integer) As Prendas
        Dim oP As New PrendaDAO(Me.oBase)
        If nTipo = 1 Then
            Return oP.CargarLista()
        Else
            Return oP.CargarLista2(sFiltro)
        End If
    End Function

#End Region
#Region "CLIENTES"
    Public Function GenCaratulaEnvio(ocliente As Cliente, ByRef sArchivo As String) As Boolean
        Return Reportes.GenerarCaratula(ocliente, sArchivo)
    End Function

    Public Function NuevoCupon(nIdCliente As Integer, nIdCupon As Integer, dPje As Double, ByRef sError As String) As Boolean
        Dim oP As New ClienteDAO(Me.oBase)
        Return oP.EntregarCupon(nIdCliente, nIdCupon, dPje, sError)
    End Function

    Public Function CargarCliente(nId As Integer, bSoloCuponesDisponibles As Boolean) As Cliente
        Dim oP As New ClienteDAO(Me.oBase)
        Dim oClis As Clientes
        oClis = oP.CargarLista("C.id_contacto = " & nId, bSoloCuponesDisponibles)
        If oClis.Count > 0 Then
            Return oClis.Items(1)
        Else
            Return Nothing
        End If
    End Function

    Public Function CargarClientes(sFiltro As String, bSoloCuponesDisponibles As Boolean) As Clientes
        Dim oP As New ClienteDAO(Me.oBase)
        Return oP.CargarLista(sFiltro, bSoloCuponesDisponibles)
    End Function
    Public Function GrabarCliente(ByVal o As Cliente, bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim oP As New ClienteDAO(Me.oBase)
        Return oP.Grabar(o, bEliminar, sError)
    End Function
#End Region
#Region "PROVEEDORES"
    Public Function CargarProveedor(nId As Integer) As Proveedor
        Dim oP As New ProveedorDAO(Me.oBase)
        Return oP.Cargar(nId)
    End Function

    Public Function CargarProveedores(sFiltro As String) As Proveedores
        Dim oP As New ProveedorDAO(Me.oBase)
        Return oP.CargarLista(sFiltro)
    End Function

    Public Function GrabarProveedor(ByVal o As Proveedor, bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim oP As New ProveedorDAO(Me.oBase)
        Return oP.Grabar(o, bEliminar, sError)
    End Function

#End Region
#Region "FINANZAS"
    Friend Function CargarLiquidaciones() As List(Of T_LIQUIDACION)
        Dim oFin As New FinanzasDAO(Me.oBase)
        Return oFin.CargarLiquidaciones
    End Function

    Public Function Liquidar(nIdProv As Integer, dImporte As Double, dPjeComis As Double, sListaPrendas As String, ByRef sError As String) As Boolean
        Dim oFin As New FinanzasDAO(Me.oBase)
        Return oFin.Liquidar(nIdProv, dImporte, dPjeComis, sListaPrendas, sError)
    End Function
#End Region
#Region "PROMOS"
    Public Function PromoAgregarPrendas(nId As Integer, sListaPrendas As String, ByRef sError As String) As Integer
        Dim oP As New PromoDAO(Me.oBase)
        Return oP.AddPrendas(nId, sListaPrendas, sError)
    End Function
    Public Function CargarPromos() As Promos
        Dim oP As New PromoDAO(Me.oBase)
        Return oP.CargarLista()
    End Function
    Public Function GrabarPromo(ByVal o As Promo, bEliminar As Boolean, ByRef sError As String) As Boolean
        Dim oP As New PromoDAO(Me.oBase)
        Return oP.Grabar(o, bEliminar, sError)
    End Function
    Public Function QuitarPrendaPromo(nIdPromo As Integer, nIdPrenda As Integer) As Boolean
        Dim oP As New PromoDAO(Me.oBase)
        Return oP.RemovePrendas(nIdPromo, nIdPrenda)
    End Function

#End Region


End Class
