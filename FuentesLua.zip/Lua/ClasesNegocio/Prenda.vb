Public Class Prenda
    Public Enum T_ACCION_IMAGEN
        NADA = 0
        AGREGAR = 1
        ELIMINAR = 2
    End Enum
    Public Structure T_IMAGEN
        Dim IdSec As Integer
        Dim Archivo As String
        Dim Accion As T_ACCION_IMAGEN
    End Structure
    Private bReservaVencida As Boolean
    Public Property ReservaVencida() As Boolean
        Get
            Return bReservaVencida
        End Get
        Set(ByVal value As Boolean)
            bReservaVencida = value
        End Set
    End Property
    Private nTemporada As Integer
    Private sTemporada As String
    Public Property Temporada() As String
        Get
            Return sTemporada
        End Get
        Set(ByVal value As String)
            sTemporada = value
        End Set
    End Property
    Public Property CodTemporada() As Integer
        Get
            Return nTemporada
        End Get
        Set(ByVal value As Integer)
            nTemporada = value
        End Set
    End Property


    Private nId As Long
    Public Property Id() As Long
        Get
            Return nId
        End Get
        Set(ByVal value As Long)
            nId = value
        End Set
    End Property

    Public ReadOnly Property PrimerIdImagen() As Integer
        Get
            Dim t As T_IMAGEN
            Dim nMin As Integer = 999

            For Each t In Me.aImagenes
                If t.IdSec < nMin Then
                    nMin = t.IdSec
                End If
            Next
            Return (nMin)
        End Get
    End Property
    Public ReadOnly Property UltimoIdImagen() As Integer
        Get
            Dim t As T_IMAGEN
            Dim nMax As Integer = 0

            For Each t In Me.aImagenes
                If t.IdSec >= nMax Then
                    nMax = t.IdSec
                End If
            Next
            Return (nMax)
        End Get
    End Property

    Private nStock As Integer
    Public Property Stock() As Integer
        Get
            Return nStock
        End Get
        Set(ByVal value As Integer)
            nStock = value
        End Set
    End Property


    Private nCantFotos As Integer
    Public Property CantFotos() As Integer
        Get
            Return nCantFotos
        End Get
        Set(ByVal value As Integer)
            nCantFotos = value
        End Set
    End Property

    Private sComentarios As String
    Public Property Descripcion() As String
        Get
            Return sComentarios
        End Get
        Set(ByVal value As String)
            sComentarios = value
        End Set
    End Property
    Private sClienteVendida As String
    Public Property ClienteVenta() As String
        Get
            Return sClienteVendida
        End Get
        Set(ByVal value As String)
            sClienteVendida = value
        End Set
    End Property

    Private dFecVendida As Date
    Public Property FecVenta() As Date
        Get
            Return dFecVendida
        End Get
        Set(ByVal value As Date)
            dFecVendida = value
        End Set
    End Property
    Private dFecDevuelta As Date
    Public Property FecDevolucion() As Date
        Get
            Return dFecDevuelta
        End Get
        Set(ByVal value As Date)
            dFecDevuelta = value
        End Set
    End Property
    Private nCodStatus As Integer
    Public Property CodStatus() As Integer
        Get
            Return nCodStatus
        End Get
        Set(ByVal value As Integer)
            nCodStatus = value
        End Set
    End Property

    Private sStatus As String
    Public Property Status() As String
        Get
            Return sStatus
        End Get
        Set(ByVal value As String)
            sStatus = value
        End Set
    End Property

    Private sExtraInfo As String
    Public Property ExtraInfo() As String
        Get
            Return sExtraInfo
        End Get
        Set(ByVal value As String)
            sExtraInfo = value
        End Set
    End Property
    Private sMarca As String
    Public Property Marca() As String
        Get
            Return sMarca
        End Get
        Set(ByVal value As String)
            sMarca = value
        End Set
    End Property

    Private sTamanio As String
    Public Property Tamanio() As String
        Get
            Return sTamanio
        End Get
        Set(ByVal value As String)
            sTamanio = value
        End Set
    End Property

    Private sEstado As String
    Public Property Estado() As String
        Get
            Return sEstado
        End Get
        Set(ByVal value As String)
            sEstado = value
        End Set
    End Property

    Private nCosto As Double
    Public Property Costo() As Double
        Get
            Return nCosto
        End Get
        Set(ByVal value As Double)
            nCosto = value
        End Set
    End Property
    Private nPrecio As Double
    Public Property Precio() As Double
        Get
            Return nPrecio
        End Get
        Set(ByVal value As Double)
            nPrecio = value
        End Set
    End Property

    Private nMarca As Integer
    Public Property CodMarca() As Integer
        Get
            Return nMarca
        End Get
        Set(ByVal value As Integer)
            nMarca = value
        End Set
    End Property

    Private sProveedor As String
    Public Property Proveedor() As String
        Get
            Return sProveedor
        End Get
        Set(ByVal value As String)
            sProveedor = value
        End Set
    End Property
    Private nTamanio As Integer
    Public Property CodTamanio() As Integer
        Get
            Return nTamanio
        End Get
        Set(ByVal value As Integer)
            nTamanio = value
        End Set
    End Property

    Private sCategoria As String
    Public Property Categoria() As String
        Get
            Return sCategoria
        End Get
        Set(ByVal value As String)
            sCategoria = value
        End Set
    End Property

    Private dtFecIngreso As Date
    Public Property FecIngreso() As Date
        Get
            Return dtFecIngreso
        End Get
        Set(ByVal value As Date)
            dtFecIngreso = value
        End Set
    End Property

    Private nIdProveedor As Integer
    Public Property IdProveedor() As Integer
        Get
            Return nIdProveedor
        End Get
        Set(ByVal value As Integer)
            nIdProveedor = value
        End Set
    End Property

    Private nIdCategoria As Integer
    Public Property IdCategoria() As Integer
        Get
            Return nIdCategoria
        End Get
        Set(ByVal value As Integer)
            nIdCategoria = value
        End Set
    End Property

    Private nEstado As Integer
    Public Property CodEstado() As Integer
        Get
            Return nEstado
        End Get
        Set(ByVal value As Integer)
            nEstado = value
        End Set
    End Property
    Private aImagenes As ArrayList
    Public Promos As Promos

    Public Sub AddImagen(ByVal t As T_IMAGEN)
        Me.aImagenes.Add(t)
    End Sub
    Public Function Imagenes() As ArrayList
        Return Me.aImagenes
    End Function
    Public Sub New()
        Me.aImagenes = New ArrayList
        Me.CodStatus = T_STATUS.DISPONIBLE
        Promos = New Promos
    End Sub

End Class
