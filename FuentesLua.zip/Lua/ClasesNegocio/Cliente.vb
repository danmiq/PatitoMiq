﻿Public Class Cliente

    Private nCantCompras As Integer
    Public Property CantCompras() As Integer
        Get
            Return nCantCompras
        End Get
        Set(ByVal value As Integer)
            nCantCompras = value
        End Set
    End Property

    Private nCantCupones As Integer
    Public Property CantCupones() As Integer
        Get
            Return nCantCupones
        End Get
        Set(ByVal value As Integer)
            nCantCupones = value
        End Set
    End Property

    Private nId As Long
    Public Property Id() As Long
        Get
            Return nId
        End Get
        Set(ByVal value As Long)
            nId = value
        End Set
    End Property

    Private sNombre As String
    Public Property Nombre() As String
        Get
            Return sNombre
        End Get
        Set(ByVal value As String)
            sNombre = value
        End Set
    End Property

    Private sTel As String
    Public Property Telefono() As String
        Get
            Return sTel
        End Get
        Set(ByVal value As String)
            sTel = value
        End Set
    End Property
    Private sDir As String
    Public Property Direccion() As String
        Get
            Return sDir
        End Get
        Set(ByVal value As String)
            sDir = value
        End Set
    End Property
    Private sLoc As String
    Public Property Localidad() As String
        Get
            Return sLoc
        End Get
        Set(ByVal value As String)
            sLoc = value
        End Set
    End Property
    Private sMail As String
    Public Property Mail() As String
        Get
            Return sMail
        End Get
        Set(ByVal value As String)
            sMail = value
        End Set
    End Property
    Private dFecIngreso As Date
    Public Property FecIngreso() As Date
        Get
            Return dFecIngreso
        End Get
        Set(ByVal value As Date)
            dFecIngreso = value
        End Set
    End Property

    Public Cupones As Cupones

    Public Sub New()
        Me.Cupones = New Cupones
    End Sub
End Class
