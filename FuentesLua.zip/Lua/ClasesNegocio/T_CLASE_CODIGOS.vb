Public Class T_CLASE_CODIGOS

    Public Enum T_OPERACION
        INCAMBIADO = -1
        NUEVO = 0
        MODIFICADO = 1
        ELIMINADO = 2
    End Enum

    Private sTabla As String
    Private sCampoCodigo As String
    Private sCampoDesc As String
    Private aElementos As Hashtable
    Public Property Tabla() As String
        Get
            Return sTabla
        End Get
        Set(ByVal value As String)
            sTabla = value
        End Set
    End Property
    Public Property CampoCodigo() As String
        Get
            Return sCampoCodigo
        End Get
        Set(ByVal value As String)
            sCampoCodigo = value
        End Set
    End Property
    Public Property CampoDesc() As String
        Get
            Return sCampoDesc
        End Get
        Set(ByVal value As String)
            sCampoDesc = value
        End Set
    End Property
    Public Property Elementos() As Hashtable
        Get
            Return aElementos
        End Get
        Set(ByVal value As Hashtable)
            aElementos = value
        End Set
    End Property
    Public Sub Add(ByVal sCod As Long, ByVal sDesc As Object, ByVal nIdOper As Integer)
        Me.aElementos.Add(CStr(sCod), nIdOper.ToString.Trim & "|" & sDesc)
    End Sub
    Public Sub New()
        Me.aElementos = New Hashtable

    End Sub
End Class

