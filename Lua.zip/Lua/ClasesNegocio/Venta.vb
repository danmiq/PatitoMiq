﻿Public Class Venta
    Friend Structure T_VENTA
        Dim CodPrenda As Integer
        Dim Cantidad As Integer
        Dim Precio As Double
    End Structure
    Public CodCliente As Integer
    Friend aArticulos As List(Of T_VENTA)

    Public Sub New()
        Me.CodCliente = 0
        Me.aArticulos = New List(Of T_VENTA)
    End Sub
End Class
