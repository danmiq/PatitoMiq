Structure ElementoCombo
    Private sDescripcion As String
    Private nCodigo As Object
    Public Sub New(ByVal nCodigoP As Object, ByVal sDescripcionP As String)
        sDescripcion = sDescripcionP
        nCodigo = nCodigoP
    End Sub
    Public ReadOnly Property Descripcion() As String
        Get
            Return sDescripcion
        End Get
    End Property
    Public ReadOnly Property Codigo() As Object
        Get
            Return nCodigo
        End Get
    End Property
End Structure
