﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmVenta
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmVenta))
        Me.txtNomCliente = New System.Windows.Forms.TextBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lblAccion = New System.Windows.Forms.Label()
        Me.dtFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblIdContacto = New System.Windows.Forms.Label()
        Me.lblPrecioFinal = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.grCliente = New System.Windows.Forms.GroupBox()
        Me.lblStatusCliente = New System.Windows.Forms.Label()
        Me.txtMail = New System.Windows.Forms.TextBox()
        Me.txtDireccion = New System.Windows.Forms.TextBox()
        Me.txtTelefono = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lvDatos = New System.Windows.Forms.ListView()
        Me.id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Descripcion = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Cantidad = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPrecio = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSubTotal = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colStock = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtBusqueda = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.grCliente.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtNomCliente
        '
        Me.txtNomCliente.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtNomCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNomCliente.Location = New System.Drawing.Point(65, 19)
        Me.txtNomCliente.Name = "txtNomCliente"
        Me.txtNomCliente.Size = New System.Drawing.Size(308, 20)
        Me.txtNomCliente.TabIndex = 1
        '
        'btnOK
        '
        Me.btnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnOK.Location = New System.Drawing.Point(404, 402)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 28)
        Me.btnOK.TabIndex = 1
        Me.btnOK.TabStop = False
        Me.btnOK.Text = "Confirmar"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(485, 402)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 28)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.TabStop = False
        Me.btnCancel.Text = "Salir"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'lblAccion
        '
        Me.lblAccion.AutoSize = True
        Me.lblAccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccion.Location = New System.Drawing.Point(6, 56)
        Me.lblAccion.Name = "lblAccion"
        Me.lblAccion.Size = New System.Drawing.Size(49, 13)
        Me.lblAccion.TabIndex = 3
        Me.lblAccion.Text = "Teléfono"
        '
        'dtFecha
        '
        Me.dtFecha.CustomFormat = "dd/MM/yyyy"
        Me.dtFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtFecha.Location = New System.Drawing.Point(473, 16)
        Me.dtFecha.Name = "dtFecha"
        Me.dtFecha.Size = New System.Drawing.Size(109, 20)
        Me.dtFecha.TabIndex = 5
        Me.dtFecha.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(430, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(37, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Fecha"
        '
        'lblIdContacto
        '
        Me.lblIdContacto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIdContacto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIdContacto.Location = New System.Drawing.Point(3, 19)
        Me.lblIdContacto.Name = "lblIdContacto"
        Me.lblIdContacto.Size = New System.Drawing.Size(54, 20)
        Me.lblIdContacto.TabIndex = 8
        Me.lblIdContacto.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPrecioFinal
        '
        Me.lblPrecioFinal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPrecioFinal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrecioFinal.Location = New System.Drawing.Point(457, 355)
        Me.lblPrecioFinal.Name = "lblPrecioFinal"
        Me.lblPrecioFinal.Size = New System.Drawing.Size(59, 20)
        Me.lblPrecioFinal.TabIndex = 103
        Me.lblPrecioFinal.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Navy
        Me.Label5.Location = New System.Drawing.Point(417, 359)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 102
        Me.Label5.Text = "Total"
        '
        'grCliente
        '
        Me.grCliente.Controls.Add(Me.lblStatusCliente)
        Me.grCliente.Controls.Add(Me.txtMail)
        Me.grCliente.Controls.Add(Me.txtDireccion)
        Me.grCliente.Controls.Add(Me.txtTelefono)
        Me.grCliente.Controls.Add(Me.Label2)
        Me.grCliente.Controls.Add(Me.Label1)
        Me.grCliente.Controls.Add(Me.txtNomCliente)
        Me.grCliente.Controls.Add(Me.lblIdContacto)
        Me.grCliente.Controls.Add(Me.lblAccion)
        Me.grCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grCliente.Location = New System.Drawing.Point(12, 12)
        Me.grCliente.Name = "grCliente"
        Me.grCliente.Size = New System.Drawing.Size(412, 129)
        Me.grCliente.TabIndex = 1
        Me.grCliente.TabStop = False
        Me.grCliente.Text = "Cliente"
        '
        'lblStatusCliente
        '
        Me.lblStatusCliente.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblStatusCliente.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblStatusCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatusCliente.ForeColor = System.Drawing.Color.White
        Me.lblStatusCliente.Location = New System.Drawing.Point(263, 103)
        Me.lblStatusCliente.Name = "lblStatusCliente"
        Me.lblStatusCliente.Size = New System.Drawing.Size(143, 18)
        Me.lblStatusCliente.TabIndex = 14
        Me.lblStatusCliente.Text = "Label4"
        Me.lblStatusCliente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtMail
        '
        Me.txtMail.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMail.Location = New System.Drawing.Point(65, 101)
        Me.txtMail.Name = "txtMail"
        Me.txtMail.Size = New System.Drawing.Size(191, 20)
        Me.txtMail.TabIndex = 13
        Me.txtMail.TabStop = False
        '
        'txtDireccion
        '
        Me.txtDireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtDireccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDireccion.Location = New System.Drawing.Point(65, 77)
        Me.txtDireccion.Name = "txtDireccion"
        Me.txtDireccion.Size = New System.Drawing.Size(308, 20)
        Me.txtDireccion.TabIndex = 12
        Me.txtDireccion.TabStop = False
        '
        'txtTelefono
        '
        Me.txtTelefono.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtTelefono.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTelefono.Location = New System.Drawing.Point(65, 51)
        Me.txtTelefono.Name = "txtTelefono"
        Me.txtTelefono.Size = New System.Drawing.Size(191, 20)
        Me.txtTelefono.TabIndex = 2
        Me.txtTelefono.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Mail"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 80)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Direccion"
        '
        'lvDatos
        '
        Me.lvDatos.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.lvDatos.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.id, Me.Descripcion, Me.Cantidad, Me.colPrecio, Me.colSubTotal, Me.colStock})
        Me.lvDatos.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lvDatos.FullRowSelect = True
        Me.lvDatos.GridLines = True
        Me.lvDatos.HideSelection = False
        Me.lvDatos.Location = New System.Drawing.Point(12, 194)
        Me.lvDatos.Name = "lvDatos"
        Me.lvDatos.Size = New System.Drawing.Size(515, 158)
        Me.lvDatos.TabIndex = 108
        Me.lvDatos.TabStop = False
        Me.lvDatos.UseCompatibleStateImageBehavior = False
        Me.lvDatos.View = System.Windows.Forms.View.Details
        '
        'id
        '
        Me.id.Text = "Código"
        Me.id.Width = 77
        '
        'Descripcion
        '
        Me.Descripcion.Text = "Artículo"
        Me.Descripcion.Width = 248
        '
        'Cantidad
        '
        Me.Cantidad.Text = "Cantidad"
        Me.Cantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colPrecio
        '
        Me.colPrecio.Text = "Precio"
        Me.colPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colSubTotal
        '
        Me.colSubTotal.Text = "SubTotal"
        '
        'colStock
        '
        Me.colStock.Text = "Stock"
        '
        'cmdAdd
        '
        Me.cmdAdd.Image = CType(resources.GetObject("cmdAdd.Image"), System.Drawing.Image)
        Me.cmdAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdAdd.Location = New System.Drawing.Point(275, 160)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(70, 25)
        Me.cmdAdd.TabIndex = 3
        Me.cmdAdd.Text = "Agregar"
        Me.cmdAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cmdAdd.UseVisualStyleBackColor = True
        '
        'txtBusqueda
        '
        Me.txtBusqueda.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtBusqueda.Location = New System.Drawing.Point(77, 163)
        Me.txtBusqueda.Name = "txtBusqueda"
        Me.txtBusqueda.Size = New System.Drawing.Size(191, 20)
        Me.txtBusqueda.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 111
        Me.Label4.Text = "Artículo"
        '
        'frmVenta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(594, 439)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtBusqueda)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.lvDatos)
        Me.Controls.Add(Me.grCliente)
        Me.Controls.Add(Me.dtFecha)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblPrecioFinal)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "frmVenta"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Venta"
        Me.grCliente.ResumeLayout(False)
        Me.grCliente.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtNomCliente As System.Windows.Forms.TextBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents lblAccion As System.Windows.Forms.Label
    Friend WithEvents dtFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblIdContacto As System.Windows.Forms.Label
    Friend WithEvents lblPrecioFinal As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents grCliente As System.Windows.Forms.GroupBox
    Friend WithEvents txtMail As System.Windows.Forms.TextBox
    Friend WithEvents txtDireccion As System.Windows.Forms.TextBox
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lvDatos As System.Windows.Forms.ListView
    Friend WithEvents id As System.Windows.Forms.ColumnHeader
    Friend WithEvents Descripcion As System.Windows.Forms.ColumnHeader
    Friend WithEvents Cantidad As System.Windows.Forms.ColumnHeader
    Friend WithEvents colPrecio As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents lblStatusCliente As System.Windows.Forms.Label
    Friend WithEvents colSubTotal As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtBusqueda As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents colStock As System.Windows.Forms.ColumnHeader
End Class
