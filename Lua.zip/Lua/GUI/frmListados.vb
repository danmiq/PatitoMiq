﻿Public Class frmListados

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()

    End Sub

    Private Sub frmListados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        oHandler.CargarCombo(Me.cboProveedor, "PROVEEDORES", "id_proveedor", "Nombre", "", "999", "*** TODOS ***")
        oHandler.CargarLista(Me.lvEstados, "STATUS", "cod_status", "Nombre", "", True)
        Me.lblStatus.Text = ""
        Me.rbExcel.Checked = True
        Me.dtDesde.Value = DateAdd(DateInterval.Month, -1, Date.Today)
        Me.dtHasta.Value = Date.Today

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        Dim sSQL As String
        Dim sError As String
        Dim d As T_DESTINO
        Dim sEstados As String = GUI.GetLista(Me.lvEstados, True)
        Dim sTitulo, sParametros, sArchivo As String
        Dim aTotales() As Integer

        If sEstados.Length = 0 Then
            MsgBox("Debe elegir al menos un Estado de Prenda")
        Else
            sSQL = GetSQL(IIf(Me.rbListadoStock.Checked, 1, 2), Me.cboProveedor.SelectedValue, sEstados, Me.dtDesde.Value, Me.dtHasta.Value, aTotales)
            If rbListadoStock.Checked Then
                sArchivo = "LISTADO_PRENDAS"
                sTitulo = "Listado de Prendas"
            Else
                sArchivo = "VENTAS"
                sTitulo = "Ventas efectuadas"
            End If

            sParametros = "Proveedor : " & Me.cboProveedor.Text
            If rbExcel.Checked Then
                d = T_DESTINO.EXCEL
            Else
                d = T_DESTINO.PDF
            End If
            Generales.DatosAExcel(sSQL, Constantes.CARPETA_REPORTES, sArchivo, sTitulo, sParametros, d, aTotales, sError)

            Me.lblStatus.Text = sError
        End If
    End Sub
    Function GetSQL(nTipoListado As Integer, nProveedor As Integer, sEstados As String, dFecDesde As Date, dFecHasta As Date, ByRef aTotales() As Integer) As String
        If nTipoListado = 1 Then
            GetSQL = "SELECT id_prenda as Prenda,NomCategoria as Categoria,NomMarca as Marca, NomTamanio as Talle, NomEstado as Estado,Precio, fec_ingreso as Ingreso,	NomProveedor as Proveedor, Status, txt_comentarios as Comentarios" & _
                     " FROM V_PRENDAS"
            GetSQL = GetSQL & " WHERE cod_status in (" & sEstados & ")"
            If nProveedor <> 999 Then
                GetSQL = GetSQL & " AND id_proveedor = " & nProveedor
            End If
            GetSQL = GetSQL & " ORDER BY id_prenda"
            aTotales = {6}
        Else

            GetSQL = "SELECT convert(varchar(10),V.fec_venta,103) as FecVenta, NomCategoria as Nombre, NomMarca as Marca, NomTamanio as Talle, " & _
                    " round(Precio * V.PjeComisProv / 100,2) as Precio, " & _
                    " C.Nombre as Cliente, Canal, pje_descuento as Descuento,id_cupon as Cupon, V.Promo,NomProveedor as Proveedor" & _
                    " FROM V_VENTAS V" & _
                    " JOIN CLIENTES C ON C.id_contacto = V.id_contacto"
            GetSQL = GetSQL & " WHERE fec_venta >= '" & FechaUniversal(dFecDesde) & "' AND fec_venta < '" & FechaUniversal(DateAdd(DateInterval.Day, 1, dFecHasta)) & "'"
            If nProveedor <> 999 Then
                GetSQL = GetSQL & " AND id_proveedor = " & nProveedor
            End If
            GetSQL = GetSQL & " ORDER BY fec_venta, id_prenda"
            aTotales = {5}
        End If
    End Function

    Private Sub rbListadoStock_CheckedChanged(sender As Object, e As EventArgs) Handles rbListadoStock.CheckedChanged
        Me.panelStock.Enabled = rbListadoStock.Checked
        Me.panelVentas.Enabled = rbListadoVentas.Checked
    End Sub
End Class