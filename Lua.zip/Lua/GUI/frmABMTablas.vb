Public Class frmABMTablas

    Dim Tabla As String
    Dim aColumnas As DataSet

    Private Sub btnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalir.Click
        If Not CambiosSinGuardar Then
            Me.Close()
        Else
            If MsgBox("Atencion : Tiene cambios no guardados" & vbCrLf & vbCrLf & "� Sale de todos modos ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Me.Close()
            End If
        End If
    End Sub

    Private Sub frmABMTablas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.lbTablas.Items.Clear()
        'Me.lbTablas.Items.Add(TABLA_CATEGORIAS)
        'Me.lbTablas.Items.Add(TABLA_CONCEPTOS_GASTO)
        'Me.lbTablas.Items.Add(TABLA_ESTADOS)
        'Me.lbTablas.Items.Add(TABLA_TALLES)
        'Me.lbTablas.Items.Add(TABLA_MARCAS)
        'Me.lbTablas.Items.Add(TABLA_COMISIONES)
        'Me.lbTablas.Items.Add(TABLA_CANALES)
        Me.lbTablas.Items.Add(TABLA_TEMPORADAS)
        'Me.lbTablas.Items.Add(TABLA_MEDIOS_ENVIO)
    End Sub

    Private Sub lbTablas_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbTablas.SelectedIndexChanged
        Dim bSigue As Boolean = True

        If Me.lbTablas.SelectedItem <> Me.Tabla And Me.Tabla <> "" And Me.CambiosSinGuardar Then
            If MsgBox("Atencion : Tiene cambios no guardados" & vbCrLf & vbCrLf & "� Sale de todos modos ?", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                bSigue = True
            Else
                bSigue = False
            End If
        End If

        If bSigue Then
            Me.Tabla = Me.lbTablas.SelectedItem
            aColumnas = oHandler.GetColumnas(Me.Tabla)
            CargarLista(Me.lvDatos, Me.Tabla, aColumnas)
        End If
    End Sub

    Sub CargarLista(ByRef l As ListView, ByVal sTabla As String, ByVal aColumnas As DataSet)
        Dim r As System.Data.DataRow
        Dim ds As System.Data.DataTable
        Dim itm As ListViewItem

        l.Columns.Clear()
        l.Columns.Add(aColumnas.Tables(0).Rows(0).Item("Nombre"), "Codigo", 80)
        l.Columns.Add(aColumnas.Tables(0).Rows(1).Item("Nombre"), "Descripcion", 400)

        ds = oHandler.CargarTablaCodigos(sTabla)
        l.Items.Clear()
        For Each r In ds.Rows
            itm = New ListViewItem
            itm.Text = r.Item(0)
            itm.SubItems.Add(r.Item(1))
            l.Items.Add(itm)
        Next
    End Sub

    Private Sub lvDatos_ItemActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvDatos.ItemActivate
        Dim k As Long
        Dim s As String

        If lvDatos.SelectedItems.Count > 0 Then
            k = lvDatos.SelectedItems(0).Text
            s = lvDatos.SelectedItems(0).SubItems(1).Text

            s = InputBox("Ingrese nuevo valor para codigo " & k.ToString, "Modificaci�n", s)
            lvDatos.SelectedItems(0).SubItems(1).Text = s
            If lvDatos.SelectedItems(0).ImageIndex = -1 Then
                lvDatos.SelectedItems(0).ImageIndex = T_CLASE_CODIGOS.T_OPERACION.MODIFICADO
            End If

        End If
    End Sub

    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        Dim k As Long
        Dim s As String
        Dim itm As ListViewItem

        k = 0
        For Each itm In Me.lvDatos.Items
            If CLng(itm.Text) > k Then
                k = CLng(itm.Text)
            End If
        Next
        k = k + 1

        s = InputBox("Ingrese descripcion para codigo " & k.ToString, "Nuevo item", "")
        itm = New ListViewItem
        itm.Text = k
        itm.SubItems.Add(s)
        itm.ImageIndex = T_CLASE_CODIGOS.T_OPERACION.NUEVO
        Me.lvDatos.Items.Add(itm)

    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If lvDatos.SelectedItems.Count > 0 Then
            If lvDatos.SelectedItems(0).ImageIndex = -1 Or lvDatos.SelectedItems(0).ImageIndex = T_CLASE_CODIGOS.T_OPERACION.MODIFICADO Then
                lvDatos.SelectedItems(0).ImageIndex = T_CLASE_CODIGOS.T_OPERACION.ELIMINADO
            End If
        End If
    End Sub

    Private Sub btnGrabar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGrabar.Click
        Dim t As T_CLASE_CODIGOS = GUI.SetTablaCodigos(Me.lvDatos, Me.lbTablas.SelectedItem, Me.lvDatos.Columns(0).Name, Me.lvDatos.Columns(1).Name)
        Dim sError As String = ""

        If Not oHandler.GrabarTablaCodigos(t, sError) Then
            MsgBox("Error al grabar : " & vbCrLf & sError, MsgBoxStyle.Critical)
        Else
            MsgBox("Datos almacenados", MsgBoxStyle.Information)
            CargarLista(Me.lvDatos, Me.Tabla, aColumnas)
        End If
    End Sub

    Function CambiosSinGuardar() As Boolean
        Dim itm As ListViewItem

        CambiosSinGuardar = False
        For Each itm In Me.lvDatos.Items
            If itm.ImageIndex = T_CLASE_CODIGOS.T_OPERACION.ELIMINADO Or itm.ImageIndex = T_CLASE_CODIGOS.T_OPERACION.MODIFICADO Or itm.ImageIndex = T_CLASE_CODIGOS.T_OPERACION.NUEVO Then
                CambiosSinGuardar = True
            End If
        Next
    End Function

    Private Sub lvDatos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvDatos.SelectedIndexChanged

    End Sub
End Class