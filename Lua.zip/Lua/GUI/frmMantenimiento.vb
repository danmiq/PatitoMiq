﻿Public Class frmMantenimiento
    Dim sArchivoSugerido As String

    Private Sub frmMantenimiento_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim s As String
        sArchivoSugerido = "Respaldo_Lua_" & FechaUniversal(Date.Today) & ".bak"
        Me.txtArchivoBackup.Text = CARPETA_BASE & sArchivoSugerido

        If oHandler.GetParametro(1, s) Then
            Me.txtEmpresa.Text = s
        Else
            Me.txtEmpresa.Text = "**** NO SE ENCONTRO PARAMETRO 1 ****"
        End If
        oHandler.GetParametro(2, s)
        Me.txtRemitente.Text = s

        oHandler.GetParametro(3, s)
        Me.txtTelRemitente.Text = s

        Me.txtSettingBase.Text = CARPETA_BASE
        Me.txtSettingImagenes.Text = CARPETA_IMAGENES
        Me.txtSettingReportes.Text = CARPETA_REPORTES
    End Sub

    Private Sub btnBackUp_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnGrabarEmpresa_Click(sender As Object, e As EventArgs) Handles btnGrabarEmpresa.Click

        If MsgBox("¿ Confirma estos parámetros ?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
            If oHandler.SetParametro(1, "NOMBRE DE LA EMPRESA", Me.txtEmpresa.Text) Then
                If oHandler.SetParametro(2, "REMITENTE PARA ENVIOS", Me.txtRemitente.Text) Then
                    If oHandler.SetParametro(3, "TEL. REMITENTE PARA ENVIOS", Me.txtTelRemitente.Text) Then
                        MsgBox("Parámetros actualizados correctamente", MsgBoxStyle.Information)
                    End If
                End If
            End If
        Else
            MsgBox("Error al grabar el dato", MsgBoxStyle.Information)

        End If
    End Sub

    Private Sub btnBackUp_Click_1(sender As Object, e As EventArgs) Handles btnBackUp.Click
        Dim sError As String
        If oHandler.BackUp(Me.txtArchivoBackup.Text, sError) Then
            MsgBox("Respaldo finalizado", MsgBoxStyle.Information)
        Else
            MsgBox("Error al respaldar base : " & vbCrLf & sError, MsgBoxStyle.Information)
        End If
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub btnDirectorio_Click(sender As Object, e As EventArgs) Handles btnDirectorio.Click
        Me.FolderBrowserDialog1.SelectedPath = System.IO.Path.GetDirectoryName(Me.txtArchivoBackup.Text)
        If Me.FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Me.txtArchivoBackup.Text = Me.FolderBrowserDialog1.SelectedPath & "\" & sArchivoSugerido
        End If

    End Sub
End Class