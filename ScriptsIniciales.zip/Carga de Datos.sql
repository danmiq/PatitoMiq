
-- -----------------------------------------------------------------------------------
-- Pasos para levantar la info
-- -----------------------------------------------------------------------------------

-- 1) Limpiar tablas "staging"
	truncate table FP_Mercaderia
	truncate table FP_Ventas
	TRUNCATE TABLE DEVOLUCIONES

-- 2) Ejecutar los scripts  VENTAS.SQL y MERCADERIA.SQL (carga tablas "staging")

-- 3) Cargar tablas finales

	-- 3.1) Prendas

	TRUNCATE TABLE PRENDAS

	INSERT INTO PRENDAS (id_prenda, Descripcion, id_proveedor, Costo, Stock, Precio, fec_ingreso, cod_status)
	select distinct ME_CODIGO,rtrim(ME_DESCRIP), [ME_NUMPROV ], ME_COSTO, case when ME_STOCK < 0 then 0 else ME_STOCK end , ME_COSTO,[ME_FECHA   ], 1
	FROM FP_Mercaderia F
	where F.[ME_NUMPROV ] >= 1380
	
	update PRENDAS set Descripcion = REPLACE(Descripcion, CHAR(39),'�')

	-- 3.2) Proveedores
	TRUNCATE TABLE PROVEEDORES

	drop table #proveedores
	select DISTINCT [ME_NUMPROV ] AS id_proveedor , rtrim(Ltrim(	[ME_NOMPROV ] )) as Nombre
	into #proveedores
	FROM FP_Mercaderia
	where [ME_NUMPROV ] >= 1380

	DELETE FROM #proveedores where id_proveedor =       1388 AND Nombre <> 'ALBA MENDEZ'	
	DELETE FROM #proveedores where id_proveedor =       1397 AND Nombre <> 'BEATRIZ GONZALEZ'
	DELETE FROM #proveedores where id_proveedor =       1397 AND Nombre <> 'BEATRIZ MARTINEZ'
	DELETE FROM #proveedores where id_proveedor =       1398 AND Nombre <> 'SANDRA OLAVE'
	DELETE FROM #proveedores where id_proveedor =       1411 AND Nombre <> 'KAREN KOLENDER'
	DELETE FROM #proveedores where id_proveedor =       1434 AND Nombre <> 'FELICIA LEV'
	DELETE FROM #proveedores where id_proveedor =       1474 AND Nombre <> 'SABRINA FISBOIM'
	DELETE FROM #proveedores where id_proveedor =       1488 AND Nombre <> 'CELESTE APOLO'
	DELETE FROM #proveedores where id_proveedor =       1490 AND Nombre <> 'ROSINA QUINTELA VARIETE'
	DELETE FROM #proveedores where id_proveedor =       1497 AND Nombre <> 'LORENA MALDEVER'
	DELETE FROM #proveedores where id_proveedor =       1530 AND Nombre <> 'MONICA GALLINARES VARIETE'
	DELETE FROM #proveedores where id_proveedor =       1598 AND Nombre <> 'VICTORIA PERERA VARIETE'
	DELETE FROM #proveedores where id_proveedor =       1644 AND Nombre <> 'ANDREA MORENI'
	DELETE FROM #proveedores where id_proveedor =       1762 AND Nombre <> 'STANKA MATULEVICIUS'
	DELETE FROM #proveedores where id_proveedor =       1943 AND Nombre <> 'MAGDALENA PE�A VARIETE'
	DELETE FROM #proveedores where id_proveedor =       1962 AND Nombre <> 'MACARENA GALISTEO'
	DELETE FROM #proveedores where id_proveedor =       1982 AND Nombre <> 'PAULA RODRIGUEZ BERRI'
	DELETE FROM #proveedores where id_proveedor =       1990 AND Nombre <> 'MONICA RIVERO'
	

	drop table #duplicados
	SELECT id_proveedor, count(distinct Nombre) as Cantidad
	into #duplicados
	FROM #proveedores group by  id_proveedor having count(distinct Nombre) > 1

	INSERT INTO PROVEEDORES(id_proveedor, Nombre)
	select DISTINCT 	id_proveedor , Nombre
	FROM #proveedores
	where id_proveedor not in ( SELECT id_proveedor from #duplicados)


	-- 3.3) Ventas
	TRUNCATE TABLE VENTAS

	INSERT INTO VENTAS(fec_venta, id_prenda,Precio,Cantidad,id_cliente)
	SELECT [VE_FECHA   ],[VE_CODIGO  ],[VE_PRECIO  ],[VE_CANTIDA ],null 
	from FP_VENTAS V
	WHERE  [VE_NUMPROV ] >= 1380
	AND V.[VE_CODIGO  ] IN (select id_prenda from PRENDAS)

	-- Seteo el precio de la PRENDA con el de la VENTA ( si difirieran)
	update PRENDAS
	set Precio = V.Precio
	from VENTAS V where V.id_prenda = Prendas.id_prenda
	and prendas.Precio <> V.Precio
	and V.precio <> 0

	-- Seteo precio de las VENTAS que no tienen pero la PRENDA si
	update ventas 
	set Precio = P.Precio
	from prendas P where P.id_prenda = ventas.id_prenda
	and Ventas.Precio = 0
	and P.precio <> 0

	-- Seteo autonumerador id_venta
	with T as (select ROW_NUMBER() over (order by fec_venta, id_prenda) as RN
        , id_venta from ventas)
    update T	set id_venta = RN

	-- 3.4) Estado de las prendas ya vendidas
	drop table #Vendidas
	select id_prenda, sum(Cantidad) as Cantidad 
	into #Vendidas 
	from VENTAS
	group by id_prenda

	update PRENDAS set cod_status = 3
	where exists (select * from #Vendidas V where V.id_prenda = prendas.id_prenda
	and V.Cantidad >= prendas.Stock)

