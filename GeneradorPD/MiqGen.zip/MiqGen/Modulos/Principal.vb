﻿
Module Principal

    Sub Main()
        Dim sCarpetaMolde, sCarpetaDestino, sArchProyecto As String
        Dim p As Proyecto
        Dim e As Entidad

        sCarpetaMolde = My.Application.CommandLineArgs(0)
        sArchProyecto = My.Application.CommandLineArgs(1)

        p = CargarProyecto(sArchProyecto)
        'sCarpetaDestino = "C:\temp\" & p.Nombre & "\"
        sCarpetaDestino = "C:\temp\"

        Dim oGenVB As New GeneradorVB2019(p.Nombre)
        oGenVB.CarpetaProyecto = sCarpetaDestino

        System.Console.WriteLine("Copiando Molde")
        oGenVB.CopiarMolde(sCarpetaMolde)

        Dim t As New Traductor

        'Agrega form Main

        oGenVB.AddForm("Main", t.GetMenu(p))

        ' Agrega forms por cada Entidad
        For Each e In p.Entidades
            System.Console.WriteLine("Agrega Form " & e.Nombre)
            oGenVB.AddForm(e.Nombre, t.GetObjetos(e))
        Next
        System.Console.WriteLine("Finalizado : Se ha creado el proyecto " & sCarpetaDestino & p.Nombre)
    End Sub
End Module

