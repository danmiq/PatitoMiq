﻿Module Principal

    Sub Main()
        Dim sCarpetaMolde, sCarpetaDestino, sProyecto As String
        Dim oGenVB As New GeneradorVB2019

        sCarpetaMolde = My.Application.CommandLineArgs(0)
        sCarpetaDestino = My.Application.CommandLineArgs(1)
        sProyecto = My.Application.CommandLineArgs(2)

        System.Console.WriteLine("Copiando Molde")
        oGenVB.CopiarMolde(sCarpetaMolde, sCarpetaDestino, sProyecto)

        System.Console.WriteLine("Agrega Form")
        oGenVB.AddForm(sCarpetaDestino & sProyecto & "\", "frmMain")

        System.Console.WriteLine("Finalizado")
        Stop

    End Sub





End Module

