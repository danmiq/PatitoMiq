﻿Module ManejoArchivos
    Public Sub FindReplace(sArchivo As String, sFind As String, sReplace As String)
        My.Computer.FileSystem.WriteAllText(sArchivo, My.Computer.FileSystem.ReadAllText(sArchivo).Replace(sFind, sReplace), False)
    End Sub
End Module
