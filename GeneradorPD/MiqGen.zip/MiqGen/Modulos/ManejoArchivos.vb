﻿Imports System.IO
Imports System.Xml.Serialization

Module ManejoArchivos
    Public Sub FindReplace(sArchivo As String, sFind As String, sReplace As String)
        My.Computer.FileSystem.WriteAllText(sArchivo, My.Computer.FileSystem.ReadAllText(sArchivo).Replace(sFind, sReplace), False)
    End Sub
    Public Function LeerXML(sArchivo As String) As System.Xml.XmlDocument
        Dim oXML As New System.Xml.XmlDocument
        Dim fs As New System.IO.FileStream(sArchivo, FileMode.Open, FileAccess.Read)
        oXML.Load(fs)
        fs.Close()
        Return oXML
    End Function
    Sub GrabarProyecto(p As Proyecto)
        Dim serializer As XmlSerializer = New XmlSerializer(p.GetType)
        Dim writer As TextWriter = New StreamWriter("c:\temp\" & p.Nombre & ".xml")
        serializer.Serialize(writer, p)
        writer.Close()
    End Sub
    Function CargarProyecto(sArchivo As String) As Proyecto
        Dim serializer As XmlSerializer = New XmlSerializer(GetType(Proyecto))
        Dim reader As TextReader = New StreamReader(sArchivo)
        CargarProyecto = serializer.Deserialize(reader)
        reader.Close()
    End Function
End Module
