﻿Public Class Generador
    Friend sProyecto As String

End Class
