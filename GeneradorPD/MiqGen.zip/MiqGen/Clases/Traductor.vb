﻿Imports System.Windows.Forms
Public Class Traductor

    Function GetMenu(P As Proyecto) As List(Of Object)
        Dim a As New List(Of Object)
        Dim e As Entidad

        Dim m As System.Windows.Forms.MenuStrip
        Dim itmMenu As System.Windows.Forms.ToolStripMenuItem

        m = New System.Windows.Forms.MenuStrip With {
                        .Name = "MenuStrip1",
                        .Text = "MenuPrincipal",
                        .Location = New Drawing.Point(0, 0),
                        .Dock = System.Windows.Forms.DockStyle.Left,
                        .Stretch = False
                    }
        a.Add(m)

        For Each e In P.Entidades
            itmMenu = New System.Windows.Forms.ToolStripMenuItem
            itmMenu.Name = "mnu" & e.Nombre
            itmMenu.Size = New System.Drawing.Size(61, 20)
            itmMenu.Text = e.Nombre
            a.Add(itmMenu)
        Next
        itmMenu = New System.Windows.Forms.ToolStripMenuItem
        itmMenu.Name = "mnuSalir"
        itmMenu.Size = New System.Drawing.Size(61, 20)
        itmMenu.Text = "Salir"
        a.Add(itmMenu)

        Return a

    End Function
    Function GetObjetos(e As Entidad) As List(Of Object)
        Dim a As New List(Of Object)
        Dim t As System.Windows.Forms.TextBox
        Dim l As System.Windows.Forms.Label
        Dim d As System.Windows.Forms.DateTimePicker
        Dim chk As System.Windows.Forms.CheckBox
        Dim atr As Atributo
        Dim y As Integer = 10

        For Each atr In e.Atributos
            Select Case atr.Tipo

                Case Atributo.ENUM_TIPOS.TEXTO, Atributo.ENUM_TIPOS.ENTERO, Atributo.ENUM_TIPOS.DECIM
                    l = New System.Windows.Forms.Label With {
                        .Name = "lbl" & atr.Nombre,
                        .Width = 100,
                        .Text = atr.Nombre,
                        .Location = New Drawing.Point(20, y)
                    }
                    a.Add(l)

                    t = New System.Windows.Forms.TextBox With {
                            .Name = "txt" & atr.Nombre,
                            .Multiline = False,
                            .Width = 100,
                            .Text = "",
                            .Location = New Drawing.Point(20 + l.Width + 10, y),
                            .CharacterCasing = CharacterCasing.Upper
                        }
                    a.Add(t)
                Case Atributo.ENUM_TIPOS.FECHA
                    l = New System.Windows.Forms.Label With {
                        .Name = "lbl" & atr.Nombre,
                        .Width = 100,
                        .Text = atr.Nombre,
                        .Location = New Drawing.Point(20, y)
                    }
                    a.Add(l)

                    d = New System.Windows.Forms.DateTimePicker With {
                    .Name = "dt" & atr.Nombre,
                    .Width = 97,
                    .Text = "",
                    .Location = New Drawing.Point(20 + l.Width + 10, y),
                    .CustomFormat = "dd/MM/yyyy"
                    }
                    a.Add(d)
                Case Atributo.ENUM_TIPOS.BOOLEANO
                    chk = New System.Windows.Forms.CheckBox With {
                            .Name = "chk" & atr.Nombre,
                            .Width = 100,
                            .Text = atr.Nombre,
                            .Location = New Drawing.Point(20, y)
                        }
                    a.Add(chk)
            End Select
            y = y + 50
        Next
        Return a
    End Function
End Class
