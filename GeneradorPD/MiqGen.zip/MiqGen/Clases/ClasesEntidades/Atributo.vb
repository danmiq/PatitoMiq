﻿Imports System.Xml.Serialization
Public Class Atributo
    Public Enum ENUM_TIPOS
        TEXTO = 1
        FECHA = 2
        ENTERO = 3
        DECIM = 4
        BOOLEANO = 5
    End Enum
    <XmlElement("Nombre")>
    Public Nombre As String
    <XmlElement("Tipo")>
    Public Tipo As ENUM_TIPOS
    Public Sub New()

    End Sub
    Public Sub New(sNombre As String, T As Atributo.ENUM_TIPOS)
        Me.Nombre = sNombre
        Me.Tipo = T
    End Sub
End Class
