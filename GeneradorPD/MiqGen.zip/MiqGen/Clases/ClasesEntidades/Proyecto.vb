﻿Imports System.IO
Imports System.Xml.Serialization


Public Class Proyecto
    <XmlElement("Nombre")>
    Public Nombre As String
    <XmlElement("Entidades")>
    Public Entidades As List(Of Entidad)
    Public Sub New()

    End Sub
    Public Sub New(sNombre As String)
        Me.Nombre = sNombre
        Me.Entidades = New List(Of Entidad)
    End Sub

    Public Sub Load(sArch As String)

    End Sub

End Class
