﻿Imports System.Collections.Generic
Imports System.Xml.Serialization
Public Class Entidad
    <XmlElement("Nombre")>
    Public Nombre As String
    <XmlElement("Atributos")>
    Public Atributos As List(Of Atributo)

    Public Sub New()

    End Sub
    Public Sub New(sNombre As String)
        Me.Nombre = sNombre
        Me.Atributos = New List(Of Atributo)
    End Sub

End Class
