﻿Imports System.IO
Imports System.Windows.Forms

Public Class GeneradorVB2019
    Inherits Generador
    Private sCarpetaProyecto As String
    Dim COMILLA As Char = Chr(34)

    Public Sub New(sNombre As String)
        Me.sProyecto = sNombre
    End Sub

    Public Property CarpetaProyecto As String
        Get
            Return sCarpetaProyecto
        End Get
        Set(value As String)
            sCarpetaProyecto = value
        End Set
    End Property

    Sub CopiarMolde(sCarpetaMolde As String)

        My.Computer.FileSystem.CopyDirectory(sCarpetaMolde, Me.sCarpetaProyecto & sProyecto)

        My.Computer.FileSystem.RenameFile(sCarpetaProyecto & sProyecto & "\Molde.sln", sProyecto & ".sln")
        My.Computer.FileSystem.RenameFile(sCarpetaProyecto & sProyecto & "\Molde.vbproj", sProyecto & ".vbproj")

        FindReplace(sCarpetaProyecto & sProyecto & "\" & sProyecto & ".sln", "Molde", sProyecto)
        FindReplace(sCarpetaProyecto & sProyecto & "\" & sProyecto & ".vbproj", "Molde", sProyecto)
        FindReplace(sCarpetaProyecto & sProyecto & "\" & "My Project\Settings.settings", "Molde", sProyecto)
        FindReplace(sCarpetaProyecto & sProyecto & "\" & "My Project\Settings.Designer.vb", "Molde", sProyecto)
        FindReplace(sCarpetaProyecto & sProyecto & "\" & "My Project\Application.Designer.vb", "Global.Molde.Form1", "Global." & sProyecto & ".frmMain")
        FindReplace(sCarpetaProyecto & sProyecto & "\" & "My Project\Application.myapp", "Form1", "frmMain")
    End Sub
    Sub AddObjeto(sForm As String)


    End Sub
    Private Sub IncludeInProject(sForm As String)
        Dim oXML As System.Xml.XmlDocument

        sForm = "frm" & sForm
        oXML = LeerXML(sCarpetaProyecto & sProyecto & "\" & sProyecto & ".vbproj")

        Dim n, n2, n3 As Xml.XmlNode

        n = oXML.ChildNodes(1).ChildNodes(10)
        n2 = n.ChildNodes(0).Clone
        n3 = n.ChildNodes(1).Clone

        ' <ItemGroup>                                       ==> n
        '           <Compile Include = "Form1.vb" >         ==> n2
        '                <SubType>Form</SubType>
        '           </Compile>
        '           <Compile Include = "Form1.Designer.vb" >   ==> n3
        '                   <DependentUpon>Form1.vb</DependentUpon>
        '                    <SubType>Form</SubType>
        '           </Compile>
        n2.Attributes(0).Value = sForm & ".vb"
        n3.Attributes(0).Value = sForm & ".Designer.vb"
        n3.ChildNodes(0).ChildNodes(0).Value = sForm & ".vb"

        n.AppendChild(n2)
        n.AppendChild(n3)

        oXML.Save(sCarpetaProyecto & sProyecto & "\" & sProyecto & ".vbproj")

    End Sub
    Private Sub CrearForm(sNombre As String, aObjetos As List(Of Object))
        Dim sContenido As String
        Dim sPath As String
        Dim file As System.IO.StreamWriter
        Dim bHayMenu As Boolean = HayMenu(aObjetos)

        sPath = sCarpetaProyecto & sProyecto & "\"

        sContenido = "<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _" & vbCrLf &
            "     Partial Class frm" & sNombre & vbCrLf &
            "     Inherits System.Windows.Forms.Form" & vbCrLf & vbCrLf &
            "         <System.Diagnostics.DebuggerNonUserCode()> _" & vbCrLf &
            "     Protected Overrides Sub Dispose(ByVal disposing As Boolean)" & vbCrLf &
            "       Try" & vbCrLf &
            "           If disposing AndAlso components IsNot Nothing Then" & vbCrLf &
            "               components.Dispose()" & vbCrLf &
            "           End If" & vbCrLf &
            "       Finally" & vbCrLf &
            "           MyBase.Dispose(disposing)" & vbCrLf &
            "       End Try" & vbCrLf &
            "      End Sub" & vbCrLf & vbCrLf &
            "      Private components As System.ComponentModel.IContainer" & vbCrLf & vbCrLf &
            "      <System.Diagnostics.DebuggerStepThrough()> _" & vbCrLf &
            "      Private Sub InitializeComponent()" & vbCrLf

        sContenido = sContenido & AgregarDatosObjetos(aObjetos, 1)
        If bHayMenu Then
            sContenido = sContenido & "           Me.MenuStrip1.SuspendLayout()" & vbCrLf
        End If
        sContenido = sContenido & "           Me.SuspendLayout()" & vbCrLf
        If bHayMenu Then
            Dim sMenus As String = GetItemsMenu(aObjetos)
            sContenido = sContenido & "           Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {" & sMenus & "})" & vbCrLf
        End If
        sContenido = sContenido & AgregarDatosObjetos(aObjetos, 2)
        sContenido = sContenido & "           Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)" & vbCrLf &
            "           Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font" & vbCrLf &
            "           Me.ClientSize = New System.Drawing.Size(800, 450)" & vbCrLf
        sContenido = sContenido & AgregarDatosObjetos(aObjetos, 3)
        If bHayMenu Then
            sContenido = sContenido & "        Me.MainMenuStrip = Me.MenuStrip1" & vbCrLf
        End If
        sContenido = sContenido & "           Me.Name = " & COMILLA & "frm" & sNombre & COMILLA & vbCrLf &
            "           Me.Text = " & COMILLA & sNombre & COMILLA & vbCrLf
        If bHayMenu Then
            sContenido = sContenido & "           Me.MenuStrip1.ResumeLayout(False)" & vbCrLf &
                                   "           Me.MenuStrip1.PerformLayout()" & vbCrLf
        End If
        sContenido = sContenido & "           Me.ResumeLayout(False)" & vbCrLf &
            "           Me.PerformLayout()" & vbCrLf &
            "   End Sub" & vbCrLf
        sContenido = sContenido & AgregarDatosObjetos(aObjetos, 4)

        If bHayMenu Then
            sContenido = sContenido & "Private Sub mnuSalir_Click(sender As Object, e As EventArgs) Handles mnuSalir.Click" & vbCrLf &
                                      "  Me.Close()" & vbCrLf &
                                      "End Sub" & vbCrLf
            For Each o In aObjetos
                If o.GetType.Name = "ToolStripMenuItem" And o.name <> "mnuSalir" Then
                    sContenido = sContenido & "Private Sub " & o.name & "_Click(sender As Object, e As EventArgs) Handles " & o.name & ".Click" & vbCrLf &
                                              "   frm" & o.text & ".Show()" & vbCrLf &
                                              "End Sub" & vbCrLf
                End If
            Next

        End If
        sContenido = sContenido & "End Class"

        ' Graba DISEÑO del form
        file = My.Computer.FileSystem.OpenTextFileWriter(sPath & "frm" & sNombre & ".Designer.vb", True)
        file.WriteLine(sContenido)
        file.Close()

        ' Crea Codigo del form
        'sContenido = "Public Class " & sNombre & vbCrLf &
        '             "  Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click" & vbCrLf &
        '             "      MsgBox(444)" & vbCrLf &
        '             "  End Sub " & vbCrLf &
        '             "End Class"

        sContenido = ""
        ' Graba CODIGO del form
        file = My.Computer.FileSystem.OpenTextFileWriter(sPath & "frm" & sNombre & ".vb", True)
        file.WriteLine(sContenido)
        file.Close()

    End Sub
    Function GetItemsMenu(aObjetos As List(Of Object)) As String
        GetItemsMenu = ""
        For Each o In aObjetos
            If o.GetType.Name = "ToolStripMenuItem" Then
                GetItemsMenu = GetItemsMenu & "Me." & o.name & ","
            End If
        Next
        If GetItemsMenu.Length > 0 Then
            GetItemsMenu = GetItemsMenu.Substring(0, GetItemsMenu.Length - 1)
        End If

    End Function
    Function HayMenu(aObjetos As List(Of Object)) As Boolean
        HayMenu = False
        For Each o In aObjetos
            If o.GetType.Name = "MenuStrip" Then
                HayMenu = True
            End If
        Next
    End Function
    Private Function AgregarDatosObjetos(aObjetos As List(Of Object), nTipo As Integer) As String
        Dim o As Object
        Dim s As String = ""
        Dim nX, nY, i As Integer
        nX = 50
        nY = 50
        i = 0
        For Each o In aObjetos
            Select Case nTipo
                Case 1
                    s = s & "           Me." & o.name & " = New " & o.GetType.FullName & "()" & vbCrLf
                Case 2
                    Select Case o.GetType.Name
                        Case "TextBox"
                            s = s & "           Me." & o.name & ".Location = New System.Drawing.Point(" & o.location.x & "," & o.location.y & ")" & vbCrLf &
                                    "           Me." & o.name & ".Name = " & COMILLA & o.name & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Size = New System.Drawing.Size(79, 30)" & vbCrLf &
                                    "           Me." & o.name & ".TabIndex = " & i & vbCrLf &
                                    "           Me." & o.name & ".Text = " & COMILLA & o.text & COMILLA & vbCrLf
                        Case "DateTimePicker"
                            s = s & "           Me." & o.name & ".Location = New System.Drawing.Point(" & o.location.x & "," & o.location.y & ")" & vbCrLf &
                                    "           Me." & o.name & ".Name = " & COMILLA & o.name & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Width = " & o.width & vbCrLf &
                                    "           Me." & o.name & ".TabIndex = " & i & vbCrLf &
                                    "           Me." & o.name & ".CustomFormat = " & COMILLA & "dd/MM/yyyy" & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Format = System.Windows.Forms.DateTimePickerFormat.Custom" & vbCrLf
                        Case "Button"
                            s = s & "           Me." & o.name & ".UseVisualStyleBackColor = True" & vbCrLf
                        Case "Label"
                            s = s & "           Me." & o.name & ".Location = New System.Drawing.Point(" & o.location.x & "," & o.location.y & ")" & vbCrLf &
                                    "           Me." & o.name & ".Name = " & COMILLA & o.name & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Width = " & o.width & vbCrLf &
                                    "           Me." & o.name & ".AutoSize = True" & vbCrLf &
                                    "           Me." & o.name & ".Text = " & COMILLA & o.text & COMILLA & vbCrLf
                        Case "CheckBox"
                            s = s & "           Me." & o.name & ".Location = New System.Drawing.Point(" & o.location.x & "," & o.location.y & ")" & vbCrLf &
                                    "           Me." & o.name & ".Name = " & COMILLA & o.name & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Width = " & o.width & vbCrLf &
                                    "           Me." & o.name & ".Text = " & COMILLA & o.text & COMILLA & vbCrLf
                        Case "MenuStrip"
                            s = s & "           Me." & o.name & ".Location = New System.Drawing.Point(0,0)" & vbCrLf &
                                    "           Me." & o.name & ".Name = " & COMILLA & o.name & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Size = New System.Drawing.Size(800, 24)" & vbCrLf &
                                    "           Me." & o.name & ".Text = " & COMILLA & o.text & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".BackColor = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(230, Byte), Integer))" & vbCrLf &
                                    "           Me." & o.name & ".Dock = " & o.Dock & vbCrLf &
                                    "           Me." & o.name & ".TabStop = True" & vbCrLf &
                                    "           Me." & o.name & ".Stretch = False" & vbCrLf
                        Case "ToolStripMenuItem"
                            s = s & "           Me." & o.name & ".Name = " & COMILLA & o.name & COMILLA & vbCrLf &
                                    "           Me." & o.name & ".Size = New System.Drawing.Size(60, 20)" & vbCrLf &
                                    "           Me." & o.name & ".Text = " & COMILLA & o.text & COMILLA & vbCrLf

                    End Select
                Case 3
                    If o.GetType.Name <> "ToolStripMenuItem" Then
                        s = s & "           Me.Controls.Add(Me." & o.name & ")" & vbCrLf
                    End If

                Case 4
                    s = s & "   Friend WithEvents " & o.name & " As " & o.GetType.Name & vbCrLf
            End Select
            i = i + 1
        Next
        Return s
    End Function
    Sub AddForm(sNombre As String, a As List(Of Object))
        CrearForm(sNombre, a)
        IncludeInProject(sNombre)
    End Sub

End Class
