﻿Module VB2019


    Sub CopiarMolde(sCarpetaMolde As String, sCarpetaDestino As String, sProyecto As String)
        System.Console.WriteLine("Origen  : " + sCarpetaMolde)
        System.Console.WriteLine("Destino : " + sCarpetaDestino)

        My.Computer.FileSystem.CopyDirectory(sCarpetaMolde, sCarpetaDestino & sProyecto)

        My.Computer.FileSystem.RenameFile(sCarpetaDestino & sProyecto & "\Molde.sln", sProyecto & ".sln")
        My.Computer.FileSystem.RenameFile(sCarpetaDestino & sProyecto & "\Molde.vbproj", sProyecto & ".vbproj")

        FindReplace(sCarpetaDestino & sProyecto & "\" & sProyecto & ".sln", "Molde", sProyecto)
        FindReplace(sCarpetaDestino & sProyecto & "\" & sProyecto & ".vbproj", "Molde", sProyecto)
        FindReplace(sCarpetaDestino & sProyecto & "\" & "My Project\Settings.settings", "Molde", sProyecto)
        FindReplace(sCarpetaDestino & sProyecto & "\" & "My Project\Application.Designer.vb", "Molde", sProyecto)
        FindReplace(sCarpetaDestino & sProyecto & "\" & "My Project\Application.Designer.vb", "Global.Molde.Form1", "Global." & sProyecto & ".frmMain")

        FindReplace(sCarpetaDestino & sProyecto & "\" & "My Project\Settings.Designer.vb", "Molde", sProyecto)


    End Sub
    Sub AddObjeto(sForm As String)


    End Sub

    Sub AddForm(sPath As String, sNombre As String)
        Dim COMILLA As Char = Chr(34)
        Dim sContenido As String
        sContenido = "<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _" & vbCrLf &
            "     Partial Class " & sNombre & vbCrLf &
            "     Inherits System.Windows.Forms.Form" & vbCrLf & vbCrLf &
            "         <System.Diagnostics.DebuggerNonUserCode()> _" & vbCrLf &
            "     Protected Overrides Sub Dispose(ByVal disposing As Boolean)" & vbCrLf &
            "       Try" & vbCrLf &
            "           If disposing AndAlso components IsNot Nothing Then" & vbCrLf &
            "               components.Dispose()" & vbCrLf &
            "           End If" & vbCrLf &
            "       Finally" & vbCrLf &
            "           MyBase.Dispose(disposing)" & vbCrLf &
            "       End Try" & vbCrLf &
            "      End Sub" & vbCrLf & vbCrLf &
            "      Private components As System.ComponentModel.IContainer" & vbCrLf &
            "         <System.Diagnostics.DebuggerStepThrough()> _" & vbCrLf &
            "      Private Sub InitializeComponent()" & vbCrLf &
            "           Me.Button1 = New System.Windows.Forms.Button()" & vbCrLf &
            "           Me.TextBox1 = New System.Windows.Forms.TextBox()" & vbCrLf &
            "           Me.SuspendLayout()" & vbCrLf &
            "           Me.Button1.Location = New System.Drawing.Point(100, 100)" & vbCrLf &
            "           Me.Button1.Name = " & COMILLA & "Button1" & COMILLA & vbCrLf &
            "           Me.Button1.Size = New System.Drawing.Size(79, 30)" & vbCrLf &
            "           Me.Button1.TabIndex = 0" & vbCrLf &
            "           Me.Button1.Text = " & COMILLA & "Aprietame" & COMILLA & vbCrLf &
            "           Me.Button1.UseVisualStyleBackColor = True" & vbCrLf &
            "           Me.TextBox1.Location = New System.Drawing.Point(48, 280)" & vbCrLf &
            "           Me.TextBox1.Name = " & COMILLA & "TextBox1" & COMILLA & vbCrLf &
            "           Me.TextBox1.Size = New System.Drawing.Size(226, 20)" & vbCrLf &
            "           Me.TextBox1.TabIndex = 1" & vbCrLf &
            "           Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)" & vbCrLf &
            "           Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font" & vbCrLf &
            "           Me.ClientSize = New System.Drawing.Size(800, 450)" & vbCrLf &
            "           Me.Controls.Add(Me.TextBox1)" & vbCrLf &
            "           Me.Controls.Add(Me.Button1)" & vbCrLf &
            "           Me.Name = " & COMILLA & sNombre & COMILLA & vbCrLf &
            "           Me.Text = " & COMILLA & sNombre & COMILLA & vbCrLf &
            "           Me.ResumeLayout(False)" & vbCrLf &
            "           Me.PerformLayout()" & vbCrLf &
            "   End Sub" & vbCrLf &
            "   Friend WithEvents Button1 As Button" & vbCrLf &
            "   Friend WithEvents TextBox1 As TextBox" & vbCrLf &
            "End Class"

        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter(sPath & sNombre & ".Designer.vb", True)
        file.WriteLine(sContenido)
        file.Close()

        sContenido = "Public Class " & sNombre & vbCrLf &
                     "  Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click" & vbCrLf &
                     "      MsgBox(Me.TextBox1.Text)" & vbCrLf &
                     "  End Sub " & vbCrLf &
                     "End Class"

        file = My.Computer.FileSystem.OpenTextFileWriter(sPath & sNombre & ".vb", True)
        file.WriteLine(sContenido)
        file.Close()

    End Sub
End Module
